// ═══════════════════════════════════════════════════════════════
// Klard — Migrations-Runner
// Datei: scripts/migrate.js
// Spielt alle SQL-Dateien aus /sql in alphabetischer Reihenfolge ein.
// Aufruf:  node scripts/migrate.js
// Setzt voraus, dass dein Basis-Schema (klard-seed.sql) bereits läuft.
// ═══════════════════════════════════════════════════════════════
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { pool } from "../src/db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SQL_DIR = path.join(__dirname, "..", "sql");

async function run() {
  const files = fs.readdirSync(SQL_DIR).filter(f => f.endsWith(".sql")).sort();
  if (!files.length) { console.log("Keine SQL-Dateien in /sql gefunden."); return; }
  console.log(`Spiele ${files.length} Migration(en) ein:\n`);
  for (const f of files) {
    const sql = fs.readFileSync(path.join(SQL_DIR, f), "utf8");
    process.stdout.write(`  → ${f} ... `);
    try {
      await pool.query(sql);
      console.log("OK");
    } catch (e) {
      console.log("FEHLER");
      console.error(`     ${e.message}`);
      process.exit(1);
    }
  }
  console.log("\n✅ Alle Migrationen eingespielt.");
  await pool.end();
}
run().catch(e => { console.error(e); process.exit(1); });
