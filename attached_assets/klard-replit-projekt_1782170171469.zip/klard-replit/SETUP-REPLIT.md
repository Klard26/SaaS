# Klard auf Replit aufsetzen

Komplettes, lauffähiges Backend für alle fünf Umsatzströme. Jede Datei wurde
gegen echtes PostgreSQL und über HTTP getestet (Migration, Server-Start,
Endpoints, DSGVO-Gate).

## Projektstruktur
```
src/
  index.js              Server-Einstiegspunkt (alle Routes + Webhook)
  db.js                 PostgreSQL-Pool (Neon-SSL automatisch)
  email.js              Resend + Handlebars (Demo-Modus ohne Key)
  middleware/
    entitlements.js     Tier-Gating, Lead-Limit, Rabatt
  routes/
    requests.js         Anfrage stellen, Angebot senden, Lead-Refund
    providerRequests.js Anbieter-Ansicht MIT Anonymisierung
    subscriptions.js    Abos (Stripe) + Webhook-Handler
    finance.js          Förder-Affiliate (5. Umsatzstrom)
    walletWebhook.js    Guthaben-Aufladung verbuchen
sql/
  00-base.sql           Basis-Schema (NUR bei Neustart, sonst löschen)
  01-anfragen.sql       Anfragen, Angebote, Wallet, Reviews
  02-abo.sql            Abo-Pläne, Subscriptions, Limits
  03-affiliate.sql      Finanzpartner, Förder-Leads
scripts/
  migrate.js            Spielt /sql der Reihe nach ein
public/
  anfrage.html          Kunden-Anfrage-Formular (erreichbar unter /anfrage.html)
emails/                 4 Handlebars-Templates
test/
  e2e-test.mjs          21-Punkte-End-to-End-Test
```

## Schritt 1 — Projekt anlegen
Neues Replit-Projekt (Node.js) erstellen. Diese Dateien hochladen (ZIP
entpacken oder per "Download as zip" → Import).

## Schritt 2 — PostgreSQL provisionieren
Replit nutzt serverloses Postgres (Neon). Im Project Editor das **Database**-Tool
öffnen und eine Postgres-DB erstellen. Replit setzt dann automatisch das Secret
`DATABASE_URL`. (Alternativ: externe Neon/Supabase-URL als Secret eintragen —
db.js erkennt Neon und aktiviert SSL automatisch.)

## Schritt 3 — Secrets setzen
Tools → Secrets. `DATABASE_URL` ist nach Schritt 2 schon da. Ergänzen:
```
STRIPE_SECRET_KEY      sk_test_...   (Stripe-Dashboard → Developers → API keys)
STRIPE_WEBHOOK_SECRET  whsec_...     (nach Schritt 6)
RESEND_API_KEY         re_...        (optional; leer = E-Mail-Demo-Modus)
EMAIL_FROM             Klard <noreply@deine-domain>
APP_URL                https://dein-repl.replit.app
```
Ohne STRIPE/RESEND-Keys läuft alles im Demo-Modus (kein echter Zahlungs-/
Mailversand), die DB-Logik funktioniert trotzdem vollständig.

## Schritt 4 — Abhängigkeiten & Migration
Im Shell-Tab:
```bash
npm install
npm run migrate
```
Wenn du dein bestehendes Schema (klard-seed.sql mit den 153 Leistungen) schon
hast: **sql/00-base.sql vorher löschen**, sonst überspringt der Runner es dank
`IF NOT EXISTS` ohnehin schadlos. Lade dann zusätzlich dein klard-seed.sql und
deine Katalogdaten ein.

## Schritt 5 — Starten
"Run" klicken (oder `npm start`). Erwartete Ausgabe:
```
✅ Klard-Server läuft auf Port 3000
```
Test im Browser: `/api/health` → `{"status":"ok","db":true}`.
Anfrage-Formular: `/anfrage.html`.

## Schritt 6 — Stripe-Webhook
Im Stripe-Dashboard → Developers → Webhooks → Endpoint hinzufügen:
- URL: `https://dein-repl.replit.app/webhook/stripe`
- Events: `checkout.session.completed`, `customer.subscription.updated`,
  `customer.subscription.deleted`, `invoice.payment_failed`
Den erzeugten Signing-Secret (`whsec_...`) als `STRIPE_WEBHOOK_SECRET` eintragen.

## Schritt 7 — Stripe-Abo-Preise
Im Stripe-Dashboard zwei wiederkehrende Preise anlegen (Plus 29 €, Pro 79 €),
dann im SQL-Runner:
```sql
UPDATE subscription_plans SET stripe_price_id='price_XXXX' WHERE tier='plus';
UPDATE subscription_plans SET stripe_price_id='price_YYYY' WHERE tier='pro';
```

## Schritt 8 — Deployment
Replit → Deploy (Autoscale/Cloud Run). Der Server bindet an `0.0.0.0` und nutzt
`process.env.PORT` — beides ist für Replit-Deployments nötig und bereits gesetzt.

## Test ausführen
```bash
npm run test:e2e
```
(Setzt eine erreichbare DB voraus; Verbindung in test/e2e-test.mjs ggf. anpassen.)

## Frontend-Hinweis
Das Anfrage-Formular (public/anfrage.html) läuft ohne Konfiguration im
Demo-Modus. Für den Echtbetrieb im <script> setzen:
```js
window.KLARD_API = "/api";
window.KLARD_CATALOG = <dein klard-katalog-v2.json>;
```
Die Dashboard-Tabs (Anfragen/Tarif) aus dem vorherigen Paket fügst du in dein
bestehendes klard-plattform.html ein.

## Bekannte Stolpersteine (aus Replit-Praxis)
- "pg module not found" → `npm install` lief nicht; im Shell-Tab nachholen.
- SSL-Fehler bei externer DB → db.js aktiviert SSL nur bei neon.tech/sslmode;
  bei anderem Provider ssl-Block in db.js anpassen.
- Webhook empfängt nichts → Endpoint-URL muss die öffentliche Repl-URL sein,
  nicht localhost; Repl muss deployed/aktiv sein.
- Repl "schläft" → für dauerhaften Webhook-Empfang Deployment (nicht nur Dev-Run)
  verwenden.
```
