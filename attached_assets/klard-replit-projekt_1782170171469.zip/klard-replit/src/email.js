// ═══════════════════════════════════════════════════════════════
// Klard — E-Mail-Service (Resend + Handlebars)
// Datei: src/email.js
// Lädt .hbs-Templates aus /emails, cached sie und versendet via Resend.
// Im Demo-Modus (kein RESEND_API_KEY) wird nur geloggt.
// ═══════════════════════════════════════════════════════════════
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import Handlebars from "handlebars";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const EMAIL_DIR = path.join(__dirname, "..", "emails");

const cache = new Map();
function getTemplate(name) {
  if (cache.has(name)) return cache.get(name);
  const file = path.join(EMAIL_DIR, name + ".hbs");
  const src = fs.readFileSync(file, "utf8");
  const tpl = Handlebars.compile(src);
  cache.set(name, tpl);
  return tpl;
}

// Betreffzeilen pro Template
const SUBJECTS = {
  new_request_provider:   "Neue Anfrage für Sie auf Klard",
  offer_received:         "Sie haben ein neues Angebot auf Klard",
  subscription_activated: "Ihr Klard-Tarif ist aktiv",
  finance_lead_partner:   "Neuer Finanzierungs-Lead über Klard",
};

export async function sendEmail(templateName, to, context = {}) {
  const appUrl = process.env.APP_URL || "https://klard.de";
  const html = getTemplate(templateName)({ ...context, app_url: appUrl });
  const subject = SUBJECTS[templateName] || "Nachricht von Klard";

  if (!process.env.RESEND_API_KEY) {
    console.log(`📧 [DEMO] ${templateName} → ${to} (Betreff: ${subject})`);
    return { demo: true };
  }

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${process.env.RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: process.env.EMAIL_FROM || "Klard <noreply@klard.de>",
      to: [to], subject, html,
    }),
  });
  if (!res.ok) {
    const err = await res.text();
    console.error("Resend-Fehler:", err);
    throw new Error("E-Mail-Versand fehlgeschlagen");
  }
  return res.json();
}
