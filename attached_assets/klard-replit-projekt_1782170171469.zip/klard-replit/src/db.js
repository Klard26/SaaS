// ═══════════════════════════════════════════════════════════════
// Klard — Datenbank-Anbindung (PostgreSQL / Neon auf Replit)
// Datei: src/db.js
// ═══════════════════════════════════════════════════════════════
import pg from "pg";
const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  console.warn("⚠️  DATABASE_URL ist nicht gesetzt. In Replit: Database-Tool öffnen " +
               "und Postgres provisionieren, oder in Secrets eintragen.");
}

// Neon (Replit-Postgres) verlangt SSL. Lokal (ohne sslmode) wird SSL aus.
const needsSsl = /neon\.tech|sslmode=require/.test(process.env.DATABASE_URL || "");

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: needsSsl ? { rejectUnauthorized: false } : false,
  max: 10,
  idleTimeoutMillis: 30000,
});

pool.on("error", (err) => {
  console.error("Unerwarteter DB-Pool-Fehler:", err.message);
});

export async function healthcheck() {
  const r = await pool.query("SELECT 1 AS ok");
  return r.rows[0].ok === 1;
}
