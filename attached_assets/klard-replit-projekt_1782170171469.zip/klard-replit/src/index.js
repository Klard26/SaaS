// ═══════════════════════════════════════════════════════════════
// Klard — Server-Einstiegspunkt
// Datei: src/index.js
// Bindet alle Routes ein + zentralen Stripe-Webhook.
// WICHTIG: Webhook braucht Raw-Body → vor express.json() registriert.
// ═══════════════════════════════════════════════════════════════
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import Stripe from "stripe";

import { pool, healthcheck } from "./db.js";
import requestsRouter from "./routes/requests.js";
import providerRequestsRouter from "./routes/providerRequests.js";
import subscriptionsRouter, { handleSubscriptionWebhook } from "./routes/subscriptions.js";
import financeRouter from "./routes/finance.js";
import { handleWalletWebhook } from "./routes/walletWebhook.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_dummy");

// ─── Stripe-Webhook ZUERST (Raw-Body nötig) ────────────────────
app.post("/webhook/stripe",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    let event;
    if (process.env.STRIPE_WEBHOOK_SECRET) {
      try {
        event = stripe.webhooks.constructEvent(
          req.body, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET);
      } catch (err) {
        return res.status(400).send(`Webhook Error: ${err.message}`);
      }
    } else {
      // Demo-Modus ohne Signaturprüfung
      event = JSON.parse(req.body.toString());
    }
    try {
      await handleSubscriptionWebhook(event);
      await handleWalletWebhook(event);
      // hier ggf. deine bestehenden Booking-Handler ergänzen
    } catch (e) {
      console.error("Webhook-Verarbeitung fehlgeschlagen:", e.message);
    }
    res.json({ received: true });
  });

// ─── Standard-Middleware (nach dem Webhook) ────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Statisches Anfrage-Formular ausliefern
app.use(express.static(path.join(__dirname, "..", "public")));

// ─── API-Routes ────────────────────────────────────────────────
app.use("/api", requestsRouter);
app.use("/api", providerRequestsRouter);
app.use("/api", subscriptionsRouter);
app.use("/api", financeRouter);

// ─── Health & Root ─────────────────────────────────────────────
app.get("/api/health", async (_req, res) => {
  try {
    const ok = await healthcheck();
    res.json({ status: ok ? "ok" : "degraded", db: ok });
  } catch (e) {
    res.status(500).json({ status: "error", error: e.message });
  }
});

app.get("/", (_req, res) => {
  res.send("Klard API läuft. Anfrage-Formular: /anfrage.html · Health: /api/health");
});

// ─── Start: an 0.0.0.0 binden (Replit-Anforderung) ─────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`✅ Klard-Server läuft auf Port ${PORT}`);
  console.log(`   Health: http://0.0.0.0:${PORT}/api/health`);
});
