-- ═══════════════════════════════════════════════════════════════
-- Klard — Basis-Schema (00-base.sql)
-- NUR nötig, wenn du in Replit ganz neu startest und dein bestehendes
-- klard-seed.sql (branches, service_categories, ...) noch NICHT drin ist.
-- Wenn du dein echtes Schema schon hast: diese Datei aus /sql LÖSCHEN,
-- damit der Migrations-Runner sie überspringt.
-- ═══════════════════════════════════════════════════════════════
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS branches (
  id   TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  requires_dena BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS service_categories (
  id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  branch_id TEXT REFERENCES branches(id),
  name      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS service_templates (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  category_id UUID REFERENCES service_categories(id),
  name        TEXT NOT NULL,
  price_min   NUMERIC(10,2),
  price_avg   NUMERIC(10,2),
  price_max   NUMERIC(10,2),
  unit        TEXT,
  fundable    TEXT,
  notes       TEXT
);

CREATE TABLE IF NOT EXISTS providers (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  contact_name TEXT,
  email        TEXT,
  is_active    BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS provider_services (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  provider_id         UUID REFERENCES providers(id) ON DELETE CASCADE,
  service_template_id UUID REFERENCES service_templates(id),
  price               NUMERIC(10,2)
);

CREATE TABLE IF NOT EXISTS customers (
  id    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name  TEXT,
  email TEXT
);
