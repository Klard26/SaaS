import PDFDocument from "pdfkit";
import type { ReportModell } from "./report-modell.js";

/* Farbpalette (konsistent zur Dokument-Optik) */
const INK = "#13243D";
const AMBER = "#B86A14";
const TEAL = "#1F7A6D";
const RED = "#A32D2D";
const GREY = "#5A5A5A";
const LINE = "#CCCCCC";
const PAPER = "#F7F4EE";

const eur = (n: number) => n.toLocaleString("de-DE") + " €";
const pct = (n: number) => (n * 100).toLocaleString("de-DE") + " %";

/**
 * Die eingebauten PDFKit-Standardfonts (WinAnsi) stellen einige Sonderzeichen
 * nicht dar (hochgestellte ², ³, Pfeile). Wir ersetzen sie font-sicher, damit
 * der Report ohne eingebettete Font-Dateien sauber rendert (wichtig für Replit).
 */
function fs(text: string): string {
  return text
    .replace(/²/g, "2")
    .replace(/³/g, "3")
    .replace(/→/g, "->")
    .replace(/≈/g, "ca. ");
}

/**
 * Erzeugt das PDF und schreibt es in den übergebenen Stream (z. B. die
 * HTTP-Response). Nutzt nur die eingebauten Standardfonts (keine Datei-Fonts),
 * damit es ohne zusätzliche Assets auf Replit läuft.
 */
export function schreibeReportPdf(modell: ReportModell, stream: NodeJS.WritableStream) {
  const doc = new PDFDocument({ size: "A4", margin: 50, bufferPages: true });
  doc.pipe(stream);

  const W = doc.page.width - doc.page.margins.left - doc.page.margins.right;
  const X = doc.page.margins.left;

  // ---------- Kopf ----------
  doc.fillColor(INK).font("Helvetica-Bold").fontSize(18)
    .text("ENERGETISCHE EINORDNUNG & SANIERUNGSEMPFEHLUNG", X, 50);
  doc.fillColor(AMBER).font("Helvetica-Oblique").fontSize(12)
    .text("Ergänzung zum Gebäude-Wertreport", { continued: false });
  doc.moveDown(0.4);
  doc.fillColor("#222").font("Helvetica-Bold").fontSize(10)
    .text(`Objekt: ${modell.objekt.adresse}`);
  doc.font("Helvetica").fillColor(GREY).fontSize(9)
    .text(fs(`${modell.objekt.nutzung} · ${modell.objekt.wohneinheiten} Wohneinheiten · BGF ${modell.objekt.bgf_m2} m² · Baujahr ${modell.objekt.baujahr}`));
  doc.moveDown(0.6);

  // ---------- roter Datenbasis-Hinweis ----------
  calloutBox(doc, X, W, "Wichtiger Hinweis zur Datenbasis",
    modell.hinweise[0], RED, "#FCEBEB");

  // ---------- 1. Energetische Einordnung ----------
  abschnitt(doc, "1. Energetische Einordnung (Schätzung)");
  doc.font("Helvetica").fontSize(10).fillColor("#222")
    .text(`Geschätzte Effizienzklasse: `, { continued: true })
    .font("Helvetica-Bold").text(`${modell.einordnung.effizienzklasse_schaetzung}`, { continued: true })
    .font("Helvetica").text(fs(`  (Endenergie ${modell.einordnung.endenergie_spanne})`));
  doc.moveDown(0.5);

  tabelle(doc, X, W, ["Bauteil", "Ist-Zustand", "Bewertung"], [0.32, 0.34, 0.34],
    modell.einordnung.bewertung.map((b) => [
      b.bauteil, b.ist,
      { text: b.bewertung, color: b.ampel === "rot" ? RED : b.ampel === "gelb" ? AMBER : TEAL },
    ]));

  // ---------- 2. Maßnahmen & Kosten ----------
  abschnitt(doc, "2. Empfohlene Maßnahmen & Kosten (Preisniveau 2026)");
  tabelle(doc, X, W, ["Maßnahme", "Menge", "Kosten (ca.)", "Förderstelle"], [0.40, 0.16, 0.26, 0.18],
    modell.massnahmen.map((m) => [
      m.name, m.menge, `${eur(m.kosten_min)} – ${eur(m.kosten_max)}`, m.foerderstelle,
    ]),
    [`Summe (grobe Spanne)`, "", `${eur(modell.kosten_summe_min)} – ${eur(modell.kosten_summe_max)}`, ""]);

  // ---------- 3. iSFP-Hebel ----------
  abschnitt(doc, "3. iSFP & iSFP-Bonus");
  doc.font("Helvetica").fontSize(10).fillColor("#222").text(
    "Der individuelle Sanierungsfahrplan (iSFP) ist der zentrale Förderhebel: +5 Prozentpunkte auf BAFA-Einzelmaßnahmen und Verdopplung der förderfähigen Kosten je Wohneinheit. Gilt nicht für den Heizungstausch (KfW).",
    { width: W });
  doc.moveDown(0.5);
  tabelle(doc, X, W, ["Förderrahmen Gebäudehülle", "ohne iSFP", "mit iSFP"], [0.46, 0.27, 0.27], [
    [`Förderfähige Kosten (${modell.objekt.wohneinheiten} WE)`, eur(modell.isfp.ff_kosten_ohne), eur(modell.isfp.ff_kosten_mit)],
    ["Fördersatz", pct(modell.isfp.quote_ohne), pct(modell.isfp.quote_mit)],
    ["iSFP-Erstellung", "—", modell.isfp.erstellung_zuschuss_text],
  ]);
  doc.moveDown(0.3);
  calloutBox(doc, X, W, `Beispiel: ${modell.isfp.beispiel_massnahme} (~${eur(modell.isfp.beispiel_kosten)})`,
    `Ohne iSFP: ${eur(modell.isfp.beispiel_foerderung_ohne)} · Mit iSFP: ${eur(modell.isfp.beispiel_foerderung_mit)} = rund ${eur(modell.isfp.beispiel_mehrfoerderung)} Mehrförderung allein bei dieser Maßnahme.`,
    TEAL, "#E2F0ED");

  // ---------- 4. Förderwege ----------
  abschnitt(doc, "4. Passende Förderwege");
  tabelle(doc, X, W, ["Maßnahme", "Förderstelle", "Konditionen 2026"], [0.30, 0.24, 0.46],
    modell.foerderwege.map((f) => [f.massnahme, f.stelle, f.konditionen]));

  // ---------- Hinweise / Footer-Disclaimer ----------
  doc.moveDown(0.6);
  doc.font("Helvetica-Bold").fontSize(9).fillColor(INK).text("Hinweise");
  doc.font("Helvetica").fontSize(8).fillColor(GREY);
  modell.hinweise.slice(1).forEach((h) => doc.text(fs("• " + h), { width: W }));

  // Seitenzahlen
  const range = doc.bufferedPageRange();
  for (let i = range.start; i < range.start + range.count; i++) {
    doc.switchToPage(i);
    doc.font("Helvetica").fontSize(8).fillColor(GREY).text(
      `Energetische Einordnung · ${modell.objekt.adresse} · Seite ${i + 1} von ${range.count}`,
      X, doc.page.height - 35, { width: W, align: "center" }
    );
  }

  doc.end();
}

/* ---------- Hilfsfunktionen ---------- */
function abschnitt(doc: PDFKit.PDFDocument, titel: string) {
  doc.moveDown(0.8);
  const y = doc.y;
  doc.fillColor(INK).font("Helvetica-Bold").fontSize(13).text(titel);
  doc.moveTo(doc.page.margins.left, doc.y + 2)
    .lineTo(doc.page.width - doc.page.margins.right, doc.y + 2)
    .lineWidth(1.5).strokeColor(AMBER).stroke();
  doc.moveDown(0.5);
}

function calloutBox(doc: PDFKit.PDFDocument, x: number, w: number, titel: string, text: string, akzent: string, fuell: string) {
  const padding = 8;
  doc.font("Helvetica-Bold").fontSize(10);
  const titelH = doc.heightOfString(titel, { width: w - 2 * padding });
  doc.font("Helvetica").fontSize(9);
  const textH = doc.heightOfString(text, { width: w - 2 * padding });
  const boxH = titelH + textH + 2 * padding + 4;
  const y = doc.y;
  doc.rect(x, y, w, boxH).fill(fuell);
  doc.rect(x, y, 4, boxH).fill(akzent); // Akzentbalken links
  doc.fillColor(akzent).font("Helvetica-Bold").fontSize(10)
    .text(fs(titel), x + padding + 4, y + padding, { width: w - 2 * padding - 4 });
  doc.fillColor("#333").font("Helvetica").fontSize(9)
    .text(fs(text), x + padding + 4, doc.y + 2, { width: w - 2 * padding - 4 });
  doc.y = y + boxH + 6;
  doc.x = x;
}

type Zelle = string | { text: string; color?: string };
function tabelle(
  doc: PDFKit.PDFDocument, x: number, w: number,
  header: string[], anteile: number[], zeilen: Zelle[][], summe?: Zelle[]
) {
  const colW = anteile.map((a) => a * w);
  const pad = 5;
  const rowH = (cells: Zelle[], bold: boolean) => {
    doc.font(bold ? "Helvetica-Bold" : "Helvetica").fontSize(8.5);
    return Math.max(...cells.map((c, i) =>
      doc.heightOfString(typeof c === "string" ? c : c.text, { width: colW[i] - 2 * pad }))) + 2 * pad;
  };

  // Header
  let y = doc.y;
  const hH = rowH(header, true);
  doc.rect(x, y, w, hH).fill(INK);
  let cx = x;
  doc.fillColor("#FFF").font("Helvetica-Bold").fontSize(8.5);
  header.forEach((h, i) => { doc.text(fs(h), cx + pad, y + pad, { width: colW[i] - 2 * pad }); cx += colW[i]; });
  y += hH;

  const zeichneZeile = (cells: Zelle[], idx: number, bold = false) => {
    const h = rowH(cells, bold);
    if (y + h > doc.page.height - doc.page.margins.bottom - 30) {
      doc.addPage(); y = doc.page.margins.top;
    }
    if (idx % 2 === 1) doc.rect(x, y, w, h).fill(PAPER);
    cx = x;
    cells.forEach((c, i) => {
      const txt = fs(typeof c === "string" ? c : c.text);
      const col = typeof c === "string" ? "#222" : (c.color || "#222");
      doc.fillColor(col).font(bold ? "Helvetica-Bold" : "Helvetica").fontSize(8.5)
        .text(txt, cx + pad, y + pad, { width: colW[i] - 2 * pad });
      cx += colW[i];
    });
    // Zeilenrahmen
    doc.moveTo(x, y + h).lineTo(x + w, y + h).lineWidth(0.5).strokeColor(LINE).stroke();
    y += h;
  };

  zeilen.forEach((z, i) => zeichneZeile(z, i));
  if (summe) zeichneZeile(summe, zeilen.length, true);
  doc.y = y + 4;
  doc.x = x;
}
