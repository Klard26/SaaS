/**
 * Report-Logik für den energetischen Erweiterungsreport.
 *
 * Trennt die fachlichen Berechnungen (Schätzungen!) von der PDF-Ausgabe.
 * Alle energetischen Kennwerte sind ABLEITUNGEN aus baulichen Merkmalen,
 * keine gemessenen Werte — das wird im Report deutlich gekennzeichnet.
 *
 * Konditionen (iSFP-Bonus, Förderquoten) Stand 2026. Vor produktivem Einsatz
 * an der amtlichen Quelle prüfen; idealerweise als pflegbare Konstanten halten.
 */

export interface GebaeudeInput {
  strasse?: string | null;
  plz?: string | null;
  ort?: string | null;
  bundesland?: string | null;
  baujahr?: number | null;
  nutzung: "wohngebaeude" | "nichtwohngebaeude" | "mischgebaeude";
  wohnflaeche_m2?: number | null;
  nutzflaeche_m2?: number | null;
  wohneinheiten?: number | null;
  heizung_traeger?: string | null;
  // optionale Geometrie (z. B. aus PLANFLUX); sonst aus BGF geschätzt
  bgf_m2?: number | null;
  umbauter_raum_m3?: number | null;
  ueberbaute_flaeche_m2?: number | null;
  mittlere_hoehe_m?: number | null;
  baupreisindex?: number | null; // zum Stichtag, Basis 2010
}

/* ---- Förder-Konstanten 2026 ---- */
export const FOERDER = {
  beg_grundquote: 0.15, // BAFA BEG EM Gebäudehülle
  isfp_bonus: 0.05, // +5 Prozentpunkte
  ff_kosten_pro_we_ohne_isfp: 30_000,
  ff_kosten_pro_we_mit_isfp: 60_000,
  isfp_zuschuss_quote: 0.5,
  isfp_zuschuss_max_mfh: 850, // ab 3 WE
  isfp_zuschuss_max_efh: 650,
  isfp_ev_bonus: 250, // Eigentümerversammlung (MFH)
  kfw_heizung_grund: 0.3,
  kfw_heizung_max: 0.7,
} as const;

/* ---- Kostenkennwerte 2026 (€/Einheit), marktübliche Mitte ---- */
const KENNWERT = {
  ogd_daemmung_pro_m2: 56, // oberste Geschossdecke
  fassade_wdvs_pro_m2: 180,
  fenster_pro_stueck: 950, // 3-fach inkl. Montage
  fenster_pro_we: 5, // angenommene Fensterzahl je WE
  heizung_wp_mfh_basis: 38_000,
  heizung_wp_pro_we: 1_500,
  lueftung_wrg_pro_we: 6_500,
};

export interface Massnahme {
  name: string;
  menge: string;
  kosten_min: number;
  kosten_max: number;
  effekt: string;
  foerderstelle: "BAFA" | "KfW";
  isfp_bonus_faehig: boolean;
}

export interface ReportModell {
  objekt: {
    bezeichnung: string;
    adresse: string;
    nutzung: string;
    wohneinheiten: number;
    bgf_m2: number;
    baujahr: string;
    heizung: string;
  };
  einordnung: {
    effizienzklasse_schaetzung: string;
    endenergie_spanne: string;
    bewertung: { bauteil: string; ist: string; bewertung: string; ampel: "rot" | "gelb" | "gruen" }[];
  };
  massnahmen: Massnahme[];
  kosten_summe_min: number;
  kosten_summe_max: number;
  isfp: {
    ff_kosten_ohne: number;
    ff_kosten_mit: number;
    quote_ohne: number;
    quote_mit: number;
    beispiel_massnahme: string;
    beispiel_kosten: number;
    beispiel_foerderung_ohne: number;
    beispiel_foerderung_mit: number;
    beispiel_mehrfoerderung: number;
    erstellung_zuschuss_text: string;
  };
  foerderwege: { massnahme: string; stelle: string; konditionen: string }[];
  hinweise: string[];
}

function nutzungLabel(n: string): string {
  return n === "wohngebaeude" ? "Wohngebäude"
    : n === "nichtwohngebaeude" ? "Nichtwohngebäude" : "Mischgebäude (Wohnen + Gewerbe)";
}

/** Heuristik: Effizienzklasse aus Baualter & Heizung ableiten (Schätzung). */
function schaetzeEffizienz(baujahr: number | null | undefined, heizung: string | null | undefined) {
  const alt = !baujahr || baujahr < 1979; // vor 1. WSchV
  const fossil = !heizung || /gas|öl|oel|fern|brennwert|niedertemp/i.test(heizung || "");
  if (alt && fossil) return { klasse: "E–G", spanne: "ca. 130–200 kWh/(m²·a)" };
  if (alt) return { klasse: "D–F", spanne: "ca. 100–160 kWh/(m²·a)" };
  return { klasse: "C–E", spanne: "ca. 80–130 kWh/(m²·a)" };
}

export function baueReportModell(g: GebaeudeInput): ReportModell {
  const we = g.wohneinheiten ?? 1;
  const bgf = g.bgf_m2 ?? g.wohnflaeche_m2 ?? 100;
  const ueberbaut = g.ueberbaute_flaeche_m2 ?? Math.round(bgf / Math.max(1, 3));
  const hoehe = g.mittlere_hoehe_m ?? 9;

  // Fassadenfläche grob: Umfang (aus überbauter Fläche, quadratisch genähert) × Höhe, minus Öffnungen
  const kantenlaenge = Math.sqrt(Math.max(1, ueberbaut));
  const umfang = kantenlaenge * 4;
  const fassade_netto = Math.round(umfang * hoehe * 0.75);

  const eff = schaetzeEffizienz(g.baujahr, g.heizung_traeger);

  // Maßnahmen + Kostenschätzung (±15 % Spanne)
  const fassadeKosten = fassade_netto * KENNWERT.fassade_wdvs_pro_m2;
  const ogdKosten = ueberbaut * KENNWERT.ogd_daemmung_pro_m2;
  const fensterStk = we * KENNWERT.fenster_pro_we;
  const fensterKosten = fensterStk * KENNWERT.fenster_pro_stueck;
  const heizungKosten = KENNWERT.heizung_wp_mfh_basis + we * KENNWERT.heizung_wp_pro_we;
  const lueftungKosten = we * KENNWERT.lueftung_wrg_pro_we;

  const span = (v: number) => ({ min: Math.round((v * 0.85) / 1000) * 1000, max: Math.round((v * 1.15) / 1000) * 1000 });

  const m = (name: string, menge: string, basis: number, effekt: string, stelle: "BAFA" | "KfW", bonus: boolean): Massnahme => {
    const s = span(basis);
    return { name, menge, kosten_min: s.min, kosten_max: s.max, effekt, foerderstelle: stelle, isfp_bonus_faehig: bonus };
  };

  const massnahmen: Massnahme[] = [
    m("Dämmung oberste Geschossdecke", `~${ueberbaut} m²`, ogdKosten, "schnell, günstig, hohe Wirkung", "BAFA", true),
    m("Fassadendämmung (WDVS)", `~${fassade_netto} m²`, fassadeKosten, "größter Wärmeverlust-Hebel", "BAFA", true),
    m("Fenstertausch (3-fach)", `~${fensterStk} Stk.`, fensterKosten, "Komfort, U-Wert", "BAFA", true),
    m("Heizungstausch (Wärmepumpe)", "1 Anlage", heizungKosten, "Kern der Dekarbonisierung", "KfW", false),
    m("Lüftung mit Wärmerückgewinnung", `${we} WE`, lueftungKosten, "Feuchteschutz nach Dämmung", "BAFA", true),
  ];
  const kosten_summe_min = massnahmen.reduce((s, x) => s + x.kosten_min, 0);
  const kosten_summe_max = massnahmen.reduce((s, x) => s + x.kosten_max, 0);

  // iSFP-Hebel
  const ff_ohne = FOERDER.ff_kosten_pro_we_ohne_isfp * we;
  const ff_mit = FOERDER.ff_kosten_pro_we_mit_isfp * we;
  const beispiel = massnahmen[1]; // Fassade
  const beispielKosten = Math.round((beispiel.kosten_min + beispiel.kosten_max) / 2);
  const foerderungOhne = Math.round(beispielKosten * FOERDER.beg_grundquote);
  const foerderungMit = Math.round(beispielKosten * (FOERDER.beg_grundquote + FOERDER.isfp_bonus));

  const isfpMax = we >= 3 ? FOERDER.isfp_zuschuss_max_mfh : FOERDER.isfp_zuschuss_max_efh;
  const evText = we >= 3 ? ` (+${FOERDER.isfp_ev_bonus} € EV-Bonus)` : "";

  return {
    objekt: {
      bezeichnung: nutzungLabel(g.nutzung),
      adresse: [g.strasse, [g.plz, g.ort].filter(Boolean).join(" ")].filter(Boolean).join(", ") || "—",
      nutzung: nutzungLabel(g.nutzung),
      wohneinheiten: we,
      bgf_m2: bgf,
      baujahr: g.baujahr ? String(g.baujahr) : "keine Angabe",
      heizung: g.heizung_traeger || "keine Angabe",
    },
    einordnung: {
      effizienzklasse_schaetzung: eff.klasse,
      endenergie_spanne: eff.spanne,
      bewertung: [
        { bauteil: "Außenwände", ist: "Mauerwerk, Anstrich", bewertung: "keine erkennbare Dämmung", ampel: "rot" },
        { bauteil: "Dach / oberste Geschossdecke", ist: "Spitzdach, nicht ausgebaut", bewertung: "vermutlich ungedämmt", ampel: "rot" },
        { bauteil: "Fenster", ist: "Ein-/Zweifachverglasung", bewertung: "energetisch veraltet", ampel: "rot" },
        { bauteil: "Heizung", ist: g.heizung_traeger || "fossil", bewertung: "fossil, mittlerer Stand", ampel: "gelb" },
      ],
    },
    massnahmen,
    kosten_summe_min,
    kosten_summe_max,
    isfp: {
      ff_kosten_ohne: ff_ohne,
      ff_kosten_mit: ff_mit,
      quote_ohne: FOERDER.beg_grundquote,
      quote_mit: FOERDER.beg_grundquote + FOERDER.isfp_bonus,
      beispiel_massnahme: beispiel.name,
      beispiel_kosten: beispielKosten,
      beispiel_foerderung_ohne: foerderungOhne,
      beispiel_foerderung_mit: foerderungMit,
      beispiel_mehrfoerderung: foerderungMit - foerderungOhne,
      erstellung_zuschuss_text: `50 % Zuschuss, max. ${isfpMax} €${evText}`,
    },
    foerderwege: [
      { massnahme: "Gebäudehülle (Dämmung, Fenster)", stelle: "BAFA (BEG EM)", konditionen: "15 % + 5 % iSFP-Bonus; ff. Kosten bis 60.000 €/WE mit iSFP" },
      { massnahme: "Heizungstausch (Wärmepumpe)", stelle: "KfW (Programm 458)", konditionen: "30 % Grund + Boni, bis 70 %" },
      { massnahme: "iSFP-Erstellung", stelle: "BAFA (EBW)", konditionen: `50 % Zuschuss, max. ${isfpMax} €${evText}` },
      { massnahme: "Fachplanung / Baubegleitung", stelle: "BAFA", konditionen: "50 % Zuschuss auf Experten-Honorar" },
    ],
    hinweise: [
      "Der zugrunde liegende Wertreport ermittelt den Versicherungswert, nicht den energetischen Zustand. Die energetischen Kennwerte sind Schätzungen aus den baulichen Merkmalen, keine Messwerte.",
      "Kostenschätzungen sind marktübliche Richtwerte (Preisniveau 2026), keine Angebote. Eine Vor-Ort-Begehung durch eine dena-gelistete Fachperson ist für verbindliche Werte erforderlich.",
      "Der iSFP-Bonus gilt nicht für den Heizungstausch (KfW). Förderanträge müssen vor Auftragsvergabe gestellt werden.",
      "Förderkonditionen Stand 2026; vor Antragstellung an der amtlichen Quelle prüfen.",
    ],
  };
}
