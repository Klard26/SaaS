import Fastify from "fastify";
import cors from "@fastify/cors";
import { pool } from "./db/pool.js";
import { finderRoutes } from "./routes/finder.js";
import { detailRoutes } from "./routes/detail.js";
import { matchingRoutes } from "./routes/matching.js";
import { assistentRoutes } from "./routes/assistent.js";
import { energieausweisRoutes } from "./routes/energieausweis.js";
import { vorgangRoutes } from "./routes/vorgang.js";
import { exposeRoutes } from "./routes/expose.js";

const app = Fastify({
  logger: { level: process.env.LOG_LEVEL ?? "info" },
});

await app.register(cors, { origin: true });

// Healthcheck — prüft auch die DB-Verbindung
app.get("/health", async (_req, reply) => {
  try {
    await pool.query("SELECT 1");
    return { status: "ok", db: "verbunden" };
  } catch {
    return reply.code(503).send({ status: "degraded", db: "nicht erreichbar" });
  }
});

// API-Übersicht
app.get("/", async () => ({
  name: "Förderschiene API",
  version: "0.2.0",
  positionierung:
    "Förderprogramm-Navigation für die Immobilienwirtschaft — für Hausverwaltungen, " +
    "Bestandshalter und Immobilienmakler: Förder-Vorgänge je Objekt bündeln, " +
    "Unterlagen kontextbezogen verwalten, Exposés erstellen.",
  endpunkte: [
    "GET  /health",
    "GET  /api/programme            — Finder mit Filtern",
    "GET  /api/filter-optionen      — verfügbare Filterwerte",
    "GET  /api/programme/:id        — Programm-Detail (inkl. Antragspfad)",
    "GET  /api/programme/:id/antragspfad — nur die Schritte",
    "POST /api/match                — Profil-Matching",
    "POST /api/dokument/entwurf     — Dokument-Assistent (optional)",
    "GET  /api/energieausweis/typ-weiche — GModG-Ausweistyp bestimmen",
    "POST /api/energieausweis        — Gebäude + Ausweis anlegen",
    "POST /api/energieausweis/:id/erfassung — Datenerfassung speichern",
    "GET  /api/energieausweis/:id    — Ausweis-Detail",
    "GET  /api/energieausweis/:id/foerder-anschluss — Funnel: passende Förderung",
    "POST /api/energieausweis/:id/foerder-anschluss — Funnel-Verknüpfungen erzeugen",
    "GET  /api/energieausweis/:id/report.pdf — energetischer Report als PDF",
    "POST /api/energieausweis/report-vorschau.pdf — Report-PDF aus Direkteingabe",
    "— Für Hausverwaltungen / Bestandshalter / Makler (B2B2C):",
    "POST /api/vorgaenge            — Förder-Vorgang anlegen (je Objekt)",
    "GET  /api/vorgaenge            — Vorgangs-Übersicht inkl. Doku-Vollständigkeit",
    "GET  /api/vorgaenge/:id        — Vorgang-Detail (Nachrichten + Dokumente)",
    "PATCH /api/vorgaenge/:id/status — Status-Workflow",
    "POST /api/vorgaenge/:id/nachrichten — Multi-Channel-Eingang (E-Mail/WhatsApp/…)",
    "POST /api/vorgaenge/:id/dokumente — Dokument mit Kontextzuordnung",
    "GET  /api/vorgaenge/:id/checkliste — Pflichtunterlagen-Abgleich",
    "PATCH /api/dokumente/:id/pruefen — Dokument freigeben",
    "— Für Makler (Exposé, PLANFLUX-Stil):",
    "POST /api/expose               — Exposé anlegen (inkl. Energie-Pflichtangaben)",
    "GET  /api/expose/:id           — Exposé abrufen",
    "POST /api/expose/aus-objekt/:objektId — Exposé aus Objektdaten vorbefüllen",
  ],
}));

await app.register(finderRoutes);
await app.register(detailRoutes);
await app.register(matchingRoutes);
await app.register(assistentRoutes);
await app.register(energieausweisRoutes);
await app.register(vorgangRoutes);
await app.register(exposeRoutes);

const port = Number(process.env.PORT ?? 3000);
const host = process.env.HOST ?? "0.0.0.0";

try {
  await app.listen({ port, host });
  app.log.info(`Förderpilot API läuft auf http://${host}:${port}`);
} catch (err) {
  app.log.error(err);
  process.exit(1);
}

// Sauberes Herunterfahren
for (const sig of ["SIGINT", "SIGTERM"] as const) {
  process.on(sig, async () => {
    app.log.info(`${sig} empfangen — fahre herunter`);
    await app.close();
    await pool.end();
    process.exit(0);
  });
}
