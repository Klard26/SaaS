import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";
import type { Expose } from "../lib/vorgang-types.js";

const IdParam = z.object({ id: z.string().uuid() });

const ExposeBody = z.object({
  objekt_id: z.string().uuid().optional(),
  organisation_id: z.string().uuid().optional(),
  titel: z.string().min(1),
  wohnflaeche_m2: z.number().nonnegative().optional(),
  zimmer: z.number().nonnegative().optional(),
  kaufpreis_eur: z.number().nonnegative().optional(),
  energie_kennwert_kwh_m2a: z.number().nonnegative().optional(),
  energie_klasse: z.string().optional(),
  energietraeger: z.string().optional(),
  beschreibung: z.string().optional(),
});

/**
 * Erzeugt einen einfachen, sachlichen Exposé-Fließtext aus den Eckdaten.
 * Bewusst regelbasiert (kein LLM nötig); kann später durch den
 * Dokument-Assistenten ersetzt/ergänzt werden.
 */
function baueBeschreibung(e: z.infer<typeof ExposeBody>): string {
  const teile: string[] = [];
  teile.push(`${e.titel}.`);
  if (e.wohnflaeche_m2) teile.push(`Die Wohnfläche beträgt ca. ${e.wohnflaeche_m2} m²${e.zimmer ? ` auf ${e.zimmer} Zimmer` : ""}.`);
  if (e.kaufpreis_eur) teile.push(`Der Kaufpreis liegt bei ${e.kaufpreis_eur.toLocaleString("de-DE")} €.`);
  if (e.energie_kennwert_kwh_m2a || e.energie_klasse) {
    const k = e.energie_kennwert_kwh_m2a ? `${e.energie_kennwert_kwh_m2a} kWh/(m²·a)` : "";
    const kl = e.energie_klasse ? `Effizienzklasse ${e.energie_klasse}` : "";
    teile.push(`Energetische Angaben: ${[k, kl].filter(Boolean).join(", ")}${e.energietraeger ? `, Energieträger ${e.energietraeger}` : ""}.`);
  }
  return teile.join(" ");
}

export async function exposeRoutes(app: FastifyInstance) {
  /**
   * POST /api/expose — Exposé anlegen. Erzeugt automatisch einen Beschreibungstext,
   * falls keiner mitgegeben wird. Energetische Pflichtangaben werden mit erfasst.
   */
  app.post("/api/expose", async (req, reply) => {
    const b = ExposeBody.safeParse(req.body);
    if (!b.success) return reply.code(400).send({ error: "Ungültige Exposé-Daten", details: b.error.issues });
    const e = b.data;

    // Pflichtangaben-Hinweis: Energieausweis-Kennwerte sind in Immobilienanzeigen vorgeschrieben
    const fehlendePflicht: string[] = [];
    if (!e.energie_kennwert_kwh_m2a && !e.energie_klasse) fehlendePflicht.push("Energiekennwert/Effizienzklasse");
    if (!e.energietraeger) fehlendePflicht.push("wesentlicher Energieträger");

    const beschreibung = e.beschreibung ?? baueBeschreibung(e);

    const expose = await queryOne<Expose>(
      `INSERT INTO expose (objekt_id, organisation_id, titel, wohnflaeche_m2, zimmer,
                           kaufpreis_eur, energie_kennwert_kwh_m2a, energie_klasse,
                           energietraeger, beschreibung)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING id, objekt_id, titel, status, wohnflaeche_m2, zimmer, kaufpreis_eur,
                 energie_kennwert_kwh_m2a, energie_klasse, energietraeger, beschreibung`,
      [e.objekt_id ?? null, e.organisation_id ?? null, e.titel, e.wohnflaeche_m2 ?? null,
       e.zimmer ?? null, e.kaufpreis_eur ?? null, e.energie_kennwert_kwh_m2a ?? null,
       e.energie_klasse ?? null, e.energietraeger ?? null, beschreibung]
    );

    return reply.code(201).send({
      expose,
      pflichtangaben_hinweis: fehlendePflicht.length
        ? `Achtung: In Immobilienanzeigen sind diese Angaben vorgeschrieben und fehlen noch: ${fehlendePflicht.join(", ")}.`
        : "Alle energetischen Pflichtangaben vorhanden.",
    });
  });

  /** GET /api/expose/:id — Exposé abrufen */
  app.get("/api/expose/:id", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Exposé-ID" });
    const expose = await queryOne<Expose>(
      `SELECT id, objekt_id, titel, status, wohnflaeche_m2, zimmer, kaufpreis_eur,
              energie_kennwert_kwh_m2a, energie_klasse, energietraeger, beschreibung
       FROM expose WHERE id = $1`, [pid.data.id]
    );
    if (!expose) return reply.code(404).send({ error: "Exposé nicht gefunden" });
    return expose;
  });

  /**
   * POST /api/expose/aus-objekt/:objektId — Exposé direkt aus einem Objekt
   * (und ggf. dessen Energieausweis) vorbefüllen. Brücke Objekt → Exposé.
   */
  app.post("/api/expose/aus-objekt/:objektId", async (req, reply) => {
    const p = z.object({ objektId: z.string().uuid() }).safeParse(req.params);
    if (!p.success) return reply.code(400).send({ error: "Ungültige Objekt-ID" });

    const objekt = await queryOne<{ bezeichnung: string; wohneinheiten: number | null; organisation_id: string | null }>(
      "SELECT bezeichnung, wohneinheiten, organisation_id FROM objekt WHERE id = $1",
      [p.data.objektId]
    );
    if (!objekt) return reply.code(404).send({ error: "Objekt nicht gefunden" });

    const titel = `${objekt.bezeichnung} — Exposé`;
    const beschreibung = baueBeschreibung({ titel });
    const expose = await queryOne<Expose>(
      `INSERT INTO expose (objekt_id, organisation_id, titel, beschreibung)
       VALUES ($1,$2,$3,$4)
       RETURNING id, objekt_id, titel, status, wohnflaeche_m2, zimmer, kaufpreis_eur,
                 energie_kennwert_kwh_m2a, energie_klasse, energietraeger, beschreibung`,
      [p.data.objektId, objekt.organisation_id, titel, beschreibung]
    );
    return reply.code(201).send({
      expose,
      hinweis: "Exposé-Entwurf aus Objektdaten erstellt. Energetische Pflichtangaben vor Veröffentlichung ergänzen.",
    });
  });
}
