import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";
import type { Vorgang, VorgangUebersicht, Dokument } from "../lib/vorgang-types.js";

const IdParam = z.object({ id: z.string().uuid() });

const VorgangBody = z.object({
  organisation_id: z.string().uuid().optional(),
  objekt_id: z.string().uuid().optional(),
  programm_id: z.string().uuid().optional(),
  nutzer_id: z.string().uuid().optional(),
  berater_id: z.string().uuid().optional(),
  titel: z.string().min(1),
  faellig_am: z.string().optional(), // ISO-Datum
});

const StatusBody = z.object({
  status: z.enum([
    "neu", "in_pruefung", "unterlagen_offen", "antrag_gestellt",
    "bewilligt", "abgelehnt", "abgeschlossen",
  ]),
});

const NachrichtBody = z.object({
  kanal: z.enum(["web", "email", "whatsapp", "telefon", "post", "intern"]),
  richtung: z.enum(["eingehend", "ausgehend"]).default("eingehend"),
  von: z.string().optional(),
  inhalt: z.string().min(1),
});

const DokumentBody = z.object({
  dateiname: z.string().min(1),
  mime_typ: z.string().optional(),
  speicher_pfad: z.string().optional(),
  ebene: z.enum(["organisation", "objekt", "vorgang", "antragsschritt", "pflichtunterlage"]).default("vorgang"),
  objekt_id: z.string().uuid().optional(),
  antragsschritt_id: z.string().uuid().optional(),
  pflichtunterlage_id: z.string().uuid().optional(),
  freigabe_rolle: z.string().optional(),
});

export async function vorgangRoutes(app: FastifyInstance) {
  /** POST /api/vorgaenge — neuen Förder-Vorgang anlegen */
  app.post("/api/vorgaenge", async (req, reply) => {
    const b = VorgangBody.safeParse(req.body);
    if (!b.success) return reply.code(400).send({ error: "Ungültige Vorgangsdaten", details: b.error.issues });
    const v = b.data;
    const vorgang = await queryOne<Vorgang>(
      `INSERT INTO vorgang (organisation_id, objekt_id, programm_id, nutzer_id, berater_id, titel, faellig_am)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [v.organisation_id ?? null, v.objekt_id ?? null, v.programm_id ?? null,
       v.nutzer_id ?? null, v.berater_id ?? null, v.titel, v.faellig_am ?? null]
    );
    return reply.code(201).send(vorgang);
  });

  /**
   * GET /api/vorgaenge — Übersicht (optional je Organisation), inkl.
   * Dokument-Vollständigkeit (Pflichtunterlagen Soll/Ist).
   */
  app.get("/api/vorgaenge", async (req, reply) => {
    const q = z.object({
      organisation_id: z.string().uuid().optional(),
      status: z.string().optional(),
    }).safeParse(req.query);
    if (!q.success) return reply.code(400).send({ error: "Ungültige Filter" });

    const where: string[] = [];
    const params: unknown[] = [];
    const p = (x: unknown) => { params.push(x); return `$${params.length}`; };
    if (q.data.organisation_id) where.push(`v.id IN (SELECT id FROM vorgang WHERE organisation_id = ${p(q.data.organisation_id)})`);
    if (q.data.status) where.push(`v.status = ${p(q.data.status)}`);
    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const rows = await query<VorgangUebersicht>(
      `SELECT * FROM v_vorgang_uebersicht v ${whereSql} ORDER BY v.aktualisiert_am DESC`,
      params
    );
    return { anzahl: rows.length, vorgaenge: rows };
  });

  /** GET /api/vorgaenge/:id — Detail mit Nachrichten und Dokumenten */
  app.get("/api/vorgaenge/:id", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Vorgang-ID" });

    const vorgang = await queryOne<VorgangUebersicht>(
      "SELECT * FROM v_vorgang_uebersicht WHERE id = $1", [pid.data.id]
    );
    if (!vorgang) return reply.code(404).send({ error: "Vorgang nicht gefunden" });

    const [nachrichten, dokumente] = await Promise.all([
      query("SELECT kanal, richtung, von, inhalt, erstellt_am FROM vorgang_nachricht WHERE vorgang_id = $1 ORDER BY erstellt_am", [pid.data.id]),
      query<Dokument>("SELECT id, ebene, dateiname, mime_typ, geprueft, pflichtunterlage_id FROM dokument WHERE vorgang_id = $1 ORDER BY erstellt_am", [pid.data.id]),
    ]);
    return { ...vorgang, nachrichten, dokumente };
  });

  /** PATCH /api/vorgaenge/:id/status — Statuswechsel (Workflow) */
  app.patch("/api/vorgaenge/:id/status", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    const b = StatusBody.safeParse(req.body);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Vorgang-ID" });
    if (!b.success) return reply.code(400).send({ error: "Ungültiger Status", details: b.error.issues });
    const updated = await queryOne<Vorgang>(
      "UPDATE vorgang SET status = $2 WHERE id = $1 RETURNING *",
      [pid.data.id, b.data.status]
    );
    if (!updated) return reply.code(404).send({ error: "Vorgang nicht gefunden" });
    return updated;
  });

  /**
   * POST /api/vorgaenge/:id/nachrichten — Multi-Channel-Eingang.
   * Jeder Kanal (E-Mail/WhatsApp/Telefon/Post/Web) landet im selben Vorgang.
   */
  app.post("/api/vorgaenge/:id/nachrichten", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    const b = NachrichtBody.safeParse(req.body);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Vorgang-ID" });
    if (!b.success) return reply.code(400).send({ error: "Ungültige Nachricht", details: b.error.issues });

    const exists = await queryOne<{ id: string }>("SELECT id FROM vorgang WHERE id = $1", [pid.data.id]);
    if (!exists) return reply.code(404).send({ error: "Vorgang nicht gefunden" });

    const n = b.data;
    const nachricht = await queryOne(
      `INSERT INTO vorgang_nachricht (vorgang_id, kanal, richtung, von, inhalt)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [pid.data.id, n.kanal, n.richtung, n.von ?? null, n.inhalt]
    );
    return reply.code(201).send(nachricht);
  });

  /**
   * POST /api/vorgaenge/:id/dokumente — Dokument mit Kontextzuordnung.
   * Das Facilioo-Kernmuster: das Dokument wird automatisch der richtigen
   * Ebene zugeordnet (Objekt/Vorgang/Schritt/Pflichtunterlage), mit Prüfstatus.
   */
  app.post("/api/vorgaenge/:id/dokumente", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    const b = DokumentBody.safeParse(req.body);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Vorgang-ID" });
    if (!b.success) return reply.code(400).send({ error: "Ungültiges Dokument", details: b.error.issues });

    const exists = await queryOne<{ id: string }>("SELECT id FROM vorgang WHERE id = $1", [pid.data.id]);
    if (!exists) return reply.code(404).send({ error: "Vorgang nicht gefunden" });

    const d = b.data;
    const dok = await queryOne<Dokument>(
      `INSERT INTO dokument (vorgang_id, ebene, objekt_id, antragsschritt_id, pflichtunterlage_id,
                             dateiname, mime_typ, speicher_pfad, freigabe_rolle)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING id, vorgang_id, ebene, dateiname, mime_typ, geprueft, pflichtunterlage_id`,
      [pid.data.id, d.ebene, d.objekt_id ?? null, d.antragsschritt_id ?? null,
       d.pflichtunterlage_id ?? null, d.dateiname, d.mime_typ ?? null,
       d.speicher_pfad ?? null, d.freigabe_rolle ?? null]
    );
    return reply.code(201).send(dok);
  });

  /** PATCH /api/dokumente/:id/pruefen — Dokument als geprüft markieren (Freigabe) */
  app.patch("/api/dokumente/:id/pruefen", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Dokument-ID" });
    const dok = await queryOne<Dokument>(
      "UPDATE dokument SET geprueft = TRUE WHERE id = $1 RETURNING id, vorgang_id, ebene, dateiname, mime_typ, geprueft, pflichtunterlage_id",
      [pid.data.id]
    );
    if (!dok) return reply.code(404).send({ error: "Dokument nicht gefunden" });
    return dok;
  });

  /**
   * GET /api/vorgaenge/:id/checkliste — Pflichtunterlagen-Abgleich.
   * Zeigt, welche Pflichtunterlagen des Programms noch fehlen (der wunde Punkt).
   */
  app.get("/api/vorgaenge/:id/checkliste", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Vorgang-ID" });

    const rows = await query<{ id: string; bezeichnung: string; pflicht: boolean; vorhanden: boolean; geprueft: boolean }>(
      `SELECT pu.id, pu.bezeichnung, pu.pflicht,
              EXISTS(SELECT 1 FROM dokument d WHERE d.vorgang_id = $1 AND d.pflichtunterlage_id = pu.id) AS vorhanden,
              EXISTS(SELECT 1 FROM dokument d WHERE d.vorgang_id = $1 AND d.pflichtunterlage_id = pu.id AND d.geprueft) AS geprueft
       FROM pflichtunterlage pu
       JOIN vorgang v ON v.programm_id = pu.programm_id
       WHERE v.id = $1
       ORDER BY pu.pflicht DESC, pu.bezeichnung`,
      [pid.data.id]
    );
    const offen = rows.filter((r) => r.pflicht && !r.geprueft).length;
    return { ausweis_vollstaendig: offen === 0, offen, unterlagen: rows };
  });
}
