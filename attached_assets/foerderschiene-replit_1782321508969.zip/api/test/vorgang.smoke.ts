/**
 * Smoke-Test für die Vorgang-/Dokument-/Exposé-Erweiterung (Facilioo-Muster).
 * Lauf: node --import tsx test/vorgang.smoke.ts
 */
import { strict as assert } from "node:assert";

const captured: { text: string; params: unknown[] }[] = [];

function fakeResultFor(text: string, params: unknown[]): unknown[] {
  // Vorgang anlegen
  if (text.includes("INSERT INTO vorgang"))
    return [{ id: "a1111111-1111-1111-1111-111111111111", titel: params[5], status: "neu" }];
  // Vorgang existiert?
  if (text.includes("SELECT id FROM vorgang")) return [{ id: params[0] }];
  // Übersicht
  if (text.includes("FROM v_vorgang_uebersicht") && text.includes("ORDER BY"))
    return [{ id: "v1", titel: "Fassade", status: "unterlagen_offen", organisation: "Muster HV", organisation_typ: "hausverwaltung", pflicht_soll: 3, pflicht_ist: 1, nachrichten: 2 }];
  if (text.includes("FROM v_vorgang_uebersicht WHERE id"))
    return [{ id: params[0], titel: "Fassade", status: "unterlagen_offen", pflicht_soll: 3, pflicht_ist: 1 }];
  // Nachrichten / Dokumente Detail
  if (text.includes("FROM vorgang_nachricht WHERE vorgang_id"))
    return [{ kanal: "whatsapp", richtung: "eingehend", von: "+49170", inhalt: "Foto" }];
  if (text.includes("FROM dokument WHERE vorgang_id"))
    return [{ id: "d1", ebene: "pflichtunterlage", dateiname: "rechnung.pdf", geprueft: false }];
  // Status-Update
  if (text.includes("UPDATE vorgang SET status"))
    return [{ id: params[0], status: params[1], titel: "Fassade" }];
  // Nachricht anlegen
  if (text.includes("INSERT INTO vorgang_nachricht"))
    return [{ id: "n1", kanal: params[1], inhalt: params[4] }];
  // Dokument anlegen
  if (text.includes("INSERT INTO dokument"))
    return [{ id: "d1", ebene: params[1], dateiname: params[5], geprueft: false, pflichtunterlage_id: params[4] }];
  // Dokument prüfen
  if (text.includes("UPDATE dokument SET geprueft"))
    return [{ id: params[0], geprueft: true, dateiname: "rechnung.pdf" }];
  // Checkliste
  if (text.includes("FROM pflichtunterlage pu"))
    return [
      { id: "pu1", bezeichnung: "Rechnung", pflicht: true, vorhanden: true, geprueft: true },
      { id: "pu2", bezeichnung: "Fachunternehmererklärung", pflicht: true, vorhanden: false, geprueft: false },
    ];
  // Exposé anlegen
  if (text.includes("INSERT INTO expose") && text.includes("RETURNING"))
    return [{ id: "e1", titel: params[2], status: "entwurf", beschreibung: params[9] ?? params[3] }];
  if (text.includes("SELECT bezeichnung, wohneinheiten, organisation_id FROM objekt"))
    return [{ bezeichnung: "MFH Kanzlerstr. 8", wohneinheiten: 6, organisation_id: "o1" }];
  return [];
}

const mockPool = {
  query: async (text: string, params: unknown[] = []) => { captured.push({ text, params }); return { rows: fakeResultFor(text, params) }; },
  on: () => {}, end: async () => {},
};
const pg = await import("pg");
(pg.default as unknown as { Pool: unknown }).Pool = function () { return mockPool; } as unknown as never;

const { default: Fastify } = await import("fastify");
const { vorgangRoutes } = await import("../src/routes/vorgang.js");
const { exposeRoutes } = await import("../src/routes/expose.js");
const app = Fastify();
await app.register(vorgangRoutes);
await app.register(exposeRoutes);

let passed = 0;
const ok = (n: string) => { passed++; console.log(`  ✓ ${n}`); };
const VID = "a1111111-1111-1111-1111-111111111111";

// 1. Vorgang anlegen
{
  const res = await app.inject({ method: "POST", url: "/api/vorgaenge", payload: { titel: "Fassadendämmung Kanzlerstr. 8" } });
  assert.equal(res.statusCode, 201);
  assert.equal(res.json().titel, "Fassadendämmung Kanzlerstr. 8");
  ok("POST /api/vorgaenge (Vorgang anlegen)");
}
// 2. Übersicht inkl. Doku-Vollständigkeit
{
  const res = await app.inject({ method: "GET", url: "/api/vorgaenge" });
  assert.equal(res.statusCode, 200);
  const v = res.json().vorgaenge[0];
  assert.equal(v.pflicht_soll, 3); assert.equal(v.pflicht_ist, 1);
  ok("GET /api/vorgaenge (Übersicht mit Pflicht-Soll/Ist)");
}
// 3. Multi-Channel-Nachricht
{
  const res = await app.inject({ method: "POST", url: `/api/vorgaenge/${VID}/nachrichten`, payload: { kanal: "whatsapp", inhalt: "Foto der Außenwand" } });
  assert.equal(res.statusCode, 201);
  const last = captured.find((c) => c.text.includes("INSERT INTO vorgang_nachricht"));
  assert.ok(last && last.params.includes("whatsapp"), "WhatsApp-Kanal gebunden");
  ok("POST /:id/nachrichten (Multi-Channel-Eingang)");
}
// 4. Dokument mit Kontextzuordnung
{
  const res = await app.inject({ method: "POST", url: `/api/vorgaenge/${VID}/dokumente`, payload: { dateiname: "rechnung.pdf", ebene: "pflichtunterlage", pflichtunterlage_id: "aaaaaaaa-1111-1111-1111-111111111111" } });
  assert.equal(res.statusCode, 201);
  assert.equal(res.json().ebene, "pflichtunterlage", "Dokument der Pflichtunterlage zugeordnet");
  ok("POST /:id/dokumente (Kontextzuordnung)");
}
// 5. Statuswechsel
{
  const res = await app.inject({ method: "PATCH", url: `/api/vorgaenge/${VID}/status`, payload: { status: "antrag_gestellt" } });
  assert.equal(res.statusCode, 200);
  assert.equal(res.json().status, "antrag_gestellt");
  ok("PATCH /:id/status (Workflow)");
}
// 6. Checkliste Pflichtunterlagen
{
  const res = await app.inject({ method: "GET", url: `/api/vorgaenge/${VID}/checkliste` });
  assert.equal(res.statusCode, 200);
  const b = res.json();
  assert.equal(b.offen, 1, "eine Pflichtunterlage noch offen");
  assert.equal(b.ausweis_vollstaendig, false);
  ok("GET /:id/checkliste (Pflichtunterlagen-Abgleich)");
}
// 7. Exposé mit Pflichtangaben-Warnung
{
  const res = await app.inject({ method: "POST", url: "/api/expose", payload: { titel: "3-Zi-Wohnung Berlin", wohnflaeche_m2: 78, zimmer: 3, kaufpreis_eur: 420000 } });
  assert.equal(res.statusCode, 201);
  const b = res.json();
  assert.ok(b.pflichtangaben_hinweis.includes("vorgeschrieben"), "Warnung bei fehlenden Energie-Pflichtangaben");
  ok("POST /api/expose (Exposé + Pflichtangaben-Prüfung)");
}
// 8. Exposé aus Objekt vorbefüllen
{
  const res = await app.inject({ method: "POST", url: "/api/expose/aus-objekt/bbbbbbbb-1111-1111-1111-111111111111" });
  assert.equal(res.statusCode, 201);
  assert.ok(res.json().expose.titel.includes("Kanzlerstr"), "Titel aus Objekt übernommen");
  ok("POST /api/expose/aus-objekt/:id (Objekt → Exposé)");
}

console.log(`\n${passed} Vorgang/Exposé-Tests bestanden.`);
await app.close();
process.exit(0);
