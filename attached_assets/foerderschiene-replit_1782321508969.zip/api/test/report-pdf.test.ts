/**
 * Erzeugt einen Beispiel-Report-PDF mit den Daten des Duisburg-Gebäudes,
 * um die PDF-Pipeline real zu verifizieren (gültiges PDF, lesbarer Inhalt).
 * Lauf: node --import tsx test/report-pdf.test.ts
 */
import { createWriteStream } from "node:fs";
import { baueReportModell } from "../src/lib/report-modell.js";
import { schreibeReportPdf } from "../src/lib/report-pdf.js";

const duisburg = {
  strasse: "Kanzlerstr. 8",
  plz: "47119",
  ort: "Duisburg-Laar",
  bundesland: "nordrhein_westfalen",
  baujahr: null, // Report: keine Angabe
  nutzung: "mischgebaeude" as const, // nahe an MFH; testet auch Misch-Logik
  wohneinheiten: 6,
  bgf_m2: 630,
  umbauter_raum_m3: 1387,
  ueberbaute_flaeche_m2: 125,
  mittlere_hoehe_m: 12.04,
  heizung_traeger: "Zentral-/Fernheizung (Brennwert)",
  baupreisindex: 1.886,
};

const modell = baueReportModell(duisburg);

console.log("Modell-Eckwerte:");
console.log("  Effizienzklasse (Schätzung):", modell.einordnung.effizienzklasse_schaetzung);
console.log("  Maßnahmen:", modell.massnahmen.length);
console.log("  Kostensumme:", modell.kosten_summe_min.toLocaleString("de-DE"), "–", modell.kosten_summe_max.toLocaleString("de-DE"), "€");
console.log("  iSFP ff.Kosten ohne/mit:", modell.isfp.ff_kosten_ohne.toLocaleString("de-DE"), "/", modell.isfp.ff_kosten_mit.toLocaleString("de-DE"), "€");
console.log("  iSFP Mehrförderung (Beispiel):", modell.isfp.beispiel_mehrfoerderung.toLocaleString("de-DE"), "€");

const out = "/tmp/energiereport-duisburg.pdf";
const stream = createWriteStream(out);
stream.on("finish", () => {
  console.log("\n✓ PDF geschrieben:", out);
});
schreibeReportPdf(modell, stream);
