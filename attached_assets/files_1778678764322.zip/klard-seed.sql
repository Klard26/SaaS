-- ═══════════════════════════════════════════════════════════════
-- Klard Leistungskatalog — PostgreSQL Seed Script
-- Generated: 2026-05-13 11:48
-- Target: Supabase / PostgreSQL
-- ═══════════════════════════════════════════════════════════════

-- ┌─────────────────────────────────────────────────────────────┐
-- │ SCHEMA — uncomment if tables don't exist yet                │
-- └─────────────────────────────────────────────────────────────┘

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Branches (8 Berufsgruppen)
CREATE TABLE IF NOT EXISTS branches (
    id                       TEXT PRIMARY KEY,
    name                     TEXT NOT NULL,
    icon                     TEXT,
    description              TEXT,
    color                    TEXT,
    color_light              TEXT,
    requires_dena            BOOLEAN DEFAULT FALSE,
    requires_hoai            BOOLEAN DEFAULT FALSE,
    requires_kammer          TEXT,
    requires_oebvi           BOOLEAN DEFAULT FALSE,
    requires_zertifizierung  BOOLEAN DEFAULT FALSE,
    display_order            INT,
    qualifications           JSONB,
    created_at               TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Service Categories (Leistungsgruppen pro Branche)
CREATE TABLE IF NOT EXISTS service_categories (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    branch_id     TEXT NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    display_order INT,
    UNIQUE (branch_id, name)
);
CREATE INDEX IF NOT EXISTS idx_cat_branch ON service_categories(branch_id);

-- 3. Service Templates (vorausgefüllte Leistungen)
CREATE TABLE IF NOT EXISTS service_templates (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category_id     UUID NOT NULL REFERENCES service_categories(id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    price_type      TEXT NOT NULL CHECK (price_type IN ('fix','hr','pa','hoai','on')),
    duration        TEXT,
    reference_price TEXT,
    display_order   INT
);
CREATE INDEX IF NOT EXISTS idx_svc_cat ON service_templates(category_id);

-- 4. Providers (Anbieter)
CREATE TABLE IF NOT EXISTS providers (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    branch_id        TEXT REFERENCES branches(id),
    company_name     TEXT NOT NULL,
    email            TEXT NOT NULL UNIQUE,
    phone            TEXT,
    plz              TEXT,
    city             TEXT,
    experience_years INT,
    description      TEXT,
    -- Energieberater specific
    dena_id          TEXT,
    dena_since       INT,
    dena_categories  TEXT[],
    dena_programs    TEXT[],
    -- Architekt/Statiker/TGA
    kammer_state     TEXT,
    kammer_id        TEXT,
    bauvorlage       BOOLEAN DEFAULT FALSE,
    pruefingenieur   BOOLEAN DEFAULT FALSE,
    -- Vermesser
    is_oebvi         BOOLEAN DEFAULT FALSE,
    oebvi_state      TEXT,
    oebvi_id         TEXT,
    -- Sachverständige
    is_oebuv         BOOLEAN DEFAULT FALSE,
    iso_17024        BOOLEAN DEFAULT FALSE,
    specialties      TEXT[],
    -- Meta
    online_available BOOLEAN DEFAULT TRUE,
    response_time    TEXT,
    certificates     TEXT[],
    is_verified      BOOLEAN DEFAULT FALSE,
    is_active        BOOLEAN DEFAULT TRUE,
    created_at       TIMESTAMPTZ DEFAULT NOW(),
    updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Provider Services (eigene Preise je Anbieter)
CREATE TABLE IF NOT EXISTS provider_services (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider_id         UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    service_template_id UUID REFERENCES service_templates(id),
    custom_name         TEXT,  -- für eigene Leistungen ohne Template
    price               TEXT NOT NULL,
    price_type          TEXT NOT NULL,
    duration            TEXT,
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_psvc_provider ON provider_services(provider_id);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ SEED DATA — 8 Branchen, 28 Kategorien, 153 Leistungen        │
-- └─────────────────────────────────────────────────────────────┘

-- Cleanup (optional — comment out in production)
DELETE FROM service_templates;
DELETE FROM service_categories;
DELETE FROM branches;

-- ── BRANCHES ──────────────────────────────────────────────────
INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order, qualifications) VALUES
  ('enb', 'Energieberatung', '⚡', 'Qualifizierte Energieberatung nach BAFA/KfW-Standards', '#D97706', '#FEF3C7', TRUE, FALSE, NULL, FALSE, FALSE, 1, '{"dena_required": true, "dena_categories": ["wg", "nwg", "ap", "kfn", "denkmal"], "dena_programs": ["bafa-ebw", "bafa-ebn", "beg-wg", "beg-nwg", "beg-em", "kfw-kfn", "kfw-kfg", "dgnb-qng"], "notes": "Ab 01.01.2027 ist die dena-Listung Pflicht für alle BAFA-Anträge. Grundqualifikation: Hochschulabschluss/Meister/Techniker + dena-Basismodul (80–160 UE)."}'::jsonb);

INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order, qualifications) VALUES
  ('arc', 'Architektur', '📐', 'Architektenleistungen nach HOAI (alle 9 Leistungsphasen)', '#1B2A3B', '#F1F5F9', FALSE, TRUE, 'architekt', FALSE, FALSE, 2, '{"kammer_required": true, "kammer_type": "architekt", "bauvorlage_required": true, "notes": "Eintragung Architektenkammer (bundeslandspezifisch). Bauvorlageberechtigung für eigenständige Bauantragseinreichung."}'::jsonb);

INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order, qualifications) VALUES
  ('sta', 'Statiker / Tragwerksplaner', '🏗️', 'Tragwerksplanung nach HOAI § 51 (Bauingenieure)', '#185FA5', '#E6F1FB', FALSE, TRUE, 'ingenieur', FALSE, FALSE, 3, '{"kammer_required": true, "kammer_type": "ingenieur", "notes": "Eintragung Ingenieurkammer. Bauingenieur-Diplom/Master. Bauvorlageberechtigung Tragwerksplanung (länderspezifisch). Optional: Öffentlich bestellter Prüfingenieur für Standsicherheit."}'::jsonb);

INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order, qualifications) VALUES
  ('bau', 'Bauberatung / Baubegleitung', '👷', 'Unabhängige Bauberatung, Baubegleitung, Bauleitung', '#993C1D', '#FAECE7', FALSE, FALSE, NULL, FALSE, FALSE, 4, '{"notes": "Architekt, Bauingenieur, Bautechniker oder Baumeister. Berufserfahrung in Baudurchführung/Bauleitung empfohlen."}'::jsonb);

INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order, qualifications) VALUES
  ('sac', 'Gebäudesachverständige', '🔍', 'Gutachten, Bewertungen, Schäden, Wertermittlungen', '#7C3AED', '#EDE9FE', FALSE, FALSE, NULL, FALSE, TRUE, 5, '{"zertifizierung_required": true, "options": ["öbuv", "din-iso-17024"], "specialties": ["bewertung", "schaeden", "feuchte", "schadstoff", "schall", "brand"], "notes": "Öffentliche Bestellung & Vereidigung (ö.b.u.v.) oder zertifizierter Sachverständiger nach DIN EN ISO/IEC 17024. Spezialgebiete abfragen."}'::jsonb);

INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order, qualifications) VALUES
  ('vrm', 'Vermesser / Geodäten', '📏', 'Vermessung, Lagepläne, ÖbVI-Leistungen für Bauanträge', '#059669', '#D1FAE5', FALSE, FALSE, NULL, TRUE, FALSE, 6, '{"oebvi_optional": true, "notes": "Öffentlich bestellter Vermessungsingenieur (ÖbVI) für hoheitliche Aufgaben. Master/Diplom Vermessungswesen/Geodäsie/Geoinformatik."}'::jsonb);

INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order, qualifications) VALUES
  ('tga', 'TGA-Fachplaner', '🔧', 'Technische Gebäudeausrüstung nach HOAI § 55: Heizung, Lüftung, Sanitär, Elektro', '#993556', '#FBEAF0', FALSE, TRUE, 'ingenieur', FALSE, FALSE, 7, '{"kammer_required": true, "kammer_type": "ingenieur", "fachbereiche": ["heizung", "lueftung", "sanitaer", "elektro", "msr", "aufzuege"], "notes": "Ingenieurkammer-Eintragung. Bauingenieur/Versorgungstechniker/Gebäudeenergieberater. Fachbereiche abfragen."}'::jsonb);

INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order, qualifications) VALUES
  ('bps', 'Bauphysik & Spezialberatung', '🔊', 'Schallschutz, Brandschutz, Schadstoffe, Bauphysik', '#0E7490', '#CFFAFE', FALSE, FALSE, 'ingenieur', FALSE, FALSE, 8, '{"kammer_required": true, "kammer_type": "ingenieur", "specialties": ["schallschutz", "brandschutz", "schadstoffe", "bauphysik"], "notes": "Bauingenieur mit Vertiefung. Brandschutzsachverständiger: Ingenieurkammer + Sachkundenachweis. Schadstoffsachverständiger: TRGS 519/521."}'::jsonb);

-- ── SERVICE CATEGORIES + TEMPLATES (single transaction per branch) ──

-- Energieberatung (enb)
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('enb', 'BAFA-Beratungsprogramme', 1),
    ('enb', 'BEG / KfW Fördermittel und Fachplanung', 2),
    ('enb', 'Ingenieurleistungen', 3),
    ('enb', 'Weitere Energie-Leistungen', 4)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, reference_price, display_order)
  SELECT id, 'BAFA-Energieberatung Wohngebäude (EBW)', 'fix', 'ca. 1 Tag', 'ab 1.450 €', 1
  FROM cat_inserts WHERE name = 'BAFA-Beratungsprogramme'
UNION ALL
  SELECT id, 'BAFA-Energieberatung Nichtwohngebäude (EBN)', 'on', 'individuell', 'auf Anfrage', 2
  FROM cat_inserts WHERE name = 'BAFA-Beratungsprogramme'
UNION ALL
  SELECT id, 'Energieaudit nach DIN EN 16247', 'on', 'individuell', 'auf Anfrage', 3
  FROM cat_inserts WHERE name = 'BAFA-Beratungsprogramme'
UNION ALL
  SELECT id, 'Energieberatung nach DIN V 18599', 'on', 'individuell', 'auf Anfrage', 4
  FROM cat_inserts WHERE name = 'BAFA-Beratungsprogramme'
UNION ALL
  SELECT id, 'Contracting-Orientierungsberatung', 'fix', 'ca. 4–6h', 'ab 890 €', 5
  FROM cat_inserts WHERE name = 'BAFA-Beratungsprogramme'
UNION ALL
  SELECT id, 'BEG Wohngebäude (BEG WG) – Planung & Begleitung', 'pa', 'projektbezogen', 'ab 2.490 €', 1
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'BEG Nichtwohngebäude (BEG NWG)', 'pa', 'projektbezogen', 'ab 3.990 €', 2
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'BEG Einzelmaßnahmen (BEG EM) Wohn-/Nichtwohngebäude', 'fix', 'ca. 3–4h', 'ab 590 €', 3
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Energieeffizient Bauen & Sanieren WG', 'pa', 'projektbezogen', 'ab 2.290 €', 4
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Baudenkmal Wohngebäude (Effizienzhaus Denkmal)', 'pa', 'projektbezogen', 'ab 2.890 €', 5
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Energieeffizient Bauen & Sanieren NWG', 'pa', 'projektbezogen', 'ab 3.490 €', 6
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Baudenkmal Nichtwohngebäude', 'pa', 'projektbezogen', 'ab 3.990 €', 7
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Klimafreundlicher Neubau (KFN) Wohngebäude', 'pa', 'projektbezogen', 'ab 1.890 €', 8
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Klimafreundlicher Neubau (KFN) Nichtwohngebäude', 'pa', 'projektbezogen', 'ab 2.890 €', 9
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'DGNB-Auditor – Planung & Begleitung QNG', 'pa', 'projektbezogen', 'ab 4.500 €', 10
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'Individueller Sanierungsfahrplan (iSFP)', 'fix', 'ca. 1 Tag', 'ab 1.450 €', 11
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'BAFA-Antrag Heizungsanlage (Wärmepumpe, Solar)', 'fix', 'ca. 3h', 'ab 390 €', 12
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'Energiebedarfsausweis Wohngebäude (nach GEG)', 'fix', 'ca. 2h', 'ab 299 €', 1
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Energieverbrauchsausweis Wohngebäude', 'fix', 'ca. 30 Min.', 'ab 99 €', 2
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Energiebedarfsausweis Nichtwohngebäude', 'fix', 'individuell', 'ab 490 €', 3
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Energieverbrauchsausweis Nichtwohngebäude', 'fix', 'individuell', 'ab 290 €', 4
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Wärmeschutznachweis nach GEG', 'fix', 'individuell', 'ab 390 €', 5
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Nachweis sommerlicher Wärmeschutz', 'fix', 'individuell', 'ab 290 €', 6
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Raumweise Heizlastberechnung (DIN EN 12831)', 'fix', 'individuell', 'ab 390 €', 7
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Hydraulischer Abgleich (Berechnung & Nachweis)', 'fix', 'ca. 1 Tag', 'ab 490 €', 8
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Lüftungskonzept nach DIN 1946-6', 'fix', 'individuell', 'ab 350 €', 9
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Kostenkalkulation nach DIN 276', 'on', 'individuell', 'auf Anfrage', 10
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Thermografieanalyse Gebäude', 'fix', 'Halbtag', 'ab 490 €', 1
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen'
UNION ALL
  SELECT id, 'Heizungscheck / Heizungsoptimierung', 'fix', 'ca. 2h', 'ab 190 €', 2
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen'
UNION ALL
  SELECT id, 'Photovoltaik-Wirtschaftlichkeitsberechnung', 'fix', 'ca. 2h', 'ab 290 €', 3
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen'
UNION ALL
  SELECT id, 'Energieberatung Gewerbe / Industrie', 'hr', 'pro Stunde', 'ab 150 €/h', 4
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen'
UNION ALL
  SELECT id, 'CO2-Bilanz Unternehmen', 'pa', 'individuell', 'ab 890 €', 5
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen'
UNION ALL
  SELECT id, 'Erstberatung Energieeffizienz', 'fix', 'ca. 1h', 'ab 89 €', 6
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen';


-- Architektur (arc)
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('arc', 'HOAI-Leistungsphasen Gebäudeplanung (§ 34)', 1),
    ('arc', 'Pauschalangebote', 2),
    ('arc', 'Einzelberatung', 3)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, reference_price, display_order)
  SELECT id, 'LPH 1 – Grundlagenermittlung', 'hoai', '2 % HOAI', 'nach HOAI', 1
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34)'
UNION ALL
  SELECT id, 'LPH 2 – Vorplanung (Vorentwurf)', 'hoai', '7 % HOAI', 'nach HOAI', 2
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34)'
UNION ALL
  SELECT id, 'LPH 3 – Entwurfsplanung', 'hoai', '15 % HOAI', 'nach HOAI', 3
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34)'
UNION ALL
  SELECT id, 'LPH 4 – Genehmigungsplanung / Bauantrag', 'hoai', '3 % HOAI', 'nach HOAI', 4
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34)'
UNION ALL
  SELECT id, 'LPH 5 – Ausführungsplanung (Werkplanung)', 'hoai', '25 % HOAI', 'nach HOAI', 5
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34)'
UNION ALL
  SELECT id, 'LPH 6 – Vorbereitung der Vergabe (Massenermittlung, LV)', 'hoai', '10 % HOAI', 'nach HOAI', 6
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34)'
UNION ALL
  SELECT id, 'LPH 7 – Mitwirkung bei der Vergabe', 'hoai', '4 % HOAI', 'nach HOAI', 7
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34)'
UNION ALL
  SELECT id, 'LPH 8 – Objektüberwachung (Bauleitung) & Dokumentation', 'hoai', '32 % HOAI', 'nach HOAI', 8
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34)'
UNION ALL
  SELECT id, 'LPH 9 – Objektbetreuung in der Gewährleistungsphase', 'hoai', '2 % HOAI', 'nach HOAI', 9
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34)'
UNION ALL
  SELECT id, 'Komplette Planung Einfamilienhaus (LPH 1–9)', 'pa', '6–18 Monate', '~ 12–15 % der Bausumme', 1
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Bauantrag-Erstellung Wohnhaus (LPH 1–4)', 'pa', '6–12 Wochen', 'ab 4.900 €', 2
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Sanierungsplanung Wohngebäude', 'pa', 'individuell', 'ab 3.900 €', 3
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Anbau / Aufstockung Planung', 'pa', 'individuell', 'ab 2.900 €', 4
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Innenarchitektur-Konzept (komplette Wohnung)', 'pa', '4–8 Wochen', 'ab 1.890 €', 5
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, '3D-Visualisierung (pro Raum)', 'fix', 'pro Raum', 'ab 290 €', 6
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Erstberatung Bauvorhaben', 'fix', 'ca. 1,5h', 'ab 190 €', 1
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'Bauvoranfrage erstellen', 'fix', 'ca. 4h', 'ab 490 €', 2
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'Machbarkeitsstudie Grundstück', 'fix', 'ca. 1 Tag', 'ab 890 €', 3
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'Bestandsaufnahme & Aufmaß', 'hr', 'pro Stunde', 'ab 95 €/h', 4
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'Architektenberatung allgemein (Stundensatz)', 'hr', 'pro Stunde', 'ab 110 €/h', 5
  FROM cat_inserts WHERE name = 'Einzelberatung';


-- Statiker / Tragwerksplaner (sta)
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('sta', 'HOAI Tragwerksplanung (§ 51)', 1),
    ('sta', 'Pauschalangebote', 2),
    ('sta', 'Einzelnachweise & Prüfungen', 3),
    ('sta', 'Einzelberatung', 4)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, reference_price, display_order)
  SELECT id, 'LPH 1 – Grundlagenermittlung', 'hoai', '3 % HOAI', 'nach HOAI', 1
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51)'
UNION ALL
  SELECT id, 'LPH 2 – Vorplanung', 'hoai', '10 % HOAI', 'nach HOAI', 2
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51)'
UNION ALL
  SELECT id, 'LPH 3 – Entwurfsplanung', 'hoai', '15 % HOAI', 'nach HOAI', 3
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51)'
UNION ALL
  SELECT id, 'LPH 4 – Genehmigungsplanung (Standsicherheitsnachweis)', 'hoai', '30 % HOAI', 'nach HOAI', 4
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51)'
UNION ALL
  SELECT id, 'LPH 5 – Ausführungsplanung (Schal-/Bewehrungspläne)', 'hoai', '40 % HOAI', 'nach HOAI', 5
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51)'
UNION ALL
  SELECT id, 'LPH 6 – Vorbereitung der Vergabe', 'hoai', '2 % HOAI', 'nach HOAI', 6
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51)'
UNION ALL
  SELECT id, 'Statik Einfamilienhaus (komplett)', 'pa', '3–6 Wochen', 'ab 2.490 €', 1
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Statik Anbau / Aufstockung', 'pa', '2–4 Wochen', 'ab 1.490 €', 2
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Statik Mehrfamilienhaus', 'pa', '6–12 Wochen', 'ab 4.890 €', 3
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Bewehrungsplanung (Stahlbeton)', 'pa', 'individuell', 'ab 890 €', 4
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Standsicherheitsnachweis (Einzelposition)', 'fix', 'ca. 1 Tag', 'ab 490 €', 1
  FROM cat_inserts WHERE name = 'Einzelnachweise & Prüfungen'
UNION ALL
  SELECT id, 'Statische Berechnung Wanddurchbruch', 'fix', 'ca. 4h', 'ab 390 €', 2
  FROM cat_inserts WHERE name = 'Einzelnachweise & Prüfungen'
UNION ALL
  SELECT id, 'Statische Berechnung Decken-/Wandöffnung', 'fix', 'ca. 4–6h', 'ab 490 €', 3
  FROM cat_inserts WHERE name = 'Einzelnachweise & Prüfungen'
UNION ALL
  SELECT id, 'Schadensgutachten Tragwerk', 'pa', 'individuell', 'ab 890 €', 4
  FROM cat_inserts WHERE name = 'Einzelnachweise & Prüfungen'
UNION ALL
  SELECT id, 'Statische Prüfung Bestandsgebäude', 'pa', 'individuell', 'ab 690 €', 5
  FROM cat_inserts WHERE name = 'Einzelnachweise & Prüfungen'
UNION ALL
  SELECT id, 'Statiker-Erstberatung', 'fix', 'ca. 1h', 'ab 150 €', 1
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'Statiker-Beratung (Stundensatz)', 'hr', 'pro Stunde', 'ab 110 €/h', 2
  FROM cat_inserts WHERE name = 'Einzelberatung';


-- Bauberatung / Baubegleitung (bau)
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('bau', 'Baubegleitung & Bauüberwachung', 1),
    ('bau', 'Qualitätsprüfung & Abnahme', 2),
    ('bau', 'Beratung & Vertragsprüfung', 3)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, reference_price, display_order)
  SELECT id, 'Baubegleitung Einfamilienhaus (gesamter Bau)', 'pa', '6–18 Monate', 'ab 4.900 €', 1
  FROM cat_inserts WHERE name = 'Baubegleitung & Bauüberwachung'
UNION ALL
  SELECT id, 'Baubegleitung Sanierung (komplett)', 'pa', 'individuell', 'ab 3.490 €', 2
  FROM cat_inserts WHERE name = 'Baubegleitung & Bauüberwachung'
UNION ALL
  SELECT id, 'Bauüberwachung pro Baubesprechung', 'fix', '2–3h', 'ab 290 €', 3
  FROM cat_inserts WHERE name = 'Baubegleitung & Bauüberwachung'
UNION ALL
  SELECT id, 'Bauleitung (Stundensatz)', 'hr', 'pro Stunde', 'ab 95 €/h', 4
  FROM cat_inserts WHERE name = 'Baubegleitung & Bauüberwachung'
UNION ALL
  SELECT id, 'Baufortschrittsprüfung mit Bericht', 'fix', 'ca. 3h', 'ab 390 €', 1
  FROM cat_inserts WHERE name = 'Qualitätsprüfung & Abnahme'
UNION ALL
  SELECT id, 'Bauabnahme Wohnhaus (mit Protokoll)', 'fix', 'ca. 3h', 'ab 490 €', 2
  FROM cat_inserts WHERE name = 'Qualitätsprüfung & Abnahme'
UNION ALL
  SELECT id, 'Abnahme Eigentumswohnung (Übergabe vom Bauträger)', 'fix', 'ca. 2h', 'ab 350 €', 3
  FROM cat_inserts WHERE name = 'Qualitätsprüfung & Abnahme'
UNION ALL
  SELECT id, 'Mängelaufnahme & Mängelbeseitigungsprüfung', 'fix', 'ca. 2–3h', 'ab 290 €', 4
  FROM cat_inserts WHERE name = 'Qualitätsprüfung & Abnahme'
UNION ALL
  SELECT id, 'Bauvertrag prüfen (Bauträger / Generalunternehmer)', 'fix', 'ca. 2h', 'ab 290 €', 1
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung'
UNION ALL
  SELECT id, 'LV-Prüfung (Leistungsverzeichnis)', 'fix', 'ca. 2–4h', 'ab 390 €', 2
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung'
UNION ALL
  SELECT id, 'Erstberatung Bauvorhaben', 'fix', 'ca. 1,5h', 'ab 150 €', 3
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung'
UNION ALL
  SELECT id, 'Kostenkalkulation nach DIN 276', 'fix', 'individuell', 'ab 590 €', 4
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung'
UNION ALL
  SELECT id, 'Wirtschaftlichkeitsberechnung Bauprojekt', 'fix', 'individuell', 'ab 690 €', 5
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung'
UNION ALL
  SELECT id, 'Bauberatung allgemein (Stundensatz)', 'hr', 'pro Stunde', 'ab 95 €/h', 6
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung';


-- Gebäudesachverständige (sac)
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('sac', 'Verkehrswert & Bewertung', 1),
    ('sac', 'Schadens- & Mängelgutachten', 2),
    ('sac', 'Erwerbs- & Abnahmebegleitung', 3),
    ('sac', 'Spezialgutachten', 4)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, reference_price, display_order)
  SELECT id, 'Verkehrswertgutachten Wohnimmobilie (kurz)', 'fix', 'ca. 1 Tag', 'ab 490 €', 1
  FROM cat_inserts WHERE name = 'Verkehrswert & Bewertung'
UNION ALL
  SELECT id, 'Verkehrswertgutachten Wohnimmobilie (ausführlich)', 'fix', 'individuell', 'ab 1.490 €', 2
  FROM cat_inserts WHERE name = 'Verkehrswert & Bewertung'
UNION ALL
  SELECT id, 'Verkehrswertgutachten Gewerbeimmobilie', 'pa', 'individuell', 'ab 2.490 €', 3
  FROM cat_inserts WHERE name = 'Verkehrswert & Bewertung'
UNION ALL
  SELECT id, 'Marktwertindikation (Kurzgutachten ohne Vor-Ort)', 'fix', 'ca. 2h', 'ab 290 €', 4
  FROM cat_inserts WHERE name = 'Verkehrswert & Bewertung'
UNION ALL
  SELECT id, 'Beleihungswertgutachten', 'pa', 'individuell', 'ab 990 €', 5
  FROM cat_inserts WHERE name = 'Verkehrswert & Bewertung'
UNION ALL
  SELECT id, 'Schimmelpilzgutachten', 'fix', 'ca. 4h', 'ab 590 €', 1
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Feuchtigkeitsgutachten', 'fix', 'ca. 4h', 'ab 590 €', 2
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Bauschadengutachten (Risse, Setzungen, Mängel)', 'pa', 'individuell', 'ab 890 €', 3
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Gerichtsgutachten Bauschäden', 'on', 'individuell', 'auf Anfrage', 4
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Wasserschadensgutachten', 'fix', 'individuell', 'ab 590 €', 5
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Beweissicherungsgutachten Nachbarschaftsstreit', 'pa', 'individuell', 'ab 890 €', 6
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Hauskaufbegleitung (Begehung & Mängelbericht)', 'fix', 'ca. 3h', 'ab 490 €', 1
  FROM cat_inserts WHERE name = 'Erwerbs- & Abnahmebegleitung'
UNION ALL
  SELECT id, 'Erwerbsgutachten Bestandsimmobilie', 'fix', 'ca. 1 Tag', 'ab 790 €', 2
  FROM cat_inserts WHERE name = 'Erwerbs- & Abnahmebegleitung'
UNION ALL
  SELECT id, 'Abnahme Eigentumswohnung Neubau', 'fix', 'ca. 2h', 'ab 350 €', 3
  FROM cat_inserts WHERE name = 'Erwerbs- & Abnahmebegleitung'
UNION ALL
  SELECT id, 'Bauabnahme Einfamilienhaus', 'fix', 'ca. 3h', 'ab 490 €', 4
  FROM cat_inserts WHERE name = 'Erwerbs- & Abnahmebegleitung'
UNION ALL
  SELECT id, 'Wohnflächenberechnung (Wohnflächenverordnung)', 'fix', 'ca. 1–2h', 'ab 190 €', 5
  FROM cat_inserts WHERE name = 'Erwerbs- & Abnahmebegleitung'
UNION ALL
  SELECT id, 'Schadstoffgutachten (Asbest, PCB, KMF)', 'pa', 'individuell', 'ab 690 €', 1
  FROM cat_inserts WHERE name = 'Spezialgutachten'
UNION ALL
  SELECT id, 'Lärm- & Schallschutzgutachten', 'pa', 'individuell', 'ab 790 €', 2
  FROM cat_inserts WHERE name = 'Spezialgutachten'
UNION ALL
  SELECT id, 'Sachverständigen-Beratung (Stundensatz)', 'hr', 'pro Stunde', 'ab 130 €/h', 3
  FROM cat_inserts WHERE name = 'Spezialgutachten';


-- Vermesser / Geodäten (vrm)
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('vrm', 'Amtliche Vermessung (ÖbVI)', 1),
    ('vrm', 'Ingenieurvermessung & Bauvermessung', 2),
    ('vrm', 'Lagepläne & Topografie', 3)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, reference_price, display_order)
  SELECT id, 'Grenzfeststellung / Grenzherstellung', 'pa', 'individuell', 'ab 990 €', 1
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI)'
UNION ALL
  SELECT id, 'Teilungsvermessung (Grundstücksteilung)', 'pa', 'individuell', 'ab 1.490 €', 2
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI)'
UNION ALL
  SELECT id, 'Gebäudeeinmessung (für Liegenschaftskataster)', 'fix', 'ca. 1 Tag', 'ab 490 €', 3
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI)'
UNION ALL
  SELECT id, 'Amtlicher Lageplan zum Bauantrag', 'fix', 'ca. 1–2 Wochen', 'ab 590 €', 4
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI)'
UNION ALL
  SELECT id, 'Höhenfestlegung / Höhenbolzen', 'fix', 'ca. 1 Tag', 'ab 290 €', 5
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI)'
UNION ALL
  SELECT id, 'Grenzbescheinigung', 'fix', 'ca. 4h', 'ab 250 €', 6
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI)'
UNION ALL
  SELECT id, 'Absteckung Bauwerk (Achsabsteckung)', 'fix', 'ca. 1 Tag', 'ab 490 €', 1
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, 'Schnurgerüst erstellen', 'fix', 'ca. 4h', 'ab 290 €', 2
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, 'Bestandsaufmaß Gebäude (für Planung)', 'pa', 'individuell', 'ab 690 €', 3
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, '3D-Laserscanning Gebäude', 'pa', 'individuell', 'ab 1.490 €', 4
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, 'Drohnenbefliegung / Photogrammetrie', 'pa', 'individuell', 'ab 890 €', 5
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, 'Setzungs- & Verformungsmessung', 'pa', 'individuell', 'ab 590 €', 6
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, 'Topografische Geländeaufnahme', 'pa', 'individuell', 'ab 690 €', 1
  FROM cat_inserts WHERE name = 'Lagepläne & Topografie'
UNION ALL
  SELECT id, 'Höhenplan / Geländeschnitt', 'fix', 'ca. 1 Tag', 'ab 390 €', 2
  FROM cat_inserts WHERE name = 'Lagepläne & Topografie'
UNION ALL
  SELECT id, 'Wegerechts- & Dienstbarkeitsplan', 'fix', 'individuell', 'ab 490 €', 3
  FROM cat_inserts WHERE name = 'Lagepläne & Topografie'
UNION ALL
  SELECT id, 'Vermesserberatung (Stundensatz)', 'hr', 'pro Stunde', 'ab 110 €/h', 4
  FROM cat_inserts WHERE name = 'Lagepläne & Topografie';


-- TGA-Fachplaner (tga)
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('tga', 'HOAI Technische Ausrüstung (§ 55)', 1),
    ('tga', 'Heizungs- & Lüftungsplanung', 2),
    ('tga', 'Sanitär- & Elektroplanung', 3),
    ('tga', 'Einzelberatung', 4)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, reference_price, display_order)
  SELECT id, 'LPH 1 – Grundlagenermittlung (TGA)', 'hoai', '2 % HOAI', 'nach HOAI', 1
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55)'
UNION ALL
  SELECT id, 'LPH 2 – Vorplanung (TGA)', 'hoai', '9 % HOAI', 'nach HOAI', 2
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55)'
UNION ALL
  SELECT id, 'LPH 3 – Entwurfsplanung (TGA)', 'hoai', '17 % HOAI', 'nach HOAI', 3
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55)'
UNION ALL
  SELECT id, 'LPH 4 – Genehmigungsplanung (TGA)', 'hoai', '2 % HOAI', 'nach HOAI', 4
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55)'
UNION ALL
  SELECT id, 'LPH 5 – Ausführungsplanung (TGA)', 'hoai', '22 % HOAI', 'nach HOAI', 5
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55)'
UNION ALL
  SELECT id, 'LPH 6 – Vorbereitung der Vergabe (TGA)', 'hoai', '7 % HOAI', 'nach HOAI', 6
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55)'
UNION ALL
  SELECT id, 'LPH 7 – Mitwirkung bei der Vergabe (TGA)', 'hoai', '5 % HOAI', 'nach HOAI', 7
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55)'
UNION ALL
  SELECT id, 'LPH 8 – Objektüberwachung (TGA)', 'hoai', '35 % HOAI', 'nach HOAI', 8
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55)'
UNION ALL
  SELECT id, 'Heizlastberechnung & Heizungsauslegung', 'fix', 'ca. 1–2 Tage', 'ab 690 €', 1
  FROM cat_inserts WHERE name = 'Heizungs- & Lüftungsplanung'
UNION ALL
  SELECT id, 'Wärmepumpen-Planung & Dimensionierung', 'fix', 'ca. 2 Tage', 'ab 990 €', 2
  FROM cat_inserts WHERE name = 'Heizungs- & Lüftungsplanung'
UNION ALL
  SELECT id, 'Lüftungsplanung kontrollierte Wohnraumlüftung', 'fix', 'ca. 1 Tag', 'ab 590 €', 3
  FROM cat_inserts WHERE name = 'Heizungs- & Lüftungsplanung'
UNION ALL
  SELECT id, 'Klima-/Kälteanlagenplanung Gewerbe', 'pa', 'individuell', 'ab 1.490 €', 4
  FROM cat_inserts WHERE name = 'Heizungs- & Lüftungsplanung'
UNION ALL
  SELECT id, 'Hydraulischer Abgleich (Berechnung & Planung)', 'fix', 'ca. 1 Tag', 'ab 490 €', 5
  FROM cat_inserts WHERE name = 'Heizungs- & Lüftungsplanung'
UNION ALL
  SELECT id, 'Sanitärplanung Einfamilienhaus', 'pa', 'individuell', 'ab 890 €', 1
  FROM cat_inserts WHERE name = 'Sanitär- & Elektroplanung'
UNION ALL
  SELECT id, 'Elektroplanung Wohngebäude (Stromkreise, Verteilung)', 'pa', 'individuell', 'ab 990 €', 2
  FROM cat_inserts WHERE name = 'Sanitär- & Elektroplanung'
UNION ALL
  SELECT id, 'Photovoltaikplanung & Auslegung', 'fix', 'ca. 1 Tag', 'ab 490 €', 3
  FROM cat_inserts WHERE name = 'Sanitär- & Elektroplanung'
UNION ALL
  SELECT id, 'E-Mobilität-/Wallbox-Konzept', 'fix', 'ca. 4h', 'ab 290 €', 4
  FROM cat_inserts WHERE name = 'Sanitär- & Elektroplanung'
UNION ALL
  SELECT id, 'TGA-Erstberatung', 'fix', 'ca. 1,5h', 'ab 150 €', 1
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'TGA-Beratung (Stundensatz)', 'hr', 'pro Stunde', 'ab 120 €/h', 2
  FROM cat_inserts WHERE name = 'Einzelberatung';


-- Bauphysik & Spezialberatung (bps)
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('bps', 'Schallschutznachweise', 1),
    ('bps', 'Brandschutz', 2),
    ('bps', 'Schadstoff- & Umweltgutachten', 3),
    ('bps', 'Bauphysik', 4)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, reference_price, display_order)
  SELECT id, 'Schallschutznachweis Wohngebäude (DIN 4109)', 'fix', 'ca. 1 Tag', 'ab 490 €', 1
  FROM cat_inserts WHERE name = 'Schallschutznachweise'
UNION ALL
  SELECT id, 'Schallschutznachweis Nichtwohngebäude', 'pa', 'individuell', 'ab 890 €', 2
  FROM cat_inserts WHERE name = 'Schallschutznachweise'
UNION ALL
  SELECT id, 'Raumakustik-Konzept (Gewerbe)', 'pa', 'individuell', 'ab 690 €', 3
  FROM cat_inserts WHERE name = 'Schallschutznachweise'
UNION ALL
  SELECT id, 'Bauakustische Messung vor Ort', 'fix', 'Halbtag', 'ab 590 €', 4
  FROM cat_inserts WHERE name = 'Schallschutznachweise'
UNION ALL
  SELECT id, 'Brandschutzkonzept Wohngebäude', 'pa', 'individuell', 'ab 990 €', 1
  FROM cat_inserts WHERE name = 'Brandschutz'
UNION ALL
  SELECT id, 'Brandschutzkonzept Sonderbau / Gewerbe', 'pa', 'individuell', 'ab 2.490 €', 2
  FROM cat_inserts WHERE name = 'Brandschutz'
UNION ALL
  SELECT id, 'Brandschutznachweis für Bauantrag', 'fix', 'individuell', 'ab 690 €', 3
  FROM cat_inserts WHERE name = 'Brandschutz'
UNION ALL
  SELECT id, 'Flucht- & Rettungswegplan', 'fix', 'individuell', 'ab 390 €', 4
  FROM cat_inserts WHERE name = 'Brandschutz'
UNION ALL
  SELECT id, 'Asbest-Erkundung (vor Sanierung/Abbruch)', 'fix', 'ca. 4–6h', 'ab 590 €', 1
  FROM cat_inserts WHERE name = 'Schadstoff- & Umweltgutachten'
UNION ALL
  SELECT id, 'PCB-/KMF-Erkundung', 'fix', 'individuell', 'ab 590 €', 2
  FROM cat_inserts WHERE name = 'Schadstoff- & Umweltgutachten'
UNION ALL
  SELECT id, 'Schadstoffkataster Gebäudekomplex', 'pa', 'individuell', 'ab 1.490 €', 3
  FROM cat_inserts WHERE name = 'Schadstoff- & Umweltgutachten'
UNION ALL
  SELECT id, 'Rückbau- & Entsorgungskonzept', 'pa', 'individuell', 'ab 990 €', 4
  FROM cat_inserts WHERE name = 'Schadstoff- & Umweltgutachten'
UNION ALL
  SELECT id, 'Bauphysikalisches Gutachten', 'pa', 'individuell', 'ab 890 €', 1
  FROM cat_inserts WHERE name = 'Bauphysik'
UNION ALL
  SELECT id, 'Feuchteschutznachweis nach DIN 4108', 'fix', 'ca. 4h', 'ab 390 €', 2
  FROM cat_inserts WHERE name = 'Bauphysik'
UNION ALL
  SELECT id, 'Beratung Bauphysik allgemein', 'hr', 'pro Stunde', 'ab 130 €/h', 3
  FROM cat_inserts WHERE name = 'Bauphysik';

-- ┌─────────────────────────────────────────────────────────────┐
-- │ VERIFICATION — Run these to confirm seed worked              │
-- └─────────────────────────────────────────────────────────────┘

-- Check totals
SELECT 'branches' AS table, COUNT(*) FROM branches
UNION ALL SELECT 'categories', COUNT(*) FROM service_categories
UNION ALL SELECT 'services', COUNT(*) FROM service_templates;
-- Expected: 8 branches, 28 categories, 153 services

-- View Energieberatung leistungen with prices
SELECT b.name AS branch, sc.name AS category, st.name AS service,
       st.price_type, st.reference_price
FROM branches b
JOIN service_categories sc ON sc.branch_id = b.id
JOIN service_templates st ON st.category_id = sc.id
WHERE b.id = 'enb'
ORDER BY sc.display_order, st.display_order;
