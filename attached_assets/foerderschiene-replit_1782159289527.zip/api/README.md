# Förderpilot API

Lauffähiges Backend auf dem `foerderpilot`-PostgreSQL-Schema. Liefert die
Kern-Endpunkte der Plattform: Finder, Programm-Detail mit Antragspfad und
Profil-Matching — plus einen optionalen Dokument-Assistenten.

Stack: Node 20+, TypeScript, Fastify, `pg`, Zod.

## Schnellstart

```bash
# 1. Datenbank vorbereiten (einmalig, aus dem Projekt-Hauptordner)
createdb foerderpilot
psql foerderpilot -f ../foerderpilot_schema.sql
psql foerderpilot -f ../foerderpilot_import_generiert.sql   # generierte Daten

# 2. API einrichten
cp .env.example .env        # DATABASE_URL anpassen
npm install
npm run dev                 # Entwicklung mit Auto-Reload
# oder: npm run build && npm start   (Produktion)
```

Server läuft dann auf `http://localhost:3000`. Übersicht unter `GET /`.

## Endpunkte

| Methode | Pfad | Zweck |
|---|---|---|
| GET | `/health` | Statuscheck inkl. DB-Verbindung |
| GET | `/api/programme` | **Finder** mit Filtern + Pagination |
| GET | `/api/filter-optionen` | Verfügbare Filterwerte (für UI-Dropdowns) |
| GET | `/api/programme/:id` | **Detail**: Stammdaten + Antragspfad + Faktoren + Berater |
| GET | `/api/programme/:id/antragspfad` | Nur die Schritt-für-Schritt-Anleitung |
| POST | `/api/match` | **Profil-Matching** (Förder-Schnellcheck) |
| POST | `/api/dokument/entwurf` | Dokument-Assistent (optional, braucht API-Key) |

### Energieausweis-Modul

| Methode | Pfad | Zweck |
|---|---|---|
| GET | `/api/energieausweis/typ-weiche` | **GModG-Ausweistyp** bestimmen (nutzung, baujahr, wohneinheiten) |
| POST | `/api/energieausweis` | Gebäude + Ausweis anlegen (Typ via Weiche) |
| POST | `/api/energieausweis/:id/erfassung` | Datenerfassung speichern (Upsert je Feld) |
| GET | `/api/energieausweis/:id` | Ausweis-Detail (Gebäude, Erfassung, Empfehlungen) |
| GET | `/api/energieausweis/:id/foerder-anschluss` | **Funnel**: passende Förderprogramme |
| POST | `/api/energieausweis/:id/foerder-anschluss` | Funnel-Verknüpfungen erzeugen |
| GET | `/api/energieausweis/:id/report.pdf` | **Energetischer Report als PDF** (dynamisch erzeugt) |
| POST | `/api/energieausweis/report-vorschau.pdf` | Report-PDF direkt aus Gebäudedaten (ohne DB-Eintrag) |

Voraussetzung für das Modul: `energieausweis_schema.sql` ist eingespielt (es
referenziert `foerderpilot`-Tabellen, daher zuerst das Förderpilot-Schema laden).

```bash
psql foerderpilot -f ../energieausweis_schema.sql
```

### Finder-Filter (alle optional, kombinierbar)

`ebene`, `art`, `timing`, `status`, `kategorie` (slug), `zielgruppe` (slug),
`region`, `suche` (Volltext), `nur_aktiv`, `limit`, `offset`.

```bash
# Beispiele
curl "http://localhost:3000/api/programme?ebene=bund&art=zuschuss&kategorie=energie_gebaeude"
curl "http://localhost:3000/api/programme?suche=Heizung&limit=10"
curl "http://localhost:3000/api/programme/<UUID>"

curl -X POST http://localhost:3000/api/match \
  -H 'content-type: application/json' \
  -d '{"zielgruppe":"privat","region":"berlin","kategorien":["energie_gebaeude"]}'
```

## Sicherheit & Design

- **SQL-Injection-sicher**: alle Filter werden parametrisiert ($1, $2, …) gebunden,
  nie per String-Konkatenation.
- **Validierung**: jede Eingabe wird mit Zod gegen die Schema-ENUMs geprüft;
  ungültige Werte → `400` mit Detailmeldung.
- **Ranking**: verifizierte Programme und höhere Erfolgsquoten zuerst.
- **Robust ohne Key**: Der Dokument-Assistent ist optional; fehlt der
  `ANTHROPIC_API_KEY`, antwortet nur dieser eine Endpunkt mit `503`.

## Tests

```bash
node --import tsx test/smoke.ts              # Förderpilot: Routing + Validierung + SQL
node --import tsx test/integration.ts        # Frontend-Mapper passt zur API-Antwort
node --import tsx test/energieausweis.smoke.ts # Energieausweis: Typ-Weiche + Funnel
```

Beide Tests mocken die Datenbank, fahren den echten Server hoch und prüfen
Routing, Validierung, SQL-Zusammenbau (smoke) sowie das Datenformat zwischen
API und HTML-Prototyp (integration) — ohne laufende DB.

## Frontend anbinden

Der HTML-Prototyp (`foerderpilot-prototyp.html`) ist bereits angebunden. Er
prüft beim Start `/health`:

- **API erreichbar** → echte Daten, Badge zeigt „Live-API" (grün).
- **API offline** → eingebaute Demo-Daten, Badge zeigt „Demo" (bernstein).

Die API-Adresse lässt sich überschreiben, bevor das Script lädt:

```html
<script>window.FOERDERPILOT_API = "https://api.foerderpilot.de";</script>
```

Standard ist `http://localhost:3000`. CORS ist serverseitig offen (für die
Entwicklung) — für Produktion in `server.ts` auf die echte Frontend-Domain
einschränken.

## Projektstruktur

```
src/
  server.ts            Einstiegspunkt, registriert Routen
  db/pool.ts           pg-Pool, setzt search_path, query-Helfer
  lib/types.ts         TypeScript-Typen = Spiegel des DB-Schemas
  routes/
    finder.ts          GET /api/programme, /api/filter-optionen
    detail.ts          GET /api/programme/:id (+ /antragspfad)
    matching.ts        POST /api/match
    assistent.ts       POST /api/dokument/entwurf (optional)
test/
  smoke.ts             End-to-End-Test gegen DB-Mock
```
