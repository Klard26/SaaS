# Klard — Paket 2: Dashboard-Tabs + Förder-Affiliate

## Inhalt
- `frontend/dashboard-tabs-anfragen-tarif.html` — zwei neue Dashboard-Tabs
  ("Anfragen" + "Tarif"), einbindbar in dein klard-plattform.html.
  Demo-Modus läuft ohne Backend (Fallback-Daten), Produktiv via window.KLARD_API
  und window.KLARD_PROVIDER_ID.
- `finance/sql/klard-foerder-affiliate.sql` — 5. Umsatzstrom (8 Statements).
- `finance/routes/finance.js` — Förder-Lead-Matching, Weitergabe, Conversion.
- `finance/emails/finance_lead_partner.hbs` — E-Mail an Finanzpartner.
- `foerder-affiliate-konzept.md` — Strategie, Wirtschaftlichkeit, DSGVO.

## Frontend einbinden
1. Die zwei Tab-Buttons (oben in der HTML-Datei kommentiert) in deine
   bestehende Dashboard-Tab-Leiste einfügen.
2. Die zwei <div class="tab-pane"> in den Modal-Body kopieren.
3. <style> + <script> vor </body> einfügen.
4. window.KLARD_API="/api" und window.KLARD_PROVIDER_ID=<session> setzen.

## Affiliate aktivieren
1. psql $DATABASE_URL -f finance/sql/klard-foerder-affiliate.sql
2. finance.js als Router registrieren: app.use("/api", financeRouter)
3. finance_lead_partner.hbs zu deinen Templates legen.
4. Finanzpartner anlegen (INSERT INTO finance_partners ...).
5. Anfrage-Formular um separate Checkbox "Finanzierungsangebote erhalten"
   erweitern → POST /api/requests/:id/finance-share mit consent_finance:true.

## Wichtig (DSGVO)
Die Finanzierungs-Weitergabe braucht eine EIGENE Einwilligung, getrennt von der
Handwerker-Weitergabe. Details im Konzeptdokument. Keine Rechtsberatung —
Einwilligungstexte vor Go-Live anwaltlich prüfen lassen.
