# Klard — Förder-Lead-Affiliate: Der 5. Umsatzstrom

## Die Idee in einem Satz

Jede Anfrage auf Klard, die förderrelevant ist (`funding_relevant = true`), ist
nicht nur ein Auftrag für einen Energieberater — sie ist gleichzeitig ein
hochqualifizierter Lead für eine Finanzierung oder Förderung. Diesen Lead
monetarisierst du ein zweites Mal über Finanzpartner.

## Warum das dein stärkster struktureller Vorteil ist

Du sitzt über Energie Impuls GmbH (dena-gelistet) ohnehin an der Schnittstelle
zwischen Sanierungsbedarf und Förderlandschaft (BAFA, KfW, BEG). Ein Kunde, der
auf Klard eine Energieberatung mit iSFP-Wunsch anfragt, steht mit hoher
Wahrscheinlichkeit kurz vor einer Investitionsentscheidung von 20.000–150.000 €.
Genau dieser Moment ist für Banken (KfW-durchleitende Hausbanken),
Modernisierungskredit-Anbieter und Sanierungs-Versicherer extrem wertvoll — und
für solche Leads zahlen sie regelmäßig zweistellige bis dreistellige
Beträge pro qualifiziertem Kontakt, deutlich mehr als deine Plattform-Lead-Gebühr.

## Wie es mechanisch funktioniert

1. Kunde stellt förderrelevante Anfrage und setzt eine **separate**
   DSGVO-Checkbox: „Ich möchte auch unverbindliche Finanzierungsangebote erhalten."
2. `POST /api/requests/:id/finance-share` matcht die Anfrage gegen aktive
   `finance_partners` (nach Region/Filter) und legt je Partner einen
   `finance_lead` an.
3. Partner erhält den Lead per E-Mail (`finance_lead_partner`).
4. Kommt es zum Abschluss, meldet der Partner das über
   `POST /api/finance-leads/:id/convert` zurück → Umsatz wird fällig.

Zwei Abrechnungsmodelle sind im Schema angelegt: Festbetrag pro Lead
(`payout_per_lead`) oder Erfolgsprovision (`payout_pct`). Starte mit Festbetrag —
einfacher abzurechnen und sofort planbar.

## Wirtschaftliche Einordnung

| Umsatzstrom | Typische Marge | Cashflow-Zeitpunkt |
|---|---|---|
| Buchungsprovision 7% | niedrig, transaktional | bei Buchung |
| Pay-per-Lead (Anbieter) | mittel | vor Abschluss |
| Abo (MRR) | hoch, planbar | monatlich |
| **Förder-Affiliate** | **hoch pro Lead** | bei Konversion |

Der Affiliate-Strom hat die beste Marge pro Vorgang, weil keine
Leistungserbringung deinerseits dranhängt — du vermittelst nur den ohnehin
vorhandenen Kontakt weiter. Bei z. B. 200 förderrelevanten Anfragen/Monat und
einem konservativen Festbetrag pro Lead summiert sich das schnell zu einem
relevanten Anteil am Gesamtumsatz, ohne zusätzliche operative Last.

## Der kritische Punkt: DSGVO & Erlaubnis

Das ist kein Nebenaspekt, sondern der Knackpunkt, an dem das Modell steht oder
fällt:

- Die Finanzierungs-Weitergabe braucht eine **eigene, getrennte Einwilligung** —
  nicht dieselbe Checkbox wie die Weitergabe an Handwerker/Berater. Das Schema
  trennt das bewusst (`consent_finance_share` vs. `consent_data_share`).
- Die Einwilligung muss informiert sein: an welche Art von Partnern, zu welchem
  Zweck. Liste die Partnerkategorien transparent.
- `consent_timestamp` wird gespeichert (Nachweispflicht).
- Kein Lead-Verkauf ohne aktive Einwilligung — die Route lehnt sonst ab.
- Prüfe, ob einzelne Partner als gemeinsam Verantwortliche (Art. 26 DSGVO) oder
  als eigenständige Verantwortliche einzuordnen sind; das bestimmt die nötigen
  Verträge.

Da du im stark regulierten Energie-/Finanzumfeld arbeitest, lohnt hier eine
kurze rechtliche Prüfung der Einwilligungstexte, bevor der Kanal live geht.
Ich bin kein Anwalt — das ersetzt keine Rechtsberatung, aber die Architektur ist
so gebaut, dass sie eine saubere Einwilligungslogik erzwingt.

## Empfohlene Einführungs-Reihenfolge

1. Erst Pay-per-Lead + Abos live und mit echten Anbietern testen.
2. Parallel 2–3 Finanzpartner manuell akquirieren (Hausbank-Kontakt,
   ein Modernisierungskredit-Anbieter, optional ein Versicherer).
3. Affiliate-Kanal mit Festbetrag-Abrechnung starten, klein, mit sauberer
   Einwilligung.
4. Erst bei Volumen auf Erfolgsprovision und automatisierte Partner-Anbindung
   (API-Key, Conversion-Webhook) ausbauen.
