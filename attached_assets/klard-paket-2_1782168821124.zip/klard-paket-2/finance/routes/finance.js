// ═══════════════════════════════════════════════════════════════
// Klard — Förder-Lead-Affiliate · Express Routes
// Datei: src/routes/finance.js
// ═══════════════════════════════════════════════════════════════
import express from "express";
import { pool } from "../db.js";
import { sendEmail } from "../email.js";

const router = express.Router();

// ─── Matching: passende Finanzpartner für eine Anfrage finden ──
async function matchPartners(request) {
  const r = await pool.query(
    `SELECT * FROM finance_partners
     WHERE is_active = TRUE
       AND (region_prefixes IS NULL
            OR cardinality(region_prefixes) = 0
            OR EXISTS (
              SELECT 1 FROM unnest(region_prefixes) px
              WHERE $1 LIKE px || '%'
            ))`,
    [request.postal_code || ""]);
  return r.rows;
}

// ─── POST /api/requests/:id/finance-share ──────────────────────
// Wird aufgerufen, wenn der Kunde der Finanzierungs-Weitergabe
// separat zustimmt (eigene DSGVO-Checkbox im Anfrage-Formular).
router.post("/requests/:id/finance-share", async (req, res) => {
  const requestId = req.params.id;
  const { consent_finance } = req.body;
  if (!consent_finance)
    return res.status(400).json({ error: "Einwilligung zur Finanzierungsweitergabe erforderlich." });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const rq = await client.query(`SELECT * FROM requests WHERE id=$1 FOR UPDATE`, [requestId]);
    if (!rq.rows.length) throw new Error("Anfrage nicht gefunden.");
    const request = rq.rows[0];
    if (!request.funding_relevant)
      throw new Error("Anfrage ist nicht förderrelevant.");
    if (request.finance_lead_created)
      throw new Error("Förder-Leads wurden bereits erstellt.");

    await client.query(
      `UPDATE requests SET consent_finance_share=TRUE, finance_lead_created=TRUE WHERE id=$1`,
      [requestId]);

    const partners = await matchPartners(request);
    const created = [];
    for (const p of partners) {
      const payout = Number(p.payout_per_lead) || 0;
      const fl = await client.query(
        `INSERT INTO finance_leads
          (request_id, partner_id, consent_finance, consent_timestamp, payout_amount, status)
         VALUES ($1,$2,TRUE,now(),$3,'sent')
         ON CONFLICT (request_id, partner_id) DO NOTHING
         RETURNING id`,
        [requestId, p.id, payout]);
      if (fl.rows.length) {
        created.push(p.id);
        sendEmail("finance_lead_partner", p.contact_email,
          { partner: p, request }).catch(console.error);
      }
    }
    await client.query("COMMIT");
    res.json({ ok: true, partners_notified: created.length });
  } catch (e) {
    await client.query("ROLLBACK");
    res.status(400).json({ error: e.message });
  } finally {
    client.release();
  }
});

// ─── POST /api/finance-leads/:id/convert ───────────────────────
// Partner meldet zurück, dass aus dem Lead ein Abschluss wurde.
// (per API-Key geschützt im echten Betrieb)
router.post("/finance-leads/:id/convert", async (req, res) => {
  const { id } = req.params;
  try {
    const fl = await pool.query(
      `UPDATE finance_leads
       SET status='converted', converted_at=now()
       WHERE id=$1 AND status IN ('sent','accepted')
       RETURNING *`, [id]);
    if (!fl.rows.length)
      return res.status(404).json({ error: "Lead nicht gefunden oder bereits konvertiert." });
    res.json({ ok: true, lead: fl.rows[0] });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── GET /api/admin/finance-revenue ────────────────────────────
router.get("/admin/finance-revenue", async (_req, res) => {
  const r = await pool.query(`SELECT * FROM finance_revenue ORDER BY revenue_paid DESC`);
  res.json({ partners: r.rows });
});

export default router;
