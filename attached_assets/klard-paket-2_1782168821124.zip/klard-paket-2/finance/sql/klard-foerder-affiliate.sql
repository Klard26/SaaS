-- ═══════════════════════════════════════════════════════════════
-- Klard — Förder-Lead-Affiliate-Modul (5. Umsatzstrom)
-- Monetarisiert Anfragen mit funding_relevant = true als
-- qualifizierte Leads für Finanzierungs-/Förderpartner (KfW-Banken,
-- Modernisierungskredite, Versicherer, Fördermittelberater).
-- Voraussetzung: klard-anfragen-modul.sql ist eingespielt.
-- ═══════════════════════════════════════════════════════════════

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 1. finance_partners — Abnehmer der Förder-Leads              │
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS finance_partners (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            TEXT NOT NULL,
    type            TEXT NOT NULL
                    CHECK (type IN ('bank','kredit','versicherung','foerderberatung','sonstige')),
    contact_email   TEXT NOT NULL,
    -- Provision je vermitteltem Lead (Festbetrag) ODER % bei Abschluss
    payout_per_lead NUMERIC(10,2) DEFAULT 0,
    payout_pct      NUMERIC(5,2) DEFAULT 0,
    -- Welche Lead-Typen will der Partner? (JSONB-Filter)
    accepts_filter  JSONB DEFAULT '{}'::jsonb,
    -- Geografische Abdeckung (PLZ-Präfixe, leer = bundesweit)
    region_prefixes TEXT[],
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 2. finance_leads — vermittelte Förder-Leads + Abrechnung     │
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS finance_leads (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_id          UUID NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
    partner_id          UUID NOT NULL REFERENCES finance_partners(id) ON DELETE CASCADE,
    -- Eigene DSGVO-Einwilligung für Finanzierungsweitergabe!
    consent_finance     BOOLEAN NOT NULL DEFAULT FALSE,
    consent_timestamp   TIMESTAMPTZ,
    -- Abrechnung
    payout_amount       NUMERIC(10,2) NOT NULL DEFAULT 0,
    status              TEXT NOT NULL DEFAULT 'sent'
                        CHECK (status IN ('sent','accepted','converted','rejected','paid')),
    -- Partner meldet Konversion zurück (Kredit/Förderung abgeschlossen)
    converted_at        TIMESTAMPTZ,
    payout_status       TEXT DEFAULT 'pending'
                        CHECK (payout_status IN ('pending','invoiced','paid')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (request_id, partner_id)
);

CREATE INDEX IF NOT EXISTS idx_finleads_request ON finance_leads(request_id);
CREATE INDEX IF NOT EXISTS idx_finleads_partner ON finance_leads(partner_id);
CREATE INDEX IF NOT EXISTS idx_finleads_status  ON finance_leads(status);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 3. requests-Erweiterung: separate Finanzierungs-Einwilligung │
-- └─────────────────────────────────────────────────────────────┘
ALTER TABLE requests ADD COLUMN IF NOT EXISTS consent_finance_share BOOLEAN DEFAULT FALSE;
ALTER TABLE requests ADD COLUMN IF NOT EXISTS finance_lead_created BOOLEAN DEFAULT FALSE;

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 4. View: Affiliate-Umsatz-Übersicht (fürs Admin-Dashboard)   │
-- └─────────────────────────────────────────────────────────────┘
CREATE OR REPLACE VIEW finance_revenue AS
SELECT
    fp.id AS partner_id,
    fp.name AS partner_name,
    COUNT(fl.id)                                            AS leads_sent,
    COUNT(fl.id) FILTER (WHERE fl.status = 'converted')     AS conversions,
    COALESCE(SUM(fl.payout_amount) FILTER (WHERE fl.payout_status = 'paid'), 0) AS revenue_paid,
    COALESCE(SUM(fl.payout_amount) FILTER (WHERE fl.payout_status = 'pending'), 0) AS revenue_pending
FROM finance_partners fp
LEFT JOIN finance_leads fl ON fl.partner_id = fp.id
GROUP BY fp.id, fp.name;
