import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { query } from "../db/pool.js";
import type { ProgrammVoll } from "../lib/types.js";

/**
 * Profilbasiertes Matching OHNE persistiertes Nutzerkonto — die Plattform
 * kann so schon vor Registrierung Vorschläge machen (der "Förder-Schnellcheck").
 * Die DB-Funktion passende_programme() setzt ein gespeichertes Profil voraus;
 * hier matchen wir direkt gegen die übergebenen Profilwerte.
 */
const MatchBody = z.object({
  zielgruppe: z.string().optional(), // slug, z. B. "kmu_klein"
  region: z.string().optional(), // bundesland-ENUM, z. B. "berlin"
  kategorien: z.array(z.string()).optional(), // slugs
  limit: z.coerce.number().int().min(1).max(50).default(10),
});

export async function matchingRoutes(app: FastifyInstance) {
  /**
   * POST /api/match
   * Body: { zielgruppe?, region?, kategorien?[] }
   * Liefert passende, aktive Programme — region matcht das Bundesland ODER
   * bundesweite Programme. Verifizierte und erfolgversprechende zuerst.
   */
  app.post("/api/match", async (req, reply) => {
    const parsed = MatchBody.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "Ungültiges Profil", details: parsed.error.issues });
    }
    const { zielgruppe, region, kategorien, limit } = parsed.data;

    const where: string[] = ["vp.aktiv"];
    const params: unknown[] = [];
    const p = (v: unknown) => {
      params.push(v);
      return `$${params.length}`;
    };

    if (zielgruppe) where.push(`${p(zielgruppe)} = ANY(vp.zielgruppen)`);
    if (region) {
      // passendes Bundesland ODER bundesweit
      where.push(`(${p(region)} = ANY(vp.regionen) OR 'bundesweit' = ANY(vp.regionen))`);
    }
    if (kategorien && kategorien.length > 0) {
      // mindestens eine der gewünschten Kategorien
      where.push(`vp.kategorien && ${p(kategorien)}::text[]`);
    }

    const rows = await query<ProgrammVoll>(
      `SELECT * FROM v_programm_voll vp
       WHERE ${where.join(" AND ")}
       ORDER BY (vp.status = 'verifiziert') DESC,
                vp.erfolgsquote DESC NULLS LAST,
                vp.titel ASC
       LIMIT ${p(limit)}`,
      params
    );

    return {
      profil: { zielgruppe, region, kategorien },
      anzahl: rows.length,
      treffer: rows,
    };
  });
}
