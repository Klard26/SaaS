import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { query } from "../db/pool.js";
import type { ProgrammVoll } from "../lib/types.js";

const FinderQuery = z.object({
  ebene: z.enum(["bund", "land", "eu", "kommune"]).optional(),
  art: z
    .enum(["zuschuss", "kredit", "buergschaft", "beteiligung", "beratung", "steuer"])
    .optional(),
  timing: z
    .enum(["vor_vorhabenbeginn", "laufend", "stichtag_call", "budget_topf"])
    .optional(),
  status: z.enum(["verifiziert", "zu_pruefen", "veraltet"]).optional(),
  kategorie: z.string().optional(), // slug oder Name
  zielgruppe: z.string().optional(),
  region: z.string().optional(),
  suche: z.string().optional(), // Volltext über Titel/Beschreibung
  nur_aktiv: z
    .union([z.literal("true"), z.literal("false")])
    .optional()
    .default("true"),
  limit: z.coerce.number().int().min(1).max(100).default(25),
  offset: z.coerce.number().int().min(0).default(0),
});

export async function finderRoutes(app: FastifyInstance) {
  /**
   * GET /api/programme
   * Profilbasierter/filterbarer Finder. Alle Filter sind optional und werden
   * dynamisch zur WHERE-Klausel zusammengesetzt (parametrisiert, SQL-sicher).
   */
  app.get("/api/programme", async (req, reply) => {
    const parsed = FinderQuery.safeParse(req.query);
    if (!parsed.success) {
      return reply.code(400).send({ error: "Ungültige Filter", details: parsed.error.issues });
    }
    const f = parsed.data;

    const where: string[] = [];
    const params: unknown[] = [];
    const p = (v: unknown) => {
      params.push(v);
      return `$${params.length}`;
    };

    if (f.nur_aktiv === "true") where.push("vp.aktiv");
    if (f.ebene) where.push(`vp.ebene = ${p(f.ebene)}`);
    if (f.art) where.push(`vp.art = ${p(f.art)}`);
    if (f.timing) where.push(`vp.timing = ${p(f.timing)}`);
    if (f.status) where.push(`vp.status = ${p(f.status)}`);
    if (f.kategorie) where.push(`${p(f.kategorie)} = ANY(vp.kategorien)`);
    if (f.zielgruppe) where.push(`${p(f.zielgruppe)} = ANY(vp.zielgruppen)`);
    if (f.region) where.push(`${p(f.region)} = ANY(vp.regionen)`);
    if (f.suche) {
      // Trigram-Ähnlichkeit auf Titel ODER Teilstring in Beschreibung
      where.push(
        `(vp.titel ILIKE '%' || ${p(f.suche)} || '%' OR vp.kurzbeschreibung ILIKE '%' || ${p(
          f.suche
        )} || '%')`
      );
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    // Gesamtzahl für Pagination
    const countRows = await query<{ total: string }>(
      `SELECT count(*)::text AS total FROM v_programm_voll vp ${whereSql}`,
      params
    );
    const total = Number(countRows[0]?.total ?? 0);

    // Seite laden — verifizierte zuerst, dann nach Erfolgsquote
    const rows = await query<ProgrammVoll>(
      `SELECT * FROM v_programm_voll vp
       ${whereSql}
       ORDER BY (vp.status = 'verifiziert') DESC,
                vp.erfolgsquote DESC NULLS LAST,
                vp.titel ASC
       LIMIT ${p(f.limit)} OFFSET ${p(f.offset)}`,
      params
    );

    return {
      total,
      limit: f.limit,
      offset: f.offset,
      anzahl: rows.length,
      programme: rows,
    };
  });

  /**
   * GET /api/filter-optionen
   * Liefert die verfügbaren Filterwerte (für UI-Dropdowns) direkt aus den Daten.
   */
  app.get("/api/filter-optionen", async () => {
    const [kategorien, zielgruppen] = await Promise.all([
      query<{ slug: string; name: string }>(
        "SELECT slug, name FROM kategorie ORDER BY name"
      ),
      query<{ slug: string; name: string }>(
        "SELECT slug, name FROM zielgruppe ORDER BY name"
      ),
    ]);
    return {
      ebene: ["bund", "land", "eu", "kommune"],
      art: ["zuschuss", "kredit", "buergschaft", "beteiligung", "beratung", "steuer"],
      timing: ["vor_vorhabenbeginn", "laufend", "stichtag_call", "budget_topf"],
      status: ["verifiziert", "zu_pruefen", "veraltet"],
      kategorien,
      zielgruppen,
    };
  });
}
