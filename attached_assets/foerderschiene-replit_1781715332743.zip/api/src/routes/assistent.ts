import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";

/**
 * Dokument-Assistent (optional).
 *
 * Erzeugt einen ersten Entwurf eines Pflichtdokuments (z. B. Vorhabenbeschreibung,
 * Businessplan) auf Basis der Nutzereingaben UND der programmspezifischen
 * Anforderungen aus der Anreicherungsschicht.
 *
 * Hinweis: Dieser Endpunkt ruft die Anthropic-API. Er ist nur aktiv, wenn
 * ANTHROPIC_API_KEY gesetzt ist — sonst antwortet er mit 503, ohne den Rest
 * der API zu blockieren. So bleibt das Backend auch ohne Key voll lauffähig.
 *
 * Installation bei Bedarf:  npm i @anthropic-ai/sdk
 */

const GenBody = z.object({
  programm_id: z.string().uuid(),
  dokument_typ: z.string().default("vorhabenbeschreibung"),
  eingaben: z.record(z.string()), // freie Feld→Wert-Map aus dem UI-Formular
});

const MODELL = "claude-sonnet-4-6";

export async function assistentRoutes(app: FastifyInstance) {
  app.post("/api/dokument/entwurf", async (req, reply) => {
    const parsed = GenBody.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "Ungültige Eingabe", details: parsed.error.issues });
    }
    const { programm_id, dokument_typ, eingaben } = parsed.data;

    if (!process.env.ANTHROPIC_API_KEY) {
      return reply.code(503).send({
        error: "Dokument-Assistent nicht konfiguriert",
        hinweis: "ANTHROPIC_API_KEY setzen und @anthropic-ai/sdk installieren, um diesen Endpunkt zu aktivieren.",
      });
    }

    // Programmkontext + ggf. Vorlage laden — macht den Entwurf programmspezifisch
    const programm = await queryOne<{ titel: string; besonderheit: string | null }>(
      "SELECT titel, besonderheit FROM programm WHERE id = $1",
      [programm_id]
    );
    if (!programm) {
      return reply.code(404).send({ error: "Programm nicht gefunden" });
    }
    const vorlage = await queryOne<{ prompt_vorlage: string | null }>(
      "SELECT prompt_vorlage FROM dokumentvorlage WHERE programm_id = $1 AND dokument_typ = $2 LIMIT 1",
      [programm_id, dokument_typ]
    );
    const ablehnung = await query<{ text: string }>(
      "SELECT text FROM erfolgsfaktor WHERE programm_id = $1 AND typ = 'ablehnungsgrund'",
      [programm_id]
    );

    const systemPrompt = [
      `Du bist ein Assistent, der einen ersten Entwurf für das Dokument "${dokument_typ}"`,
      `für das deutsche Förderprogramm "${programm.titel}" erstellt.`,
      programm.besonderheit ? `Programm-Besonderheit: ${programm.besonderheit}` : "",
      ablehnung.length
        ? `Vermeide diese typischen Ablehnungsgründe: ${ablehnung.map((a) => a.text).join("; ")}.`
        : "",
      vorlage?.prompt_vorlage ?? "",
      "Schreibe sachlich, auf Deutsch, in der für Förderanträge üblichen Form.",
      "Kennzeichne klar, dass dies ein Entwurf ist, der vom Antragsteller zu prüfen ist.",
    ]
      .filter(Boolean)
      .join("\n");

    const userPrompt =
      "Nutzereingaben:\n" +
      Object.entries(eingaben)
        .map(([k, v]) => `- ${k}: ${v}`)
        .join("\n");

    try {
      // Dynamischer Import, damit das Paket nur geladen wird, wenn der Endpunkt genutzt wird.
      // @ts-expect-error — optionales Paket; erst nach `npm i @anthropic-ai/sdk` vorhanden.
      const { default: Anthropic } = await import("@anthropic-ai/sdk");
      const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

      const msg = await client.messages.create({
        model: MODELL,
        max_tokens: 1500,
        system: systemPrompt,
        messages: [{ role: "user", content: userPrompt }],
      });

      const text = msg.content
        .filter((b: { type: string }): b is { type: "text"; text: string } => b.type === "text")
        .map((b: { text: string }) => b.text)
        .join("\n");

      return {
        programm: programm.titel,
        dokument_typ,
        modell: MODELL,
        entwurf: text,
        hinweis: "Automatisch erzeugter Entwurf — vor Einreichung fachlich prüfen.",
      };
    } catch (err) {
      app.log.error(err);
      return reply.code(502).send({ error: "Entwurf konnte nicht erzeugt werden" });
    }
  });
}
