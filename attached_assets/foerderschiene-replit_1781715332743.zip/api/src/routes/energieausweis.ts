import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";
import type {
  TypEntscheidung,
  Gebaeude,
  Ausweis,
  FoerderTreffer,
} from "../lib/energieausweis-types.js";

/* ---------- Schemas (Validierung) ---------- */
const NutzungEnum = z.enum(["wohngebaeude", "nichtwohngebaeude", "mischgebaeude"]);

const TypWeicheQuery = z.object({
  nutzung: NutzungEnum,
  baujahr: z.coerce.number().int().min(1800).max(2100).optional(),
  wohneinheiten: z.coerce.number().int().min(1).optional(),
});

const GebaeudeBody = z.object({
  strasse: z.string().optional(),
  plz: z.string().optional(),
  ort: z.string().optional(),
  bundesland: z.string().optional(),
  baujahr: z.number().int().min(1800).max(2100).optional(),
  nutzung: NutzungEnum,
  wohnflaeche_m2: z.number().nonnegative().optional(),
  nutzflaeche_m2: z.number().nonnegative().optional(),
  wohneinheiten: z.number().int().min(1).optional(),
  heizung_traeger: z.string().optional(),
  daten_quelle: z.enum(["manuell", "planflux", "import"]).default("manuell"),
});

const ErfassungBody = z.object({
  felder: z.array(
    z.object({
      feld: z.string(),
      wert: z.string(),
      einheit: z.string().optional(),
    })
  ),
});

const IdParam = z.object({ id: z.string().uuid() });

export async function energieausweisRoutes(app: FastifyInstance) {
  /**
   * GET /api/energieausweis/typ-weiche
   * GModG-konforme Bestimmung des zulässigen Ausweistyps.
   * Nutzt die DB-Funktion bestimme_ausweistyp().
   */
  app.get("/api/energieausweis/typ-weiche", async (req, reply) => {
    const parsed = TypWeicheQuery.safeParse(req.query);
    if (!parsed.success) {
      return reply.code(400).send({ error: "Ungültige Eingabe", details: parsed.error.issues });
    }
    const { nutzung, baujahr, wohneinheiten } = parsed.data;

    const entscheidung = await queryOne<TypEntscheidung>(
      `SELECT erzwungener_typ, wahlfreiheit, begruendung
       FROM energieausweis.bestimme_ausweistyp($1, $2, $3)`,
      [nutzung, baujahr ?? null, wohneinheiten ?? null]
    );

    if (!entscheidung) {
      // Keine Regel gefunden — sicherheitshalber Bedarfsausweis empfehlen
      return {
        nutzung,
        erzwungener_typ: "bedarfsausweis",
        wahlfreiheit: false,
        begruendung: "Keine passende Regel gefunden — vorsorglich Bedarfsausweis.",
        hinweis: "Fallback. Regelbasis prüfen.",
      };
    }

    // Empfohlener Typ: erzwungener_typ, sonst (bei Wahlfreiheit) Verbrauchsausweis als Default
    const empfehlung =
      entscheidung.erzwungener_typ ??
      (entscheidung.wahlfreiheit ? "verbrauchsausweis" : "bedarfsausweis");

    return {
      nutzung,
      empfohlener_typ: empfehlung,
      erzwungener_typ: entscheidung.erzwungener_typ,
      wahlfreiheit: entscheidung.wahlfreiheit,
      begruendung: entscheidung.begruendung,
    };
  });

  /**
   * POST /api/energieausweis
   * Legt Gebäude + Ausweis an. Der Ausweistyp wird über die Typ-Weiche
   * bestimmt (kann durch ?typ überschrieben werden, falls Wahlfreiheit).
   */
  app.post("/api/energieausweis", async (req, reply) => {
    const parsed = GebaeudeBody.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "Ungültige Gebäudedaten", details: parsed.error.issues });
    }
    const g = parsed.data;

    // 1. Typ-Weiche anwenden
    const entscheidung = await queryOne<TypEntscheidung>(
      `SELECT erzwungener_typ, wahlfreiheit, begruendung
       FROM energieausweis.bestimme_ausweistyp($1, $2, $3)`,
      [g.nutzung, g.baujahr ?? null, g.wohneinheiten ?? null]
    );
    const typ =
      entscheidung?.erzwungener_typ ??
      (entscheidung?.wahlfreiheit ? "verbrauchsausweis" : "bedarfsausweis");

    // 2. Gebäude anlegen
    const gebaeude = await queryOne<Gebaeude>(
      `INSERT INTO energieausweis.gebaeude
        (strasse, plz, ort, bundesland, baujahr, nutzung,
         wohnflaeche_m2, nutzflaeche_m2, wohneinheiten, heizung_traeger, daten_quelle)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
       RETURNING *`,
      [
        g.strasse ?? null, g.plz ?? null, g.ort ?? null, g.bundesland ?? null,
        g.baujahr ?? null, g.nutzung, g.wohnflaeche_m2 ?? null, g.nutzflaeche_m2 ?? null,
        g.wohneinheiten ?? null, g.heizung_traeger ?? null, g.daten_quelle,
      ]
    );
    if (!gebaeude) return reply.code(500).send({ error: "Gebäude konnte nicht angelegt werden" });

    // 3. Preis aus Preisliste ziehen, Ausweis anlegen
    const ausweis = await queryOne<Ausweis>(
      `INSERT INTO energieausweis.ausweis (gebaeude_id, typ, status, preis_eur)
       VALUES ($1, $2, 'entwurf',
               (SELECT basispreis_eur FROM energieausweis.preis WHERE typ = $2))
       RETURNING *`,
      [gebaeude.id, typ]
    );

    return reply.code(201).send({
      gebaeude,
      ausweis,
      typ_entscheidung: {
        empfohlener_typ: typ,
        wahlfreiheit: entscheidung?.wahlfreiheit ?? false,
        begruendung: entscheidung?.begruendung ?? null,
      },
    });
  });

  /**
   * POST /api/energieausweis/:id/erfassung
   * Speichert/aktualisiert Erfassungsfelder (geführte Datenerfassung).
   */
  app.post("/api/energieausweis/:id/erfassung", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    const pbody = ErfassungBody.safeParse(req.body);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Ausweis-ID" });
    if (!pbody.success) return reply.code(400).send({ error: "Ungültige Erfassung", details: pbody.error.issues });

    const ausweis = await queryOne<{ id: string }>(
      "SELECT id FROM energieausweis.ausweis WHERE id = $1",
      [pid.data.id]
    );
    if (!ausweis) return reply.code(404).send({ error: "Ausweis nicht gefunden" });

    // Upsert je Feld (UNIQUE(ausweis_id, feld))
    for (const f of pbody.data.felder) {
      await query(
        `INSERT INTO energieausweis.erfassung (ausweis_id, feld, wert, einheit)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (ausweis_id, feld)
         DO UPDATE SET wert = EXCLUDED.wert, einheit = EXCLUDED.einheit, geprueft = FALSE`,
        [pid.data.id, f.feld, f.wert, f.einheit ?? null]
      );
    }
    const gespeichert = await query(
      "SELECT feld, wert, einheit, geprueft FROM energieausweis.erfassung WHERE ausweis_id = $1 ORDER BY feld",
      [pid.data.id]
    );
    return { ausweis_id: pid.data.id, erfassung: gespeichert };
  });

  /**
   * GET /api/energieausweis/:id
   * Detail: Ausweis + Gebäude + Erfassung + Empfehlungen.
   */
  app.get("/api/energieausweis/:id", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Ausweis-ID" });

    const ausweis = await queryOne<Ausweis & Gebaeude>(
      `SELECT a.*, g.nutzung, g.bundesland, g.baujahr, g.strasse, g.plz, g.ort
       FROM energieausweis.ausweis a
       JOIN energieausweis.gebaeude g ON g.id = a.gebaeude_id
       WHERE a.id = $1`,
      [pid.data.id]
    );
    if (!ausweis) return reply.code(404).send({ error: "Ausweis nicht gefunden" });

    const [erfassung, empfehlungen] = await Promise.all([
      query("SELECT feld, wert, einheit, geprueft FROM energieausweis.erfassung WHERE ausweis_id = $1 ORDER BY feld", [pid.data.id]),
      query("SELECT massnahme, einspar_potenzial_prozent, reihenfolge FROM energieausweis.empfehlung WHERE ausweis_id = $1 ORDER BY reihenfolge", [pid.data.id]),
    ]);

    return { ...ausweis, erfassung, empfehlungen };
  });

  /**
   * GET /api/energieausweis/:id/foerder-anschluss
   * Die Funnel-Übergabe: liefert die zum Ausweis passenden Förderprogramme
   * (Brücke ins Förderpilot-Kerngeschäft).
   */
  app.get("/api/energieausweis/:id/foerder-anschluss", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Ausweis-ID" });

    const treffer = await query<FoerderTreffer>(
      `SELECT fa.programm_id, p.titel, fa.relevanz
       FROM energieausweis.foerder_anschluss fa
       JOIN foerderpilot.programm p ON p.id = fa.programm_id
       WHERE fa.ausweis_id = $1
       ORDER BY fa.relevanz ASC`,
      [pid.data.id]
    );
    return { ausweis_id: pid.data.id, anzahl: treffer.length, foerderprogramme: treffer };
  });

  /**
   * POST /api/energieausweis/:id/foerder-anschluss
   * Erzeugt Funnel-Verknüpfungen: ordnet dem Ausweis passende Förderprogramme
   * zu. Heuristik: Energie-/Gebäude-Programme mit Bezug zu Sanierung/Heizung.
   */
  app.post("/api/energieausweis/:id/foerder-anschluss", async (req, reply) => {
    const pid = IdParam.safeParse(req.params);
    if (!pid.success) return reply.code(400).send({ error: "Ungültige Ausweis-ID" });

    const ausweis = await queryOne<{ id: string }>(
      "SELECT id FROM energieausweis.ausweis WHERE id = $1",
      [pid.data.id]
    );
    if (!ausweis) return reply.code(404).send({ error: "Ausweis nicht gefunden" });

    // Passende Energie-/Gebäude-Förderprogramme aus Förderpilot wählen
    const programme = await query<{ id: string }>(
      `SELECT vp.id FROM foerderpilot.v_programm_voll vp
       WHERE vp.aktiv AND 'Energie & Gebäude' = ANY(vp.kategorien)
       ORDER BY (vp.status = 'verifiziert') DESC, vp.erfolgsquote DESC NULLS LAST
       LIMIT 5`,
      []
    );

    let angelegt = 0;
    for (let i = 0; i < programme.length; i++) {
      await query(
        `INSERT INTO energieausweis.foerder_anschluss (ausweis_id, programm_id, relevanz)
         VALUES ($1, $2, $3)`,
        [pid.data.id, programme[i].id, i + 1]
      );
      angelegt++;
    }
    return { ausweis_id: pid.data.id, angelegte_anschluesse: angelegt };
  });
}
