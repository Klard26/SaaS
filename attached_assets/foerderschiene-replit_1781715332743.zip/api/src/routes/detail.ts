import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";
import type {
  ProgrammVoll,
  ProgrammDetail,
  Antragsschritt,
  Erfolgsfaktor,
  Pflichtunterlage,
  Berater,
} from "../lib/types.js";

const IdParam = z.object({ id: z.string().uuid() });

export async function detailRoutes(app: FastifyInstance) {
  /**
   * GET /api/programme/:id
   * Vollständige Detailansicht: Stammdaten + angereicherter Antragspfad,
   * Erfolgsfaktoren, Ablehnungsgründe, Pflichtunterlagen, passende Berater.
   */
  app.get("/api/programme/:id", async (req, reply) => {
    const parsed = IdParam.safeParse(req.params);
    if (!parsed.success) {
      return reply.code(400).send({ error: "Ungültige Programm-ID" });
    }
    const { id } = parsed.data;

    const programm = await queryOne<ProgrammVoll>(
      "SELECT * FROM v_programm_voll WHERE id = $1",
      [id]
    );
    if (!programm) {
      return reply.code(404).send({ error: "Programm nicht gefunden" });
    }

    // Anreicherungsschicht parallel laden
    const [schritte, faktoren, unterlagen, berater] = await Promise.all([
      query<Antragsschritt>(
        `SELECT reihenfolge, titel, beschreibung, aufwand_text, frist_bezug,
                erfordert_dokument_typ, erfordert_berater
         FROM antragsschritt WHERE programm_id = $1 ORDER BY reihenfolge`,
        [id]
      ),
      query<Erfolgsfaktor>(
        `SELECT typ, text, gewicht FROM erfolgsfaktor
         WHERE programm_id = $1 ORDER BY gewicht DESC`,
        [id]
      ),
      query<Pflichtunterlage>(
        `SELECT bezeichnung, pflicht FROM pflichtunterlage WHERE programm_id = $1`,
        [id]
      ),
      query<Berater>(
        `SELECT b.id, b.name, b.qualifikation, b.region::text, b.bewertung
         FROM berater b
         JOIN berater_programm bp ON bp.berater_id = b.id
         WHERE bp.programm_id = $1 AND b.aktiv
         ORDER BY b.bewertung DESC NULLS LAST`,
        [id]
      ),
    ]);

    const detail: ProgrammDetail = {
      ...programm,
      antragspfad: schritte,
      erfolgsfaktoren: faktoren.filter((f) => f.typ === "erfolgsfaktor"),
      ablehnungsgruende: faktoren.filter((f) => f.typ === "ablehnungsgrund"),
      pflichtunterlagen: unterlagen,
      berater,
    };
    return detail;
  });

  /**
   * GET /api/programme/:id/antragspfad
   * Nur der geführte Antragspfad — leichtgewichtig für die Schritt-Ansicht.
   */
  app.get("/api/programme/:id/antragspfad", async (req, reply) => {
    const parsed = IdParam.safeParse(req.params);
    if (!parsed.success) {
      return reply.code(400).send({ error: "Ungültige Programm-ID" });
    }
    const schritte = await query<Antragsschritt>(
      `SELECT reihenfolge, titel, beschreibung, aufwand_text, frist_bezug,
              erfordert_dokument_typ, erfordert_berater
       FROM antragsschritt WHERE programm_id = $1 ORDER BY reihenfolge`,
      [parsed.data.id]
    );
    if (schritte.length === 0) {
      // Kein Pfad hinterlegt — 200 mit leerer Liste statt 404 (Programm kann existieren)
      return { programm_id: parsed.data.id, schritte: [] };
    }
    return { programm_id: parsed.data.id, schritte };
  });
}
