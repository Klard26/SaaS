import Fastify from "fastify";
import cors from "@fastify/cors";
import { pool } from "./db/pool.js";
import { finderRoutes } from "./routes/finder.js";
import { detailRoutes } from "./routes/detail.js";
import { matchingRoutes } from "./routes/matching.js";
import { assistentRoutes } from "./routes/assistent.js";
import { energieausweisRoutes } from "./routes/energieausweis.js";

const app = Fastify({
  logger: { level: process.env.LOG_LEVEL ?? "info" },
});

await app.register(cors, { origin: true });

// Healthcheck — prüft auch die DB-Verbindung
app.get("/health", async (_req, reply) => {
  try {
    await pool.query("SELECT 1");
    return { status: "ok", db: "verbunden" };
  } catch {
    return reply.code(503).send({ status: "degraded", db: "nicht erreichbar" });
  }
});

// API-Übersicht
app.get("/", async () => ({
  name: "Förderpilot API",
  version: "0.1.0",
  endpunkte: [
    "GET  /health",
    "GET  /api/programme            — Finder mit Filtern",
    "GET  /api/filter-optionen      — verfügbare Filterwerte",
    "GET  /api/programme/:id        — Programm-Detail (inkl. Antragspfad)",
    "GET  /api/programme/:id/antragspfad — nur die Schritte",
    "POST /api/match                — Profil-Matching",
    "POST /api/dokument/entwurf     — Dokument-Assistent (optional)",
    "GET  /api/energieausweis/typ-weiche — GModG-Ausweistyp bestimmen",
    "POST /api/energieausweis        — Gebäude + Ausweis anlegen",
    "POST /api/energieausweis/:id/erfassung — Datenerfassung speichern",
    "GET  /api/energieausweis/:id    — Ausweis-Detail",
    "GET  /api/energieausweis/:id/foerder-anschluss — Funnel: passende Förderung",
    "POST /api/energieausweis/:id/foerder-anschluss — Funnel-Verknüpfungen erzeugen",
  ],
}));

await app.register(finderRoutes);
await app.register(detailRoutes);
await app.register(matchingRoutes);
await app.register(assistentRoutes);
await app.register(energieausweisRoutes);

const port = Number(process.env.PORT ?? 3000);
const host = process.env.HOST ?? "0.0.0.0";

try {
  await app.listen({ port, host });
  app.log.info(`Förderpilot API läuft auf http://${host}:${port}`);
} catch (err) {
  app.log.error(err);
  process.exit(1);
}

// Sauberes Herunterfahren
for (const sig of ["SIGINT", "SIGTERM"] as const) {
  process.on(sig, async () => {
    app.log.info(`${sig} empfangen — fahre herunter`);
    await app.close();
    await pool.end();
    process.exit(0);
  });
}
