/**
 * Typen für das Energieausweis-Modul — Spiegel des energieausweis-Schemas.
 */

export type Nutzungstyp = "wohngebaeude" | "nichtwohngebaeude" | "mischgebaeude";
export type Ausweistyp = "verbrauchsausweis" | "bedarfsausweis";
export type AusweisStatus =
  | "entwurf"
  | "in_pruefung"
  | "experten_freigabe"
  | "registriert"
  | "ausgestellt"
  | "storniert";
export type Effizienzklasse =
  | "A_plus" | "A" | "B" | "C" | "D" | "E" | "F" | "G" | "H";
export type Datenquelle = "manuell" | "planflux" | "import";

/** Ergebnis der GModG-Typ-Weiche. */
export interface TypEntscheidung {
  erzwungener_typ: Ausweistyp | null;
  wahlfreiheit: boolean;
  begruendung: string | null;
}

export interface Gebaeude {
  id: string;
  strasse: string | null;
  plz: string | null;
  ort: string | null;
  bundesland: string | null;
  baujahr: number | null;
  nutzung: Nutzungstyp;
  wohnflaeche_m2: number | null;
  nutzflaeche_m2: number | null;
  wohneinheiten: number | null;
  heizung_traeger: string | null;
  daten_quelle: Datenquelle;
}

export interface Ausweis {
  id: string;
  gebaeude_id: string;
  typ: Ausweistyp;
  status: AusweisStatus;
  kennwert_kwh_m2a: number | null;
  effizienz: Effizienzklasse | null;
  dibt_nr: string | null;
  preis_eur: number | null;
}

export interface FoerderTreffer {
  programm_id: string;
  titel: string;
  relevanz: number;
}
