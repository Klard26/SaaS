/**
 * Typen, die das foerderpilot-Schema in TypeScript spiegeln.
 * Halten Backend und Datenbank konsistent.
 */

export type Ebene = "bund" | "land" | "eu" | "kommune";
export type Foerderart =
  | "zuschuss"
  | "kredit"
  | "buergschaft"
  | "beteiligung"
  | "beratung"
  | "steuer";
export type AntragsTiming =
  | "vor_vorhabenbeginn"
  | "laufend"
  | "stichtag_call"
  | "budget_topf";
export type PruefStatus = "verifiziert" | "zu_pruefen" | "veraltet";
export type FaktorTyp = "erfolgsfaktor" | "ablehnungsgrund";

/** Eine Zeile aus der View v_programm_voll. */
export interface ProgrammVoll {
  id: string;
  titel: string;
  foerdergeber: string;
  ebene: Ebene;
  art: Foerderart;
  timing: AntragsTiming;
  foerderquote_text: string | null;
  quote_min: number | null;
  quote_max: number | null;
  max_betrag_text: string | null;
  max_betrag_eur: number | null;
  kurzbeschreibung: string | null;
  besonderheit: string | null;
  quelle_url: string | null;
  quelle_stand: string | null;
  status: PruefStatus;
  aktiv: boolean;
  kategorien: string[];
  zielgruppen: string[];
  regionen: string[];
  erfolgsquote: number | null;
}

export interface Antragsschritt {
  reihenfolge: number;
  titel: string;
  beschreibung: string;
  aufwand_text: string | null;
  frist_bezug: string | null;
  erfordert_dokument_typ: string | null;
  erfordert_berater: boolean;
}

export interface Erfolgsfaktor {
  typ: FaktorTyp;
  text: string;
  gewicht: number;
}

export interface Pflichtunterlage {
  bezeichnung: string;
  pflicht: boolean;
}

export interface Berater {
  id: string;
  name: string;
  qualifikation: string | null;
  region: string | null;
  bewertung: number | null;
}

/** Vollständige Detailantwort für ein Programm. */
export interface ProgrammDetail extends ProgrammVoll {
  antragspfad: Antragsschritt[];
  erfolgsfaktoren: Erfolgsfaktor[];
  ablehnungsgruende: Erfolgsfaktor[];
  pflichtunterlagen: Pflichtunterlage[];
  berater: Berater[];
}
