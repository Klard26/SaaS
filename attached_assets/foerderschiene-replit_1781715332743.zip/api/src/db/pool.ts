import pg from "pg";

const { Pool } = pg;

/**
 * Zentraler Connection-Pool. Liest die Verbindung aus DATABASE_URL,
 * z. B. postgres://user:pass@localhost:5432/foerderpilot
 *
 * Wichtig: Das Schema heißt "foerderpilot" — wir setzen den search_path
 * pro Verbindung, damit alle Tabellen ohne Schema-Präfix erreichbar sind.
 */
export const pool = new Pool({
  connectionString:
    process.env.DATABASE_URL ??
    "postgres://postgres:postgres@localhost:5432/foerderpilot",
  max: 10,
  idleTimeoutMillis: 30_000,
  // SSL nur bei Bedarf: Replit-eigenes PostgreSQL braucht es nicht, externe
  // Anbieter (Neon, Supabase, Railway) meist schon. Per PGSSL=true aktivierbar.
  ssl:
    String(process.env.PGSSL).toLowerCase() === "true"
      ? { rejectUnauthorized: false }
      : undefined,
});

pool.on("connect", (client) => {
  // Beide Modul-Schemas im Pfad: energieausweis referenziert foerderpilot-Tabellen.
  client.query("SET search_path TO foerderpilot, energieausweis, public");
});

pool.on("error", (err) => {
  // Verbindungsfehler im Pool sollen den Prozess nicht crashen lassen
  console.error("[db] Unerwarteter Pool-Fehler:", err.message);
});

/** Kleiner Helfer für typisierte Queries. */
export async function query<T = unknown>(
  text: string,
  params: unknown[] = []
): Promise<T[]> {
  const res = await pool.query(text, params);
  return res.rows as T[];
}

/** Genau eine Zeile erwarten (oder null). */
export async function queryOne<T = unknown>(
  text: string,
  params: unknown[] = []
): Promise<T | null> {
  const rows = await query<T>(text, params);
  return rows[0] ?? null;
}
