/**
 * Integrationstest Frontend ↔ Backend.
 *
 * Fährt den ECHTEN Fastify-Server hoch (mit gemocktem pg-Pool) und prüft, dass
 * die Frontend-Mapper-Logik (aus dem HTML-Prototyp) die echten API-Antworten
 * korrekt ins Card/Detail-Format übersetzt. Das fängt genau die Format-
 * Mismatches ab, die zwischen Backend und Frontend am häufigsten auftreten.
 *
 * Lauf:  node --import tsx test/integration.ts
 */
import { strict as assert } from "node:assert";

// ---- pg mocken (gleiche Strategie wie smoke.ts) ----
const fakeProgramm = {
  id: "11111111-1111-1111-1111-111111111111",
  titel: "BEG Einzelmaßnahmen – Heizungstausch",
  foerdergeber: "BAFA",
  ebene: "bund",
  art: "zuschuss",
  timing: "vor_vorhabenbeginn",
  foerderquote_text: "30 % + Boni, max. 70 %",
  quote_min: 30,
  quote_max: 70,
  max_betrag_text: "bis 21.000 €",
  max_betrag_eur: 21000,
  kurzbeschreibung: "Zuschuss für klimafreundliche Heizungen.",
  besonderheit: "Antrag vor Auftragsvergabe.",
  quelle_url: "bafa.de",
  quelle_stand: "2026-01-15",
  status: "verifiziert",
  aktiv: true,
  kategorien: ["Energie & Gebäude"],
  zielgruppen: ["Privatpersonen / Eigentümer"],
  regionen: ["bundesweit"],
  erfolgsquote: 78,
};
function fakeResultFor(text: string): unknown[] {
  if (text.includes("count(*)")) return [{ total: "1" }];
  if (text.includes("FROM v_programm_voll")) return [fakeProgramm];
  if (text.includes("FROM antragsschritt"))
    return [
      { reihenfolge: 1, titel: "Förderfähigkeit prüfen", beschreibung: "TMA prüfen.", aufwand_text: "30 Min.", frist_bezug: "vor Antrag", erfordert_dokument_typ: null, erfordert_berater: false },
      { reihenfolge: 2, titel: "Experten einbinden", beschreibung: "dena-Fachperson.", aufwand_text: "1–2 Tage", frist_bezug: "vor Antrag", erfordert_dokument_typ: null, erfordert_berater: true },
    ];
  if (text.includes("FROM erfolgsfaktor"))
    return [{ typ: "ablehnungsgrund", text: "Auftrag vor Antrag vergeben", gewicht: 3 }];
  if (text.includes("FROM pflichtunterlage")) return [{ bezeichnung: "Rechnung", pflicht: true }];
  if (text.includes("FROM berater"))
    return [{ id: "22222222-2222-2222-2222-222222222222", name: "Energie Impuls GmbH", qualifikation: "dena-gelistet", region: "berlin", bewertung: 4.9 }];
  if (text.includes("SELECT 1")) return [{ "?column?": 1 }];
  return [];
}
const mockPool = {
  query: async (text: string) => ({ rows: fakeResultFor(text) }),
  on: () => {},
  end: async () => {},
};
const pgModule = await import("pg");
(pgModule.default as unknown as { Pool: unknown }).Pool = function () {
  return mockPool;
} as unknown as never;

// ---- echten Server hochfahren ----
const { default: Fastify } = await import("fastify");
const { finderRoutes } = await import("../src/routes/finder.js");
const { detailRoutes } = await import("../src/routes/detail.js");
const app = Fastify();
await app.register(finderRoutes);
await app.register(detailRoutes);

// ---- Frontend-Mapper (1:1 aus dem HTML-Prototyp übernommen) ----
const EBENE_LABEL: Record<string, string> = { bund: "Bund", land: "Land", eu: "EU", kommune: "Kommune" };
const ART_LABEL: Record<string, string> = { zuschuss: "Zuschuss", kredit: "Kredit", buergschaft: "Bürgschaft", beteiligung: "Beteiligung", beratung: "Beratung", steuer: "Steuer" };
const TIMING_LABEL: Record<string, string> = { vor_vorhabenbeginn: "vor Vorhabenbeginn", laufend: "laufend", stichtag_call: "Call/Stichtag", budget_topf: "Budget-Topf" };
function mapApiProgram(a: any) {
  return {
    id: a.id, title: a.titel, giver: a.foerdergeber || "",
    level: a.ebene, levelLabel: EBENE_LABEL[a.ebene] || a.ebene,
    type: ART_LABEL[a.art] || a.art,
    area: (a.kategorien && a.kategorien[0]) || "",
    who: a.zielgruppen || [],
    funding: a.foerderquote_text || (a.quote_max ? `bis ${a.quote_max} %` : "—"),
    max: a.max_betrag_text || "—",
    deadline: TIMING_LABEL[a.timing] || a.timing,
    success: a.erfolgsquote ?? 50,
    desc: a.kurzbeschreibung || a.besonderheit || "",
    steps: (a.antragspfad || []).map((s: any, i: number) => ({
      t: s.titel, d: s.beschreibung, aufwand: s.aufwand_text || "—",
      frist: s.frist_bezug || "—", done: false, active: i === 0,
      doc: s.erfordert_berater ? "advisor" : undefined,
    })),
    pitfalls: (a.ablehnungsgruende || []).map((x: any) => x.text),
    docs: (a.pflichtunterlagen || []).map((d: any) => d.bezeichnung),
    advisors: (a.berater || []).map((b: any) => ({
      n: b.name, r: b.qualifikation || (b.bewertung ? `${b.bewertung} ★` : "—"),
      init: (b.name || "?").split(" ").map((w: string) => w[0]).join("").slice(0, 2).toUpperCase(),
    })),
  };
}

let passed = 0;
const ok = (n: string) => { passed++; console.log(`  ✓ ${n}`); };

// --- Test 1: Finder-Antwort → Card-Format ---
{
  const res = await app.inject({ method: "GET", url: "/api/programme" });
  const body = res.json();
  const cards = body.programme.map(mapApiProgram);
  const c = cards[0];
  assert.equal(c.title, "BEG Einzelmaßnahmen – Heizungstausch");
  assert.equal(c.levelLabel, "Bund", "ebene → Label gemappt");
  assert.equal(c.type, "Zuschuss", "art → Label gemappt");
  assert.equal(c.deadline, "vor Vorhabenbeginn", "timing → Label gemappt");
  assert.equal(c.success, 78, "Erfolgsquote durchgereicht");
  assert.equal(c.area, "Energie & Gebäude", "erste Kategorie als area");
  ok("Finder-Antwort → Card-Format (alle Felder gemappt)");
}

// --- Test 2: Detail-Antwort → Detail-Format mit Antragspfad ---
{
  const res = await app.inject({ method: "GET", url: "/api/programme/11111111-1111-1111-1111-111111111111" });
  const detail = mapApiProgram(res.json());
  assert.equal(detail.steps.length, 2, "zwei Antragsschritte gemappt");
  assert.equal(detail.steps[0].active, true, "erster Schritt aktiv");
  assert.equal(detail.steps[1].doc, "advisor", "berater-Schritt → advisor-Aktion");
  assert.equal(detail.pitfalls.length, 1, "Ablehnungsgrund gemappt");
  assert.equal(detail.docs[0], "Rechnung", "Pflichtunterlage gemappt");
  assert.equal(detail.advisors[0].init, "EI", "Berater-Initialen aus Name");
  assert.equal(detail.advisors[0].r, "dena-gelistet", "Qualifikation als Rating");
  ok("Detail-Antwort → Detail-Format (Pfad, Fallstricke, Berater)");
}

// --- Test 3: Filter-Query erreicht den Server korrekt ---
{
  const res = await app.inject({ method: "GET", url: "/api/programme?ebene=bund&kategorie=energie_gebaeude" });
  assert.equal(res.statusCode, 200);
  assert.equal(res.json().programme.length, 1);
  ok("Gefilterte Finder-Query liefert Treffer");
}

console.log(`\n${passed} Integrationstests bestanden — Frontend-Mapper passt zur API.`);
await app.close();
process.exit(0);
