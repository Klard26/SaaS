/**
 * Smoke-Test ohne echte Datenbank.
 *
 * Wir mocken den pg-Pool, fahren den echten Fastify-Server hoch und prüfen,
 * dass Routing, Zod-Validierung und SQL-Zusammenbau funktionieren. Die
 * abgesetzten SQL-Strings werden mitgeschnitten und geprüft.
 *
 * Lauf:  node --import tsx test/smoke.ts
 */
import { strict as assert } from "node:assert";

// ---- pg mocken, BEVOR der Pool importiert wird ----
const captured: { text: string; params: unknown[] }[] = [];

const fakeRows: Record<string, unknown[]> = {
  default: [],
};

function fakeResultFor(text: string): unknown[] {
  if (text.includes("count(*)")) return [{ total: "2" }];
  const programmZeile = {
    id: "11111111-1111-1111-1111-111111111111",
    titel: "BEG Einzelmaßnahmen – Heizungstausch",
    foerdergeber: "BAFA",
    ebene: "bund",
    art: "zuschuss",
    timing: "vor_vorhabenbeginn",
    foerderquote_text: "30 % + Boni, max. 70 %",
    quote_min: 30,
    quote_max: 70,
    max_betrag_text: "bis 21.000 €",
    max_betrag_eur: 21000,
    kurzbeschreibung: "Zuschuss für klimafreundliche Heizungen.",
    besonderheit: null,
    quelle_url: "bafa.de",
    quelle_stand: "2026-01-15",
    status: "verifiziert",
    aktiv: true,
    kategorien: ["Energie & Gebäude"],
    zielgruppen: ["Privatpersonen / Eigentümer"],
    regionen: ["bundesweit"],
    erfolgsquote: 78,
  };
  // Detail-Einzelabfrage (WHERE id) ODER Listen-/Match-Abfrage (LIMIT)
  if (text.includes("FROM v_programm_voll")) return [programmZeile];
  if (text.includes("FROM antragsschritt"))
    return [
      {
        reihenfolge: 1,
        titel: "Förderfähigkeit prüfen",
        beschreibung: "TMA abgleichen.",
        aufwand_text: "30 Min.",
        frist_bezug: "vor Antrag",
        erfordert_dokument_typ: null,
        erfordert_berater: false,
      },
    ];
  if (text.includes("FROM erfolgsfaktor"))
    return [{ typ: "ablehnungsgrund", text: "Auftrag vor Antrag vergeben", gewicht: 3 }];
  if (text.includes("FROM pflichtunterlage")) return [{ bezeichnung: "Rechnung", pflicht: true }];
  if (text.includes("FROM berater"))
    return [{ id: "22222222-2222-2222-2222-222222222222", name: "Energie Impuls GmbH", qualifikation: "dena-gelistet", region: "berlin", bewertung: 4.9 }];
  if (text.includes("FROM kategorie")) return [{ slug: "energie_gebaeude", name: "Energie & Gebäude" }];
  if (text.includes("FROM zielgruppe")) return [{ slug: "kmu_klein", name: "Kleine Unternehmen" }];
  if (text.includes("SELECT 1")) return [{ "?column?": 1 }];
  return fakeRows.default;
}

// Modul-Mock für "pg"
const mockPool = {
  query: async (text: string, params: unknown[] = []) => {
    captured.push({ text, params });
    return { rows: fakeResultFor(text) };
  },
  on: () => {},
  end: async () => {},
};

// @ts-expect-error — wir überschreiben das Default-Export-Verhalten von pg im Test
const pgModule = await import("pg");
// Pool-Konstruktor durch unseren Mock ersetzen
(pgModule.default as unknown as { Pool: unknown }).Pool = function () {
  return mockPool;
} as unknown as never;

// Jetzt erst die App importieren (zieht den gemockten Pool)
const { default: Fastify } = await import("fastify");
const { finderRoutes } = await import("../src/routes/finder.js");
const { detailRoutes } = await import("../src/routes/detail.js");
const { matchingRoutes } = await import("../src/routes/matching.js");

const app = Fastify();
await app.register(finderRoutes);
await app.register(detailRoutes);
await app.register(matchingRoutes);

let passed = 0;
function ok(name: string) {
  passed++;
  console.log(`  ✓ ${name}`);
}

// --- Test 1: Finder ohne Filter ---
{
  const res = await app.inject({ method: "GET", url: "/api/programme" });
  assert.equal(res.statusCode, 200, "Finder soll 200 liefern");
  const body = res.json();
  assert.equal(body.total, 2, "total aus count()");
  assert.equal(body.programme.length, 1, "eine Programmzeile");
  assert.equal(body.programme[0].titel, "BEG Einzelmaßnahmen – Heizungstausch");
  ok("GET /api/programme (ohne Filter)");
}

// --- Test 2: Finder mit Filtern → SQL korrekt parametrisiert ---
{
  captured.length = 0;
  const res = await app.inject({
    method: "GET",
    url: "/api/programme?ebene=bund&art=zuschuss&kategorie=energie_gebaeude&suche=Heizung",
  });
  assert.equal(res.statusCode, 200);
  const last = captured[captured.length - 1];
  assert.ok(last.text.includes("vp.ebene = $"), "ebene-Filter im SQL");
  assert.ok(last.text.includes("ANY(vp.kategorien)"), "kategorie-Filter im SQL");
  assert.ok(last.text.includes("ILIKE"), "Suche im SQL");
  assert.ok(last.params.includes("bund"), "Parameter 'bund' gebunden");
  assert.ok(last.params.includes("energie_gebaeude"), "Parameter kategorie gebunden");
  ok("GET /api/programme (Filter → parametrisiertes SQL)");
}

// --- Test 3: Ungültiger Filter → 400 ---
{
  const res = await app.inject({ method: "GET", url: "/api/programme?ebene=quatsch" });
  assert.equal(res.statusCode, 400, "ungültiger ENUM-Wert → 400");
  ok("GET /api/programme (ungültiger Filter → 400)");
}

// --- Test 4: Detail mit gültiger UUID ---
{
  const res = await app.inject({
    method: "GET",
    url: "/api/programme/11111111-1111-1111-1111-111111111111",
  });
  assert.equal(res.statusCode, 200);
  const body = res.json();
  assert.ok("antragspfad" in body, "Detail enthält antragspfad");
  assert.ok("ablehnungsgruende" in body, "Detail enthält ablehnungsgruende");
  assert.ok(Array.isArray(body.berater), "Detail enthält berater-Array");
  ok("GET /api/programme/:id (Detail-Struktur)");
}

// --- Test 5: Detail mit ungültiger UUID → 400 ---
{
  const res = await app.inject({ method: "GET", url: "/api/programme/keine-uuid" });
  assert.equal(res.statusCode, 400, "ungültige UUID → 400");
  ok("GET /api/programme/:id (ungültige UUID → 400)");
}

// --- Test 6: Matching ---
{
  captured.length = 0;
  const res = await app.inject({
    method: "POST",
    url: "/api/match",
    payload: { zielgruppe: "privat", region: "berlin", kategorien: ["energie_gebaeude"] },
  });
  assert.equal(res.statusCode, 200);
  const last = captured[captured.length - 1];
  assert.ok(last.text.includes("ANY(vp.zielgruppen)"), "zielgruppe im Match-SQL");
  assert.ok(last.text.includes("bundesweit"), "Region inkl. bundesweit-Fallback");
  assert.ok(last.text.includes("&&"), "Kategorien-Overlap-Operator");
  ok("POST /api/match (Profil → SQL)");
}

console.log(`\n${passed} Tests bestanden.`);
await app.close();
process.exit(0);
