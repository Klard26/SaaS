/**
 * Smoke-Test Energieausweis-Modul (ohne echte DB).
 * Fährt den echten Server hoch (gemockter pg-Pool) und prüft die Kern-Flows:
 * GModG-Typ-Weiche, Ausweis anlegen, Erfassung, Funnel-Übergabe.
 *
 * Lauf:  node --import tsx test/energieausweis.smoke.ts
 */
import { strict as assert } from "node:assert";

const captured: { text: string; params: unknown[] }[] = [];

/** Antwort-Mock je nach SQL-Inhalt. */
function fakeResultFor(text: string, params: unknown[]): unknown[] {
  // Typ-Weiche: Antwort hängt von der Nutzung (erster Param) ab
  if (text.includes("bestimme_ausweistyp")) {
    const nutzung = params[0];
    if (nutzung === "mischgebaeude")
      return [{ erzwungener_typ: "bedarfsausweis", wahlfreiheit: false, begruendung: "Mischnutzung: kein Verbrauchsausweis (GModG)." }];
    if (nutzung === "wohngebaeude")
      return [{ erzwungener_typ: null, wahlfreiheit: true, begruendung: "Wohngebäude: Wahlfreiheit." }];
    return [{ erzwungener_typ: "bedarfsausweis", wahlfreiheit: false, begruendung: "NWG: Bedarfsausweis." }];
  }
  if (text.includes("INSERT INTO energieausweis.gebaeude"))
    return [{ id: "aaaa1111-1111-1111-1111-111111111111", nutzung: params[5], daten_quelle: params[10] }];
  if (text.includes("INSERT INTO energieausweis.ausweis"))
    return [{ id: "bbbb2222-2222-2222-2222-222222222222", gebaeude_id: params[0], typ: params[1], status: "entwurf", preis_eur: 119.95 }];
  if (text.includes("SELECT id FROM energieausweis.ausweis"))
    return [{ id: params[0] }];
  if (text.includes("INSERT INTO energieausweis.erfassung")) return [];
  if (text.includes("FROM energieausweis.erfassung"))
    return [{ feld: "verbrauch_2024", wert: "18500", einheit: "kWh", geprueft: false }];
  if (text.includes("FROM energieausweis.empfehlung")) return [];
  if (text.includes("v_programm_voll"))
    return [{ id: "cccc3333-3333-3333-3333-333333333333" }, { id: "dddd4444-4444-4444-4444-444444444444" }];
  if (text.includes("INSERT INTO energieausweis.foerder_anschluss")) return [];
  if (text.includes("FROM energieausweis.foerder_anschluss"))
    return [{ programm_id: "cccc3333-3333-3333-3333-333333333333", titel: "BEG Heizungstausch", relevanz: 1 }];
  if (text.includes("JOIN energieausweis.gebaeude"))
    return [{ id: params[0], typ: "bedarfsausweis", status: "entwurf", nutzung: "mischgebaeude", baujahr: 1992 }];
  if (text.includes("SELECT 1")) return [{ "?column?": 1 }];
  return [];
}

const mockPool = {
  query: async (text: string, params: unknown[] = []) => {
    captured.push({ text, params });
    return { rows: fakeResultFor(text, params) };
  },
  on: () => {},
  end: async () => {},
};
const pgModule = await import("pg");
(pgModule.default as unknown as { Pool: unknown }).Pool = function () {
  return mockPool;
} as unknown as never;

const { default: Fastify } = await import("fastify");
const { energieausweisRoutes } = await import("../src/routes/energieausweis.js");
const app = Fastify();
await app.register(energieausweisRoutes);

let passed = 0;
const ok = (n: string) => { passed++; console.log(`  ✓ ${n}`); };

// --- Test 1: Typ-Weiche Mischgebäude → Bedarfsausweis erzwungen ---
{
  const res = await app.inject({ method: "GET", url: "/api/energieausweis/typ-weiche?nutzung=mischgebaeude&baujahr=1992&wohneinheiten=6" });
  assert.equal(res.statusCode, 200);
  const b = res.json();
  assert.equal(b.empfohlener_typ, "bedarfsausweis", "Mischgebäude → Bedarfsausweis");
  assert.equal(b.wahlfreiheit, false, "keine Wahlfreiheit bei Mischnutzung");
  ok("Typ-Weiche: Mischgebäude → Bedarfsausweis (GModG)");
}

// --- Test 2: Typ-Weiche Wohngebäude → Wahlfreiheit, Default Verbrauch ---
{
  const res = await app.inject({ method: "GET", url: "/api/energieausweis/typ-weiche?nutzung=wohngebaeude" });
  const b = res.json();
  assert.equal(b.wahlfreiheit, true, "Wohngebäude hat Wahlfreiheit");
  assert.equal(b.empfohlener_typ, "verbrauchsausweis", "Default bei Wahlfreiheit = Verbrauch");
  ok("Typ-Weiche: Wohngebäude → Wahlfreiheit");
}

// --- Test 3: ungültige Nutzung → 400 ---
{
  const res = await app.inject({ method: "GET", url: "/api/energieausweis/typ-weiche?nutzung=schloss" });
  assert.equal(res.statusCode, 400);
  ok("Typ-Weiche: ungültige Nutzung → 400");
}

// --- Test 4: Ausweis anlegen → Gebäude + Ausweis + Typentscheidung ---
{
  const res = await app.inject({
    method: "POST",
    url: "/api/energieausweis",
    payload: { nutzung: "mischgebaeude", baujahr: 1992, wohneinheiten: 6, ort: "Berlin", daten_quelle: "planflux" },
  });
  assert.equal(res.statusCode, 201);
  const b = res.json();
  assert.ok(b.gebaeude.id, "Gebäude angelegt");
  assert.equal(b.ausweis.typ, "bedarfsausweis", "Ausweistyp aus Weiche");
  assert.equal(b.typ_entscheidung.empfohlener_typ, "bedarfsausweis");
  ok("POST /api/energieausweis (Gebäude + Ausweis + Typ-Weiche)");
}

// --- Test 5: Erfassung speichern (Upsert) ---
{
  const res = await app.inject({
    method: "POST",
    url: "/api/energieausweis/bbbb2222-2222-2222-2222-222222222222/erfassung",
    payload: { felder: [{ feld: "verbrauch_2024", wert: "18500", einheit: "kWh" }] },
  });
  assert.equal(res.statusCode, 200);
  const last = captured.find((c) => c.text.includes("ON CONFLICT (ausweis_id, feld)"));
  assert.ok(last, "Upsert-SQL mit ON CONFLICT verwendet");
  ok("POST /:id/erfassung (Upsert je Feld)");
}

// --- Test 6: Funnel-Verknüpfung erzeugen ---
{
  const res = await app.inject({
    method: "POST",
    url: "/api/energieausweis/bbbb2222-2222-2222-2222-222222222222/foerder-anschluss",
  });
  assert.equal(res.statusCode, 200);
  const b = res.json();
  assert.equal(b.angelegte_anschluesse, 2, "zwei Programme verknüpft");
  ok("POST /:id/foerder-anschluss (Funnel-Verknüpfung)");
}

// --- Test 7: Funnel-Übergabe lesen ---
{
  const res = await app.inject({
    method: "GET",
    url: "/api/energieausweis/bbbb2222-2222-2222-2222-222222222222/foerder-anschluss",
  });
  assert.equal(res.statusCode, 200);
  const b = res.json();
  assert.equal(b.foerderprogramme[0].titel, "BEG Heizungstausch");
  ok("GET /:id/foerder-anschluss (Funnel ins Förderpilot-Kerngeschäft)");
}

console.log(`\n${passed} Energieausweis-Tests bestanden.`);
await app.close();
process.exit(0);
