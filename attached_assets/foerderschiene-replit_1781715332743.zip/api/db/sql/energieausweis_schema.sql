-- ============================================================================
--  ENERGIEAUSWEIS-MODUL — PostgreSQL-Schema
--  Erweiterung der Förderpilot-Plattform um einen Energieausweis-Service.
--  Stand: Juni 2026 · PostgreSQL 14+
--
--  Designprinzipien (konsistent zum foerderpilot-Schema):
--    • Eigenes Schema "energieausweis", aber Wiederverwendung der vorhandenen
--      Tabellen aus "foerderpilot" (berater, nutzer, programm) per FK.
--    • Amtliche/fachliche Daten getrennt von Prozess-/Anreicherungsdaten.
--    • GModG-2026-konforme Ausweistyp-Logik als Regelschicht.
--    • Energieausweis als Top-of-Funnel: foerder_anschluss verknüpft das
--      Ergebnis mit foerderpilot.programm (Sanierungs-/Förderempfehlung).
--
--  Voraussetzung: foerderpilot_schema.sql ist bereits eingespielt
--  (liefert das Schema "foerderpilot" mit berater/nutzer/programm).
-- ============================================================================

BEGIN;

DROP SCHEMA IF EXISTS energieausweis CASCADE;
CREATE SCHEMA energieausweis;
SET search_path TO energieausweis, foerderpilot, public;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ============================================================================
-- 1. ENUM-TYPEN
-- ============================================================================

-- Nutzungstyp des Gebäudes (treibt die GModG-Ausweistyp-Weiche)
CREATE TYPE nutzungstyp AS ENUM (
    'wohngebaeude',        -- ausschließlich Wohnzwecke
    'nichtwohngebaeude',   -- ausschließlich Nichtwohnzwecke
    'mischgebaeude'        -- gemischt (Wohnen + Gewerbe)
);

-- Ausweistyp nach GModG/GEG
CREATE TYPE ausweistyp AS ENUM (
    'verbrauchsausweis',   -- auf Basis gemessenen Verbrauchs
    'bedarfsausweis'       -- auf Basis energetischer Bilanzierung (DIN V 18599)
);

-- Status im Bearbeitungs-Workflow
CREATE TYPE ausweis_status AS ENUM (
    'entwurf',             -- Datenerfassung läuft
    'in_pruefung',         -- fachliche Prüfung / Bilanzierung
    'experten_freigabe',   -- wartet auf dena-Experten-Freigabe
    'registriert',         -- beim DIBt registriert
    'ausgestellt',         -- fertiges PDF verfügbar
    'storniert'
);

-- Energieeffizienzklasse (GModG: Wohngebäude weiterhin A+ … H)
CREATE TYPE effizienzklasse AS ENUM (
    'A_plus','A','B','C','D','E','F','G','H'
);

-- Herkunft der Gebäudedaten
CREATE TYPE datenquelle AS ENUM ('manuell', 'planflux', 'import');

-- Berechnungsverfahren der Bewertung
CREATE TYPE bewertungsverfahren AS ENUM ('verbrauch', 'din_v_18599');

-- ============================================================================
-- 2. GEBÄUDE (Stammdaten des Objekts)
-- ============================================================================
CREATE TABLE gebaeude (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    -- optionaler Bezug zum Plattform-Nutzer (Eigentümer)
    nutzer_id       UUID REFERENCES foerderpilot.nutzer(id) ON DELETE SET NULL,

    -- Adresse
    strasse         TEXT,
    plz             TEXT,
    ort             TEXT,
    bundesland      foerderpilot.bundesland,   -- Wiederverwendung des ENUMs

    -- Energetisch relevante Stammdaten
    baujahr         INTEGER CHECK (baujahr BETWEEN 1800 AND 2100),
    nutzung         nutzungstyp NOT NULL,
    wohnflaeche_m2  NUMERIC(10,2),
    nutzflaeche_m2  NUMERIC(10,2),
    wohneinheiten   INTEGER,
    heizung_traeger TEXT,                       -- z. B. 'erdgas','waermepumpe','oel'

    -- Datenherkunft (PLANFLUX-Import erhöht Datenqualität)
    daten_quelle    datenquelle NOT NULL DEFAULT 'manuell',
    planflux_ref    TEXT,                       -- Referenz auf PLANFLUX-Projekt

    erstellt_am     TIMESTAMPTZ NOT NULL DEFAULT now()
);
COMMENT ON TABLE gebaeude IS 'Objektstammdaten. Flächen können aus PLANFLUX übernommen werden.';

-- ============================================================================
-- 3. AUSWEISTYP-WEICHE (GModG-Regelschicht)
--    Bestimmt regelbasiert den zulässigen Ausweistyp — wartbar als Daten,
--    damit Gesetzesänderungen ohne Code-Deploy nachgezogen werden können.
-- ============================================================================
CREATE TABLE typ_regel (
    id              SMALLSERIAL PRIMARY KEY,
    nutzung         nutzungstyp NOT NULL,
    baujahr_bis     INTEGER,                    -- NULL = unbegrenzt
    wohneinheiten_bis INTEGER,                  -- NULL = unbegrenzt
    erzwungener_typ ausweistyp,                 -- NULL = Wahlfreiheit
    wahlfreiheit    BOOLEAN NOT NULL DEFAULT FALSE,
    begruendung     TEXT,
    rechtsstand     TEXT,                        -- z. B. 'GModG-Entwurf 2026'
    gueltig_ab      DATE
);
COMMENT ON TABLE typ_regel IS 'Regelbasierte Ausweistyp-Bestimmung. Als Daten pflegbar (GModG-Änderungen ohne Deploy).';

-- ============================================================================
-- 4. ENERGIEAUSWEIS (zentrale Prozess-Entität)
-- ============================================================================
CREATE TABLE ausweis (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    gebaeude_id     UUID NOT NULL REFERENCES gebaeude(id) ON DELETE CASCADE,

    typ             ausweistyp NOT NULL,
    status          ausweis_status NOT NULL DEFAULT 'entwurf',

    -- Ergebnis (nach Bewertung)
    kennwert_kwh_m2a NUMERIC(8,2),              -- End-/Verbrauchskennwert
    effizienz       effizienzklasse,

    -- Registrierung & Gültigkeit
    dibt_nr         TEXT,                        -- DIBt-Registriernummer
    ausgestellt_am  DATE,
    gueltig_bis     DATE,                        -- i. d. R. +10 Jahre

    -- kaufmännisch
    preis_eur       NUMERIC(8,2),                -- berechneter Verkaufspreis
    pdf_pfad        TEXT,

    erstellt_am     TIMESTAMPTZ NOT NULL DEFAULT now(),
    aktualisiert_am TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- 5. DATENERFASSUNG (geführte Formularstrecke + Pflichtprüfung)
--    Erfüllt die gesetzliche Prüfpflicht: jede Eingabe kann als geprüft
--    markiert werden (geprueft=TRUE) inkl. Prüfhinweis.
-- ============================================================================
CREATE TABLE erfassung (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ausweis_id      UUID NOT NULL REFERENCES ausweis(id) ON DELETE CASCADE,
    feld            TEXT NOT NULL,               -- z. B. 'verbrauch_2024'
    wert            TEXT,
    einheit         TEXT,
    geprueft        BOOLEAN NOT NULL DEFAULT FALSE,
    pruef_hinweis   TEXT,
    UNIQUE (ausweis_id, feld)
);

-- ============================================================================
-- 6. BEWERTUNG (Verbrauchsauswertung bzw. DIN-V-18599-Bilanzierung)
-- ============================================================================
CREATE TABLE bewertung (
    ausweis_id      UUID PRIMARY KEY REFERENCES ausweis(id) ON DELETE CASCADE,
    verfahren       bewertungsverfahren NOT NULL,
    primaerenergie_kwh_m2a  NUMERIC(8,2),
    endenergie_kwh_m2a      NUMERIC(8,2),
    nutzenergie_kwh_m2a     NUMERIC(8,2),
    thg_emissionen_kg_m2a   NUMERIC(8,2),        -- GModG: neue Pflichtangabe
    ee_anteil_prozent       NUMERIC(5,2),        -- erneuerbarer Anteil
    erfassungszeitraum_monate INTEGER,           -- GModG: künftig 24
    letzte_abrechnung       DATE,                -- GModG: max. 15 Mon. alt
    berechnet_am    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- 7. EXPERTEN-ESKALATION (dena-Experte prüft/freigibt — über Klard-Buchung)
--    Wiederverwendung von foerderpilot.berater als Experten-Pool.
-- ============================================================================
CREATE TABLE eskalation (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ausweis_id      UUID NOT NULL REFERENCES ausweis(id) ON DELETE CASCADE,
    berater_id      UUID REFERENCES foerderpilot.berater(id),
    status          TEXT NOT NULL DEFAULT 'offen'
                    CHECK (status IN ('offen','in_pruefung','freigegeben','abgelehnt')),
    klard_buchung_id TEXT,                       -- Referenz auf Klard-Termin
    pruef_kommentar TEXT,
    freigabe_am     TIMESTAMPTZ,
    erstellt_am     TIMESTAMPTZ NOT NULL DEFAULT now()
);
COMMENT ON TABLE eskalation IS 'Fachliche Freigabe anspruchsvoller Fälle durch dena-gelistete Berater (Energie Impuls / Netz).';

-- ============================================================================
-- 8. MODERNISIERUNGSEMPFEHLUNGEN (Pflichtteil) + FÖRDER-ANSCHLUSS
--    Der Brückenkopf zum Kerngeschäft: aus dem Ausweis-Ergebnis werden
--    passende Förderprogramme (foerderpilot.programm) abgeleitet.
-- ============================================================================
CREATE TABLE empfehlung (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ausweis_id      UUID NOT NULL REFERENCES ausweis(id) ON DELETE CASCADE,
    massnahme       TEXT NOT NULL,               -- z. B. 'Dämmung Außenwand'
    einspar_potenzial_prozent NUMERIC(5,2),
    reihenfolge     SMALLINT
);

CREATE TABLE foerder_anschluss (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ausweis_id      UUID NOT NULL REFERENCES ausweis(id) ON DELETE CASCADE,
    -- Verknüpfung ins Förderpilot-Kerngeschäft:
    programm_id     UUID REFERENCES foerderpilot.programm(id),
    empfehlung_id   UUID REFERENCES empfehlung(id) ON DELETE SET NULL,
    relevanz        SMALLINT DEFAULT 1,          -- Ranking der Passung
    erstellt_am     TIMESTAMPTZ NOT NULL DEFAULT now()
);
COMMENT ON TABLE foerder_anschluss IS 'Top-of-Funnel: Ausweis-Ergebnis -> passende Förderprogramme aus foerderpilot.';

-- ============================================================================
-- 9. KAUFMÄNNISCH: Preisliste + Partner (B2B2C-Vertrieb)
-- ============================================================================
CREATE TABLE preis (
    typ             ausweistyp PRIMARY KEY,
    basispreis_eur  NUMERIC(8,2) NOT NULL,
    beschreibung    TEXT
);

CREATE TABLE partner (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            TEXT NOT NULL,
    typ             TEXT NOT NULL CHECK (typ IN ('makler','hausverwalter','affiliate')),
    provision_prozent NUMERIC(5,2),              -- Lead-/Vermittlungsprovision
    aktiv           BOOLEAN NOT NULL DEFAULT TRUE,
    erstellt_am     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Welcher Ausweis kam über welchen Partner (für Provisions-/Funnel-Tracking)
CREATE TABLE ausweis_partner (
    ausweis_id      UUID PRIMARY KEY REFERENCES ausweis(id) ON DELETE CASCADE,
    partner_id      UUID NOT NULL REFERENCES partner(id),
    provision_eur   NUMERIC(8,2)
);

-- ============================================================================
-- 10. INDIZES, TRIGGER, VIEWS
-- ============================================================================
CREATE INDEX idx_ausweis_status   ON ausweis(status);
CREATE INDEX idx_ausweis_gebaeude ON ausweis(gebaeude_id);
CREATE INDEX idx_erfassung_ausweis ON erfassung(ausweis_id);
CREATE INDEX idx_eskalation_ausweis ON eskalation(ausweis_id);
CREATE INDEX idx_foerder_ausweis  ON foerder_anschluss(ausweis_id);
CREATE INDEX idx_gebaeude_nutzung ON gebaeude(nutzung);

CREATE OR REPLACE FUNCTION set_aktualisiert_am() RETURNS trigger AS $$
BEGIN NEW.aktualisiert_am = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ausweis_update
    BEFORE UPDATE ON ausweis
    FOR EACH ROW EXECUTE FUNCTION set_aktualisiert_am();

-- Ausweistyp-Weiche als Funktion: liefert zulässigen Typ + Wahlfreiheit
CREATE OR REPLACE FUNCTION bestimme_ausweistyp(
    p_nutzung nutzungstyp,
    p_baujahr INTEGER DEFAULT NULL,
    p_wohneinheiten INTEGER DEFAULT NULL
) RETURNS TABLE (erzwungener_typ ausweistyp, wahlfreiheit BOOLEAN, begruendung TEXT) AS $$
    SELECT r.erzwungener_typ, r.wahlfreiheit, r.begruendung
    FROM typ_regel r
    WHERE r.nutzung = p_nutzung
      AND (r.baujahr_bis IS NULL OR p_baujahr IS NULL OR p_baujahr <= r.baujahr_bis)
      AND (r.wohneinheiten_bis IS NULL OR p_wohneinheiten IS NULL OR p_wohneinheiten <= r.wohneinheiten_bis)
    ORDER BY r.gueltig_ab DESC NULLS LAST
    LIMIT 1;
$$ LANGUAGE sql STABLE;

-- Funnel-View: Ausweis + Gebäude + Anzahl Förderanschlüsse (für Reporting)
CREATE VIEW v_ausweis_funnel AS
SELECT
    a.id, a.typ, a.status, a.effizienz, a.preis_eur,
    g.nutzung, g.bundesland, g.baujahr,
    (SELECT count(*) FROM foerder_anschluss f WHERE f.ausweis_id = a.id) AS foerder_treffer,
    (SELECT count(*) FROM eskalation e WHERE e.ausweis_id = a.id) AS eskalationen,
    a.erstellt_am
FROM ausweis a
JOIN gebaeude g ON g.id = a.gebaeude_id;

-- ============================================================================
-- 11. SEED — GModG-konforme Typ-Regeln + Preise
-- ============================================================================

-- Preise (aus dem Konzept / Marktbeobachtung)
INSERT INTO preis (typ, basispreis_eur, beschreibung) VALUES
 ('verbrauchsausweis', 69.95,  'Auf Basis gemessenen Verbrauchs, nur Wohngebäude (GModG)'),
 ('bedarfsausweis',    119.95, 'Bilanziert (DIN V 18599), inkl. Experten-Freigabe bei Bedarf');

-- Ausweistyp-Regeln nach GModG-Entwurf 2026
INSERT INTO typ_regel (nutzung, baujahr_bis, wohneinheiten_bis, erzwungener_typ, wahlfreiheit, begruendung, rechtsstand, gueltig_ab) VALUES
 -- Wohngebäude: grundsätzlich Wahlfreiheit ...
 ('wohngebaeude', NULL, NULL, NULL, TRUE,
  'Reine Wohngebäude: Wahlfreiheit zwischen Bedarfs- und Verbrauchsausweis.', 'GModG-Entwurf 2026', DATE '2026-07-01'),
 -- ... Ausnahme: kleine, alte, unsanierte Wohngebäude → Bedarfsausweis-Pflicht (WSchVO 1978)
 ('wohngebaeude', 1977, 4, 'bedarfsausweis', FALSE,
  'Wohngebäude mit ≤ 4 WE, Baujahr bis 1977 und ohne Erfüllung WSchVO 1977: Bedarfsausweis-Pflicht.', 'GEG/GModG', DATE '2026-07-01'),
 -- Misch- und Nichtwohngebäude: kein Verbrauchsausweis mehr zulässig
 ('mischgebaeude', NULL, NULL, 'bedarfsausweis', FALSE,
  'Mischnutzung: Verbrauchsausweis nach GModG nicht mehr zulässig — Bedarfsausweis erforderlich.', 'GModG-Entwurf 2026', DATE '2026-07-01'),
 ('nichtwohngebaeude', NULL, NULL, 'bedarfsausweis', FALSE,
  'Nichtwohngebäude: Bedarfsausweis erforderlich (kein Verbrauchsausweis mehr).', 'GModG-Entwurf 2026', DATE '2026-07-01');

-- ----------------------------------------------------------------------------
-- Beispiel: Mischgebäude (Laden + Wohnungen) komplett durchgespielt
-- ----------------------------------------------------------------------------
DO $$
DECLARE v_geb UUID; v_ausw UUID; v_typ ausweistyp; v_wahl BOOLEAN; v_begr TEXT;
BEGIN
    INSERT INTO gebaeude (strasse, plz, ort, bundesland, baujahr, nutzung,
        wohnflaeche_m2, nutzflaeche_m2, wohneinheiten, heizung_traeger, daten_quelle)
    VALUES ('Beispielstraße 5', '10115', 'Berlin', 'berlin', 1992, 'mischgebaeude',
        420.0, 110.0, 6, 'erdgas', 'planflux')
    RETURNING id INTO v_geb;

    -- Typ-Weiche anwenden
    SELECT erzwungener_typ, wahlfreiheit, begruendung
      INTO v_typ, v_wahl, v_begr
      FROM bestimme_ausweistyp('mischgebaeude', 1992, 6);

    INSERT INTO ausweis (gebaeude_id, typ, status, preis_eur)
    VALUES (v_geb, COALESCE(v_typ,'bedarfsausweis'), 'in_pruefung',
        (SELECT basispreis_eur FROM preis WHERE typ = COALESCE(v_typ,'bedarfsausweis')))
    RETURNING id INTO v_ausw;

    INSERT INTO empfehlung (ausweis_id, massnahme, einspar_potenzial_prozent, reihenfolge) VALUES
        (v_ausw, 'Heizungstausch auf Wärmepumpe', 25.0, 1),
        (v_ausw, 'Dämmung oberste Geschossdecke', 8.0, 2);

    -- Förder-Anschluss ins Kerngeschäft (verknüpft mit Förderpilot-Programm, falls vorhanden)
    INSERT INTO foerder_anschluss (ausweis_id, programm_id, relevanz)
    SELECT v_ausw, p.id, 1
      FROM foerderpilot.programm p
     WHERE p.titel ILIKE 'BEG%Heizungstausch%'
     LIMIT 1;
END $$;

COMMIT;

-- ============================================================================
--  Beispielabfragen:
--
--  -- Zulässigen Ausweistyp für ein Objekt bestimmen:
--  SELECT * FROM bestimme_ausweistyp('mischgebaeude', 1992, 6);
--
--  -- Funnel-Reporting: wie viele Ausweise münden in Förderanschlüsse?
--  SELECT typ, status, foerder_treffer FROM v_ausweis_funnel;
--
--  -- Umsatz nach Ausweistyp:
--  SELECT typ, count(*), sum(preis_eur) FROM ausweis GROUP BY typ;
-- ============================================================================
