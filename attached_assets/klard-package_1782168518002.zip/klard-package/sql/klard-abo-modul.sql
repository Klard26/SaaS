-- ═══════════════════════════════════════════════════════════════
-- Klard — Abo-Tier-Modul · SQL Migration
-- Ergänzt das Anfrage-/Angebots-Modul um Subscriptions
-- Voraussetzung: klard-anfragen-modul.sql wurde bereits eingespielt
-- ═══════════════════════════════════════════════════════════════

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 1. subscription_plans — Tier-Definitionen (konfigurierbar)   │
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS subscription_plans (
    tier                TEXT PRIMARY KEY
                        CHECK (tier IN ('free','plus','pro')),
    name                TEXT NOT NULL,
    price_monthly       NUMERIC(10,2) NOT NULL DEFAULT 0,
    stripe_price_id     TEXT,
    -- Limits & Features
    max_leads_month     INTEGER,          -- NULL = unbegrenzt
    lead_discount_pct   NUMERIC(5,2) DEFAULT 0,
    verified_badge      BOOLEAN DEFAULT FALSE,
    ranking_boost       INTEGER DEFAULT 0,  -- höher = bessere Platzierung
    multi_location      BOOLEAN DEFAULT FALSE,
    api_access          BOOLEAN DEFAULT FALSE,
    priority_support    BOOLEAN DEFAULT FALSE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO subscription_plans
  (tier, name, price_monthly, max_leads_month, lead_discount_pct,
   verified_badge, ranking_boost, multi_location, api_access, priority_support)
VALUES
  ('free','Klard Free',  0.00,   3, 0,   FALSE, 0, FALSE, FALSE, FALSE),
  ('plus','Klard Plus', 29.00, NULL, 10, TRUE, 10, FALSE, FALSE, FALSE),
  ('pro', 'Klard Pro',  79.00, NULL, 20, TRUE, 25, TRUE,  TRUE,  TRUE)
ON CONFLICT (tier) DO UPDATE SET
  name = EXCLUDED.name,
  price_monthly = EXCLUDED.price_monthly,
  max_leads_month = EXCLUDED.max_leads_month,
  lead_discount_pct = EXCLUDED.lead_discount_pct,
  verified_badge = EXCLUDED.verified_badge,
  ranking_boost = EXCLUDED.ranking_boost,
  multi_location = EXCLUDED.multi_location,
  api_access = EXCLUDED.api_access,
  priority_support = EXCLUDED.priority_support;

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 2. subscriptions — aktive Abos je Anbieter                   │
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS subscriptions (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider_id             UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    tier                    TEXT NOT NULL REFERENCES subscription_plans(tier),
    stripe_subscription_id  TEXT,
    stripe_customer_id      TEXT,
    status                  TEXT NOT NULL DEFAULT 'active'
                            CHECK (status IN ('active','past_due','canceled','trialing')),
    current_period_end      TIMESTAMPTZ,
    cancel_at_period_end    BOOLEAN DEFAULT FALSE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (provider_id)
);

CREATE INDEX IF NOT EXISTS idx_subs_provider ON subscriptions(provider_id);
CREATE INDEX IF NOT EXISTS idx_subs_status   ON subscriptions(status);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 3. lead_usage — Monatszähler für Lead-Limits (Free-Tier)     │
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS lead_usage (
    provider_id     UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    period_month    DATE NOT NULL,  -- erster Tag des Monats
    leads_used      INTEGER NOT NULL DEFAULT 0,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (provider_id, period_month)
);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 4. View: effektive Anbieter-Berechtigungen (Routes lesen das)│
-- └─────────────────────────────────────────────────────────────┘
CREATE OR REPLACE VIEW provider_entitlements AS
SELECT
    p.id AS provider_id,
    COALESCE(s.tier, 'free')                 AS tier,
    COALESCE(s.status, 'active')             AS sub_status,
    sp.max_leads_month,
    sp.lead_discount_pct,
    sp.verified_badge AS tier_grants_badge,
    sp.ranking_boost,
    sp.multi_location,
    sp.api_access,
    sp.priority_support,
    s.current_period_end
FROM providers p
LEFT JOIN subscriptions s
       ON s.provider_id = p.id AND s.status IN ('active','trialing')
LEFT JOIN subscription_plans sp
       ON sp.tier = COALESCE(s.tier, 'free');
