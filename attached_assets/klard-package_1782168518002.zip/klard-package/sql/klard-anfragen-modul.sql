-- ═══════════════════════════════════════════════════════════════
-- Klard — Anfrage-/Angebots-Modul (Pay-per-Lead + Erfolgsprovision)
-- Migration: dockt an bestehendes Schema an
-- (branches, service_categories, service_templates, providers, provider_services)
-- Target: Supabase / PostgreSQL / Replit DB
-- ═══════════════════════════════════════════════════════════════

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 1. requests — Kundenanfragen (Lead-Quelle)                   │
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS requests (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    -- Kundenbezug (customers-Tabelle existiert bereits aus Buchungs-Setup)
    customer_id         UUID REFERENCES customers(id) ON DELETE SET NULL,
    customer_name       TEXT NOT NULL,
    customer_email      TEXT NOT NULL,
    customer_phone      TEXT,
    -- Was wird gesucht
    branch_id           TEXT REFERENCES branches(id),
    category_id         UUID REFERENCES service_categories(id),
    service_template_id UUID REFERENCES service_templates(id),
    title               TEXT NOT NULL,
    description         TEXT,
    -- Strukturierte Antworten aus dem dynamischen Formular (JSONB)
    answers             JSONB DEFAULT '{}'::jsonb,
    -- Objekt-/Standortdaten für Umkreis-Matching
    postal_code         TEXT,
    city                TEXT,
    -- Budget-Indikation (optional, vom Kunden)
    budget_min          NUMERIC(10,2),
    budget_max          NUMERIC(10,2),
    -- Zeitliche Dringlichkeit
    urgency             TEXT DEFAULT 'flexibel'
                        CHECK (urgency IN ('sofort','2_wochen','1_monat','flexibel')),
    -- Förder-Flag: braucht Kunde BAFA/KfW-Bezug? (Klard-USP)
    funding_relevant    BOOLEAN DEFAULT FALSE,
    -- Wie viele Anbieter dürfen antworten (Qualitäts-Cap wie Armut)
    max_offers          INTEGER NOT NULL DEFAULT 3,
    -- DSGVO: Einwilligung zur Datenweitergabe an Anbieter
    consent_data_share  BOOLEAN NOT NULL DEFAULT FALSE,
    consent_timestamp   TIMESTAMPTZ,
    -- Lifecycle
    status              TEXT NOT NULL DEFAULT 'open'
                        CHECK (status IN ('open','matched','closed','expired','fulfilled')),
    expires_at          TIMESTAMPTZ DEFAULT (now() + INTERVAL '14 days'),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_requests_branch    ON requests(branch_id);
CREATE INDEX IF NOT EXISTS idx_requests_category  ON requests(category_id);
CREATE INDEX IF NOT EXISTS idx_requests_status    ON requests(status);
CREATE INDEX IF NOT EXISTS idx_requests_postal    ON requests(postal_code);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 2. request_matches — welcher Anbieter sieht welche Anfrage   │
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS request_matches (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_id      UUID NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
    provider_id     UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    -- Match-Qualität (für Ranking / spätere ML)
    match_score     NUMERIC(5,2) DEFAULT 0,
    distance_km     NUMERIC(6,1),
    -- Wurde der Anbieter benachrichtigt?
    notified_at     TIMESTAMPTZ,
    -- Hat der Anbieter die Anfrage angesehen?
    viewed_at       TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (request_id, provider_id)
);

CREATE INDEX IF NOT EXISTS idx_matches_request  ON request_matches(request_id);
CREATE INDEX IF NOT EXISTS idx_matches_provider ON request_matches(provider_id);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 3. lead_fees — Pay-per-Lead Abrechnung (Umsatz VOR Abschluss)│
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS lead_fees (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider_id         UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    request_id          UUID NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
    -- Dynamischer Lead-Preis (höherwertige Leads = teurer)
    amount              NUMERIC(10,2) NOT NULL,
    currency            TEXT NOT NULL DEFAULT 'EUR',
    -- Stripe-Bezug
    stripe_payment_id   TEXT,
    -- Wallet/Guthaben-Modell statt Einzelabbuchung (empfohlen)
    paid_from_credit    BOOLEAN DEFAULT FALSE,
    status              TEXT NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','paid','refunded','failed')),
    -- Lead-Garantie: Rückerstattung bei totem Lead (Armut-Mechanik)
    refund_reason       TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (provider_id, request_id)
);

CREATE INDEX IF NOT EXISTS idx_leadfees_provider ON lead_fees(provider_id);
CREATE INDEX IF NOT EXISTS idx_leadfees_status   ON lead_fees(status);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 4. offers — Angebote der Anbieter auf eine Anfrage           │
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS offers (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_id          UUID NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
    provider_id         UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    lead_fee_id         UUID REFERENCES lead_fees(id) ON DELETE SET NULL,
    -- Angebotsinhalt
    price               NUMERIC(10,2) NOT NULL,
    price_type          TEXT DEFAULT 'fixed'
                        CHECK (price_type IN ('fixed','from','hourly','estimate')),
    message             TEXT NOT NULL,
    -- Geschätzte Bearbeitungszeit / Verfügbarkeit
    available_from      DATE,
    estimated_duration  TEXT,
    -- Anhang (z. B. PDF-Angebot, Referenzen)
    attachment_url      TEXT,
    -- Gültigkeit
    valid_until         TIMESTAMPTZ DEFAULT (now() + INTERVAL '7 days'),
    status              TEXT NOT NULL DEFAULT 'sent'
                        CHECK (status IN ('sent','viewed','accepted','declined','expired','withdrawn')),
    viewed_at           TIMESTAMPTZ,
    responded_at        TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (request_id, provider_id)
);

CREATE INDEX IF NOT EXISTS idx_offers_request  ON offers(request_id);
CREATE INDEX IF NOT EXISTS idx_offers_provider ON offers(provider_id);
CREATE INDEX IF NOT EXISTS idx_offers_status   ON offers(status);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 5. provider_wallet — Guthaben-Konto für Lead-Gebühren        │
-- │    (Prepaid-Credits = weniger Stripe-Fees, besserer Cashflow)│
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS provider_wallet (
    provider_id     UUID PRIMARY KEY REFERENCES providers(id) ON DELETE CASCADE,
    balance         NUMERIC(10,2) NOT NULL DEFAULT 0,
    currency        TEXT NOT NULL DEFAULT 'EUR',
    -- Auto-Aufladung bei Unterschreitung
    auto_topup      BOOLEAN DEFAULT FALSE,
    auto_topup_amount NUMERIC(10,2) DEFAULT 50,
    threshold       NUMERIC(10,2) DEFAULT 10,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS wallet_transactions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider_id     UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    type            TEXT NOT NULL CHECK (type IN ('topup','lead_charge','refund','bonus')),
    amount          NUMERIC(10,2) NOT NULL,
    balance_after   NUMERIC(10,2) NOT NULL,
    reference_id    UUID,
    stripe_payment_id TEXT,
    note            TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wallet_tx_provider ON wallet_transactions(provider_id);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 6. Erweiterung providers: Subscription-Tier + Verifizierung  │
-- └─────────────────────────────────────────────────────────────┘
ALTER TABLE providers ADD COLUMN IF NOT EXISTS subscription_tier TEXT DEFAULT 'free'
    CHECK (subscription_tier IN ('free','plus','pro'));
ALTER TABLE providers ADD COLUMN IF NOT EXISTS subscription_until TIMESTAMPTZ;
ALTER TABLE providers ADD COLUMN IF NOT EXISTS verified_badge BOOLEAN DEFAULT FALSE;
ALTER TABLE providers ADD COLUMN IF NOT EXISTS response_rate NUMERIC(5,2) DEFAULT 0;
ALTER TABLE providers ADD COLUMN IF NOT EXISTS avg_response_hours NUMERIC(6,1);
ALTER TABLE providers ADD COLUMN IF NOT EXISTS service_radius_km INTEGER DEFAULT 50;

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 7. reviews — Bewertungen (Vertrauen = Conversion-Treiber)    │
-- └─────────────────────────────────────────────────────────────┘
CREATE TABLE IF NOT EXISTS reviews (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider_id     UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    request_id      UUID REFERENCES requests(id) ON DELETE SET NULL,
    customer_name   TEXT NOT NULL,
    rating          INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment         TEXT,
    -- Nur verifizierte Reviews (echter Abschluss) zählen voll
    verified        BOOLEAN DEFAULT FALSE,
    provider_reply  TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reviews_provider ON reviews(provider_id);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ 8. View: Anbieter-Performance (fürs Dashboard + Ranking)     │
-- └─────────────────────────────────────────────────────────────┘
CREATE OR REPLACE VIEW provider_stats AS
SELECT
    p.id AS provider_id,
    COUNT(DISTINCT o.id)                                   AS total_offers,
    COUNT(DISTINCT o.id) FILTER (WHERE o.status = 'accepted') AS won_offers,
    COALESCE(AVG(r.rating), 0)                             AS avg_rating,
    COUNT(DISTINCT r.id)                                   AS review_count,
    COALESCE(SUM(lf.amount) FILTER (WHERE lf.status = 'paid'), 0) AS lead_spend
FROM providers p
LEFT JOIN offers o     ON o.provider_id = p.id
LEFT JOIN reviews r    ON r.provider_id = p.id
LEFT JOIN lead_fees lf ON lf.provider_id = p.id
GROUP BY p.id;
