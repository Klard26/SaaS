// ═══════════════════════════════════════════════════════════════
// Klard — Abo-Routes (Stripe Subscriptions)
// Datei: src/routes/subscriptions.js
// ═══════════════════════════════════════════════════════════════
import express from "express";
import Stripe from "stripe";
import { pool } from "../db.js";
import { sendEmail } from "../email.js";

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// ─── GET /api/plans — Tarifübersicht fürs Frontend ─────────────
router.get("/plans", async (_req, res) => {
  const r = await pool.query(
    `SELECT * FROM subscription_plans ORDER BY price_monthly ASC`);
  res.json({ plans: r.rows });
});

// ─── GET /api/providers/:id/subscription — aktueller Status ────
router.get("/providers/:id/subscription", async (req, res) => {
  const ent = await pool.query(
    `SELECT * FROM provider_entitlements WHERE provider_id = $1`, [req.params.id]);
  const sub = await pool.query(
    `SELECT * FROM subscriptions WHERE provider_id = $1`, [req.params.id]);
  res.json({
    entitlements: ent.rows[0] || null,
    subscription: sub.rows[0] || null,
  });
});

// ─── POST /api/subscriptions/checkout — Abo starten/upgraden ───
router.post("/subscriptions/checkout", async (req, res) => {
  const { provider_id, tier } = req.body;
  if (!["plus", "pro"].includes(tier))
    return res.status(400).json({ error: "Ungültiger Tarif." });
  try {
    const plan = await pool.query(
      `SELECT * FROM subscription_plans WHERE tier = $1`, [tier]);
    if (!plan.rows.length || !plan.rows[0].stripe_price_id)
      return res.status(400).json({ error: "Tarif nicht konfiguriert (stripe_price_id fehlt)." });

    const prov = await pool.query(
      `SELECT email, contact_name FROM providers WHERE id = $1`, [provider_id]);
    if (!prov.rows.length) return res.status(404).json({ error: "Anbieter nicht gefunden." });

    // Stripe-Customer wiederverwenden falls vorhanden
    const existing = await pool.query(
      `SELECT stripe_customer_id FROM subscriptions WHERE provider_id = $1`, [provider_id]);
    let customerId = existing.rows[0]?.stripe_customer_id;
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: prov.rows[0].email,
        name: prov.rows[0].contact_name,
        metadata: { provider_id },
      });
      customerId = customer.id;
    }

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer: customerId,
      line_items: [{ price: plan.rows[0].stripe_price_id, quantity: 1 }],
      metadata: { provider_id, tier },
      subscription_data: { metadata: { provider_id, tier } },
      success_url: `${process.env.APP_URL}/dashboard?sub=success`,
      cancel_url: `${process.env.APP_URL}/dashboard?sub=cancel`,
    });
    res.json({ url: session.url });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── POST /api/subscriptions/cancel — zum Periodenende kündigen ─
router.post("/subscriptions/cancel", async (req, res) => {
  const { provider_id } = req.body;
  try {
    const sub = await pool.query(
      `SELECT stripe_subscription_id FROM subscriptions WHERE provider_id = $1`,
      [provider_id]);
    if (!sub.rows.length || !sub.rows[0].stripe_subscription_id)
      return res.status(404).json({ error: "Kein aktives Abo." });
    await stripe.subscriptions.update(sub.rows[0].stripe_subscription_id,
      { cancel_at_period_end: true });
    await pool.query(
      `UPDATE subscriptions SET cancel_at_period_end = TRUE, updated_at = now()
       WHERE provider_id = $1`, [provider_id]);
    res.json({ ok: true, message: "Abo wird zum Periodenende beendet." });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── Webhook-Handler — in deinem zentralen Stripe-Webhook aufrufen
// Ergänzt deine bestehenden Handler (checkout.session.completed etc.)
export async function handleSubscriptionWebhook(event) {
  switch (event.type) {
    case "checkout.session.completed": {
      const s = event.data.object;
      if (s.mode !== "subscription") break;
      const { provider_id, tier } = s.metadata || {};
      if (!provider_id) break;
      const stripeSub = await stripe.subscriptions.retrieve(s.subscription);
      await upsertSubscription(provider_id, tier, stripeSub, s.customer);
      await pool.query(
        `UPDATE providers SET subscription_tier = $1, verified_badge = TRUE WHERE id = $2`,
        [tier, provider_id]);
      const p = await pool.query(`SELECT email, contact_name FROM providers WHERE id=$1`,
        [provider_id]);
      if (p.rows.length)
        sendEmail("subscription_activated", p.rows[0].email,
          { provider: p.rows[0], tier }).catch(console.error);
      break;
    }
    case "customer.subscription.updated": {
      const sub = event.data.object;
      const { provider_id, tier } = sub.metadata || {};
      if (!provider_id) break;
      await upsertSubscription(provider_id, tier, sub, sub.customer);
      break;
    }
    case "customer.subscription.deleted": {
      const sub = event.data.object;
      const { provider_id } = sub.metadata || {};
      if (!provider_id) break;
      await pool.query(
        `UPDATE subscriptions SET status='canceled', updated_at=now()
         WHERE provider_id=$1`, [provider_id]);
      await pool.query(
        `UPDATE providers SET subscription_tier='free' WHERE id=$1`, [provider_id]);
      break;
    }
    case "invoice.payment_failed": {
      const inv = event.data.object;
      const sub = await stripe.subscriptions.retrieve(inv.subscription);
      const { provider_id } = sub.metadata || {};
      if (!provider_id) break;
      await pool.query(
        `UPDATE subscriptions SET status='past_due', updated_at=now()
         WHERE provider_id=$1`, [provider_id]);
      break;
    }
  }
}

async function upsertSubscription(providerId, tier, stripeSub, customerId) {
  const periodEnd = stripeSub.current_period_end
    ? new Date(stripeSub.current_period_end * 1000).toISOString() : null;
  await pool.query(
    `INSERT INTO subscriptions
       (provider_id, tier, stripe_subscription_id, stripe_customer_id,
        status, current_period_end, cancel_at_period_end)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT (provider_id) DO UPDATE SET
       tier = EXCLUDED.tier,
       stripe_subscription_id = EXCLUDED.stripe_subscription_id,
       stripe_customer_id = EXCLUDED.stripe_customer_id,
       status = EXCLUDED.status,
       current_period_end = EXCLUDED.current_period_end,
       cancel_at_period_end = EXCLUDED.cancel_at_period_end,
       updated_at = now()`,
    [providerId, tier, stripeSub.id, customerId,
     stripeSub.status === "active" ? "active" : stripeSub.status,
     periodEnd, stripeSub.cancel_at_period_end || false]);
}

export default router;
