// ═══════════════════════════════════════════════════════════════
// Klard — Anfrage-/Angebots-Modul · Express Routes (v2, tier-aware)
// Datei: src/routes/requests.js
// Ersetzt die erste Version: jetzt mit Tier-Gating, Lead-Garantie,
// Tier-Rabatt und Ranking-Boost im Matching.
// ═══════════════════════════════════════════════════════════════
import express from "express";
import Stripe from "stripe";
import { pool } from "../db.js";
import { sendEmail } from "../email.js";
import {
  getEntitlements, canRespondToLead, applyTierDiscount, incrementLeadUsage,
} from "../middleware/entitlements.js";

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// ─── Lead-Preis-Logik ──────────────────────────────────────────
function calcLeadPrice({ funding_relevant, budget_max, branch_id }) {
  let base = 4.9;
  if (funding_relevant) base += 3;
  if (budget_max && budget_max > 2000) base += 4;
  if (budget_max && budget_max > 10000) base += 6;
  if (["enb", "stat", "bauphysik"].includes(branch_id)) base += 2;
  return Math.round(base * 100) / 100;
}

// ─── POST /api/requests — Kunde stellt Anfrage ─────────────────
router.post("/requests", async (req, res) => {
  const c = req.body;
  if (!c.consent_data_share)
    return res.status(400).json({ error: "DSGVO-Einwilligung erforderlich." });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const ins = await client.query(
      `INSERT INTO requests
        (customer_name, customer_email, customer_phone, branch_id, category_id,
         service_template_id, title, description, answers, postal_code, city,
         budget_min, budget_max, urgency, funding_relevant, max_offers,
         consent_data_share, consent_timestamp)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17, now())
       RETURNING *`,
      [c.customer_name, c.customer_email, c.customer_phone, c.branch_id,
       c.category_id, c.service_template_id, c.title, c.description,
       c.answers || {}, c.postal_code, c.city, c.budget_min, c.budget_max,
       c.urgency || "flexibel", !!c.funding_relevant, c.max_offers || 3, true]);
    const request = ins.rows[0];

    // Matching mit Ranking-Boost: Pro/Plus-Anbieter werden bevorzugt benachrichtigt
    const matches = await client.query(
      `INSERT INTO request_matches (request_id, provider_id, match_score)
       SELECT $1, p.id, COALESCE(ent.ranking_boost, 0) + COALESCE(ps_avg.score, 0)
       FROM providers p
       JOIN provider_services ps ON ps.provider_id = p.id
       LEFT JOIN provider_entitlements ent ON ent.provider_id = p.id
       LEFT JOIN LATERAL (
         SELECT AVG(rating)::numeric AS score FROM reviews WHERE provider_id = p.id
       ) ps_avg ON TRUE
       WHERE p.is_active = TRUE
         AND ($2::uuid IS NULL OR ps.service_template_id = $2)
       GROUP BY p.id, ent.ranking_boost, ps_avg.score
       ORDER BY 3 DESC
       LIMIT 25
       RETURNING provider_id`,
      [request.id, c.service_template_id]);

    await client.query("COMMIT");
    for (const m of matches.rows)
      notifyProviderOfRequest(m.provider_id, request).catch(console.error);
    res.json({ request, matched_providers: matches.rowCount });
  } catch (e) {
    await client.query("ROLLBACK");
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

// ─── POST /api/requests/:id/offers — Anbieter sendet Angebot ───
router.post("/requests/:id/offers", async (req, res) => {
  const requestId = req.params.id;
  const { provider_id, price, price_type, message,
          available_from, estimated_duration } = req.body;

  // Tier-Gate: darf dieser Anbieter überhaupt antworten?
  const gate = await canRespondToLead(provider_id);
  if (!gate.allowed)
    return res.status(403).json({ error: gate.reason, upgrade_required: true });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const rq = await client.query(
      `SELECT * FROM requests WHERE id = $1 FOR UPDATE`, [requestId]);
    if (!rq.rows.length) throw new Error("Anfrage nicht gefunden.");
    const request = rq.rows[0];
    if (["closed", "expired"].includes(request.status))
      throw new Error("Anfrage ist nicht mehr offen.");

    const offerCount = await client.query(
      `SELECT COUNT(*)::int AS n FROM offers WHERE request_id = $1`, [requestId]);
    if (offerCount.rows[0].n >= request.max_offers)
      throw new Error("Maximale Anzahl Angebote erreicht.");

    // Lead-Preis inkl. Tier-Rabatt
    const basePrice = calcLeadPrice(request);
    const leadPrice = applyTierDiscount(basePrice, gate.entitlements);

    // Wallet abbuchen
    const wallet = await client.query(
      `SELECT * FROM provider_wallet WHERE provider_id = $1 FOR UPDATE`, [provider_id]);
    if (!wallet.rows.length || Number(wallet.rows[0].balance) < leadPrice)
      throw new Error("Guthaben zu niedrig. Bitte Wallet aufladen.");

    const newBal = Number(wallet.rows[0].balance) - leadPrice;
    await client.query(
      `UPDATE provider_wallet SET balance=$1, updated_at=now() WHERE provider_id=$2`,
      [newBal, provider_id]);
    await client.query(
      `INSERT INTO wallet_transactions
        (provider_id, type, amount, balance_after, reference_id, note)
       VALUES ($1,'lead_charge',$2,$3,$4,$5)`,
      [provider_id, -leadPrice, newBal, requestId, "Lead: " + request.title]);

    const lf = await client.query(
      `INSERT INTO lead_fees (provider_id, request_id, amount, paid_from_credit, status)
       VALUES ($1,$2,$3,TRUE,'paid') RETURNING id`,
      [provider_id, requestId, leadPrice]);

    const offer = await client.query(
      `INSERT INTO offers
        (request_id, provider_id, lead_fee_id, price, price_type, message,
         available_from, estimated_duration)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [requestId, provider_id, lf.rows[0].id, price, price_type || "fixed",
       message, available_from, estimated_duration]);

    // Lead-Verbrauch zählen (für Free-Limit)
    await incrementLeadUsage(client, provider_id);

    if (offerCount.rows[0].n + 1 >= request.max_offers)
      await client.query(`UPDATE requests SET status='matched' WHERE id=$1`, [requestId]);

    await client.query("COMMIT");
    sendEmail("offer_received", request.customer_email,
      { request, offer: offer.rows[0] }).catch(console.error);
    res.json({ offer: offer.rows[0], lead_fee: leadPrice,
               base_price: basePrice, tier: gate.entitlements.tier });
  } catch (e) {
    await client.query("ROLLBACK");
    res.status(400).json({ error: e.message });
  } finally {
    client.release();
  }
});

// ─── POST /api/offers/:id/accept — Kunde nimmt Angebot an ──────
router.post("/offers/:id/accept", async (req, res) => {
  const offerId = req.params.id;
  try {
    const o = await pool.query(
      `UPDATE offers SET status='accepted', responded_at=now()
       WHERE id=$1 RETURNING *`, [offerId]);
    if (!o.rows.length) return res.status(404).json({ error: "Angebot nicht gefunden." });
    await pool.query(`UPDATE requests SET status='fulfilled' WHERE id=$1`,
      [o.rows[0].request_id]);
    await pool.query(
      `UPDATE offers SET status='declined'
       WHERE request_id=$1 AND id<>$2 AND status IN ('sent','viewed')`,
      [o.rows[0].request_id, offerId]);
    res.json({ offer: o.rows[0] });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── POST /api/leads/:leadFeeId/refund — Lead-Garantie ─────────
// Toter Lead (Kunde nicht erreichbar/Spam) → Credit zurück.
// Stärkster Vertrauenstreiber, damit Anbieter überhaupt zahlen.
router.post("/leads/:leadFeeId/refund", async (req, res) => {
  const { leadFeeId } = req.params;
  const { reason } = req.body;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const lf = await client.query(
      `SELECT * FROM lead_fees WHERE id=$1 FOR UPDATE`, [leadFeeId]);
    if (!lf.rows.length) throw new Error("Lead-Gebühr nicht gefunden.");
    if (lf.rows[0].status === "refunded") throw new Error("Bereits erstattet.");

    const fee = lf.rows[0];
    const wallet = await client.query(
      `SELECT * FROM provider_wallet WHERE provider_id=$1 FOR UPDATE`,
      [fee.provider_id]);
    const newBal = Number(wallet.rows[0].balance) + Number(fee.amount);
    await client.query(
      `UPDATE provider_wallet SET balance=$1, updated_at=now() WHERE provider_id=$2`,
      [newBal, fee.provider_id]);
    await client.query(
      `INSERT INTO wallet_transactions
        (provider_id, type, amount, balance_after, reference_id, note)
       VALUES ($1,'refund',$2,$3,$4,$5)`,
      [fee.provider_id, fee.amount, newBal, fee.request_id,
       "Lead-Garantie: " + (reason || "toter Lead")]);
    await client.query(
      `UPDATE lead_fees SET status='refunded', refund_reason=$1 WHERE id=$2`,
      [reason || "toter Lead", leadFeeId]);
    await client.query("COMMIT");
    res.json({ ok: true, refunded: fee.amount, new_balance: newBal });
  } catch (e) {
    await client.query("ROLLBACK");
    res.status(400).json({ error: e.message });
  } finally {
    client.release();
  }
});

// ─── POST /api/wallet/topup — Stripe Checkout fürs Aufladen ────
router.post("/wallet/topup", async (req, res) => {
  const { provider_id, amount } = req.body;
  try {
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{
        price_data: {
          currency: "eur",
          product_data: { name: `Klard Lead-Guthaben (${amount} €)` },
          unit_amount: Math.round(amount * 100),
        },
        quantity: 1,
      }],
      metadata: { provider_id, type: "wallet_topup", amount },
      success_url: `${process.env.APP_URL}/dashboard?topup=success`,
      cancel_url: `${process.env.APP_URL}/dashboard?topup=cancel`,
    });
    res.json({ url: session.url });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

async function notifyProviderOfRequest(providerId, request) {
  const p = await pool.query(`SELECT email, contact_name FROM providers WHERE id=$1`,
    [providerId]);
  if (!p.rows.length) return;
  await pool.query(`UPDATE request_matches SET notified_at=now()
    WHERE request_id=$1 AND provider_id=$2`, [request.id, providerId]);
  await sendEmail("new_request_provider", p.rows[0].email,
    { provider: p.rows[0], request });
}

export default router;
