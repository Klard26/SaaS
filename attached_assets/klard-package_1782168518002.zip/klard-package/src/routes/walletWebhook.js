// ═══════════════════════════════════════════════════════════════
// Klard — Wallet-Topup Webhook-Handler
// Datei: src/routes/walletWebhook.js
// In deinem zentralen Stripe-Webhook nach Signaturprüfung aufrufen.
// ═══════════════════════════════════════════════════════════════
import { pool } from "../db.js";

export async function handleWalletWebhook(event) {
  if (event.type !== "checkout.session.completed") return;
  const s = event.data.object;
  if (s.metadata?.type !== "wallet_topup") return;

  const providerId = s.metadata.provider_id;
  const amount = Number(s.metadata.amount);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    // Wallet anlegen falls nicht vorhanden, dann gutschreiben
    await client.query(
      `INSERT INTO provider_wallet (provider_id, balance)
       VALUES ($1, $2)
       ON CONFLICT (provider_id)
       DO UPDATE SET balance = provider_wallet.balance + $2, updated_at = now()`,
      [providerId, amount]);
    const w = await client.query(
      `SELECT balance FROM provider_wallet WHERE provider_id = $1`, [providerId]);
    await client.query(
      `INSERT INTO wallet_transactions
        (provider_id, type, amount, balance_after, stripe_payment_id, note)
       VALUES ($1,'topup',$2,$3,$4,$5)`,
      [providerId, amount, w.rows[0].balance, s.payment_intent, "Wallet-Aufladung"]);
    await client.query("COMMIT");
  } catch (e) {
    await client.query("ROLLBACK");
    console.error("Wallet topup failed:", e.message);
  } finally {
    client.release();
  }
}
