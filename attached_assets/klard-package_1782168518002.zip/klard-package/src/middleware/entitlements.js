// ═══════════════════════════════════════════════════════════════
// Klard — Tier-Gating Middleware & Entitlement-Helfer
// Datei: src/middleware/entitlements.js
// Liest die View provider_entitlements und setzt Limits durch.
// ═══════════════════════════════════════════════════════════════
import { pool } from "../db.js";

// Effektive Berechtigungen eines Anbieters laden
export async function getEntitlements(providerId) {
  const r = await pool.query(
    `SELECT * FROM provider_entitlements WHERE provider_id = $1`, [providerId]);
  if (!r.rows.length) {
    // Fallback: behandeln wie Free
    return {
      provider_id: providerId, tier: "free", sub_status: "active",
      max_leads_month: 3, lead_discount_pct: 0, tier_grants_badge: false,
      ranking_boost: 0, multi_location: false, api_access: false,
      priority_support: false,
    };
  }
  return r.rows[0];
}

// Aktuellen Monats-Lead-Verbrauch lesen
export async function getLeadUsage(providerId) {
  const month = new Date();
  month.setUTCDate(1);
  const periodMonth = month.toISOString().slice(0, 10);
  const r = await pool.query(
    `SELECT leads_used FROM lead_usage
     WHERE provider_id = $1 AND period_month = $2`,
    [providerId, periodMonth]);
  return r.rows.length ? r.rows[0].leads_used : 0;
}

// Lead-Zähler erhöhen (im selben Transaktions-Client wie die Offer-Erstellung!)
export async function incrementLeadUsage(client, providerId) {
  const month = new Date();
  month.setUTCDate(1);
  const periodMonth = month.toISOString().slice(0, 10);
  await client.query(
    `INSERT INTO lead_usage (provider_id, period_month, leads_used)
     VALUES ($1, $2, 1)
     ON CONFLICT (provider_id, period_month)
     DO UPDATE SET leads_used = lead_usage.leads_used + 1, updated_at = now()`,
    [providerId, periodMonth]);
}

// Darf der Anbieter auf eine weitere Anfrage antworten?
// Free hat ein Monatslimit; Plus/Pro sind unbegrenzt (max_leads_month = NULL).
export async function canRespondToLead(providerId) {
  const ent = await getEntitlements(providerId);
  if (ent.sub_status === "past_due")
    return { allowed: false, reason: "Abo-Zahlung überfällig.", entitlements: ent };
  if (ent.max_leads_month === null)
    return { allowed: true, entitlements: ent };
  const used = await getLeadUsage(providerId);
  if (used >= ent.max_leads_month)
    return {
      allowed: false,
      reason: `Free-Limit von ${ent.max_leads_month} Leads/Monat erreicht. Upgrade auf Plus für unbegrenzte Anfragen.`,
      entitlements: ent,
    };
  return { allowed: true, entitlements: ent };
}

// Lead-Preis mit Tier-Rabatt anwenden
export function applyTierDiscount(basePrice, entitlements) {
  const pct = Number(entitlements.lead_discount_pct || 0);
  const discounted = basePrice * (1 - pct / 100);
  return Math.round(discounted * 100) / 100;
}

// Express-Guard für Feature-Gates (z. B. API-Zugang, Multi-Standort)
export function requireFeature(feature) {
  return async (req, res, next) => {
    const providerId = req.body.provider_id || req.query.provider_id || req.params.providerId;
    if (!providerId) return res.status(400).json({ error: "provider_id fehlt." });
    const ent = await getEntitlements(providerId);
    if (!ent[feature]) {
      return res.status(403).json({
        error: `Diese Funktion ist im Tarif '${ent.tier}' nicht enthalten.`,
        upgrade_required: true,
        current_tier: ent.tier,
      });
    }
    req.entitlements = ent;
    next();
  };
}
