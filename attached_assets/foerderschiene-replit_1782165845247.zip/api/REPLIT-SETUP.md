# Förderschiene — Import & Setup auf Replit

Diese Anleitung führt dich durch den kompletten Import des Backends auf Replit
mit dem Replit-eigenen PostgreSQL. Folge den Schritten der Reihe nach.

> **Namens-Hinweis:** Nach außen heißt das Produkt **Förderschiene**. Intern
> (Datenbank-Schema, Code-Bezeichner, Ordnernamen) bleibt vorerst
> `foerderpilot` — das ist Absicht und spart Risiko bei Umbenennungen. Diese
> internen Namen sieht kein Nutzer.

---

## Was du importierst

Ein lauffähiges Node/TypeScript-Backend (Fastify) mit zwei Modulen:
- **Förderschiene** — Förderprogramm-Finder, Detail mit Antragspfad, Profil-Matching
- **Energieausweis** — GModG-Typ-Weiche, Ausweis-Erstellung, Funnel zur Förderung

Plus alle SQL-Dateien (Schema + Daten) und ein Setup-Skript, das die Datenbank
mit einem Befehl befüllt.

---

## Schritt 1 — Projekt auf Replit anlegen

1. Auf Replit **„Create App"** → **„Import from GitHub"** (falls du das Projekt
   in ein Repo legst) **oder** ein leeres **Node.js**-Repl anlegen und den
   Inhalt dieses `api/`-Ordners hochladen.
2. Wichtig: Der Inhalt dieses Ordners (mit `package.json`, `src/`, `db/`) muss
   im **Projekt-Root** liegen — nicht in einem Unterordner.

## Schritt 2 — PostgreSQL hinzufügen

1. Im **Project Editor** das Tool **„Database"** öffnen (Lupe → „Database").
2. **PostgreSQL-Datenbank erstellen** (ein Klick). Replit setzt damit automatisch
   die Umgebungsvariable **`DATABASE_URL`** — dein Code liest sie bereits.
3. Du musst nichts manuell konfigurieren; die DB ist in Sekunden bereit.

## Schritt 3 — Abhängigkeiten installieren

Replit installiert beim ersten Start meist automatisch. Falls nicht, in der
Shell:

```bash
npm install
```

## Schritt 4 — Datenbank befüllen

```bash
npm run db:setup
```

Das Skript spielt die vier SQL-Dateien in der richtigen Reihenfolge ein:
Schema → Programmdaten → Antragspfade → Energieausweis-Modul. Am Ende meldet es,
wie viele Programme in der DB liegen.

> **Sicher by default:** Existiert das Schema schon, wird **nicht** überschrieben
> (kein Datenverlust); es werden nur die Programmdaten aktualisiert. Ein
> vollständiges Neuaufsetzen (mit Datenverlust) nur bewusst mit
> `npm run db:reset`.

## Schritt 5 — Starten

Auf **„Run"** klicken (startet `npm run dev`) oder in der Shell:

```bash
npm run dev
```

Das Backend läuft dann unter der Replit-URL. Teste:
- `GET /health` → sollte `{"status":"ok","db":"verbunden"}` liefern
- `GET /` → Übersicht aller Endpunkte

## Schritt 6 — (optional) Tests

```bash
npm test
```

16 Tests laufen ohne DB (gemockt) und prüfen Routing, Validierung,
SQL-Aufbau und die Energieausweis-Typ-Weiche.

## Energetischen Report als PDF erzeugen

Der Endpunkt `report.pdf` erzeugt dynamisch einen energetischen
Erweiterungsreport (Einordnung, Maßnahmen, Kostenschätzung, iSFP-Hebel,
Förderwege) als PDF — direkt im Browser anzeigbar.

```bash
# Für ein in der DB gespeichertes Gebäude (per Ausweis-ID):
#   https://DEIN-REPL.../api/energieausweis/<UUID>/report.pdf

# Schnelltest ohne DB-Eintrag — Report aus Direkteingabe:
curl -X POST https://DEIN-REPL.../api/energieausweis/report-vorschau.pdf \
  -H 'content-type: application/json' \
  -o report.pdf \
  -d '{
    "nutzung": "mischgebaeude",
    "wohneinheiten": 6,
    "bgf_m2": 630,
    "ueberbaute_flaeche_m2": 125,
    "mittlere_hoehe_m": 12.04,
    "heizung_traeger": "Zentral-/Fernheizung (Brennwert)"
  }'
```

Das PDF wird mit `pdfkit` rein serverseitig erzeugt — keine Browser- oder
Font-Abhängigkeiten, läuft direkt auf Replit.

---

## Secrets (wichtig)

- **`DATABASE_URL`** wird von Replit automatisch gesetzt — nicht anfassen.
- **`ANTHROPIC_API_KEY`** (optional, nur für den Dokument-Assistenten):
  in die **Secrets-Pane** eintragen (Schloss-Symbol in der Seitenleiste),
  **nicht** in eine `.env`-Datei. Ohne diesen Key läuft alles außer dem
  einen Assistenten-Endpunkt normal weiter.

> Secrets aus dem Workspace werden **nicht** automatisch in Deployments
> übernommen. Beim Veröffentlichen (Schritt 7) die Secrets dort separat setzen.

## Schritt 7 — Veröffentlichen (Deployment)

1. **„Deploy"** / **„Publish"** im Replit-UI.
2. Deployment-Typ **Autoscale** wählen (passt für eine API mit wechselndem Traffic).
3. In den **Deployment-Secrets** die nötigen Variablen erneut setzen
   (`DATABASE_URL` wird bei Replit-PostgreSQL automatisch verknüpft; einen
   ggf. genutzten `ANTHROPIC_API_KEY` separat eintragen).
4. Build/Run sind in `.replit` bereits hinterlegt: `npm run build` → `npm run start`.

---

## Häufige Stolpersteine

| Symptom | Ursache / Lösung |
|---|---|
| `DATABASE_URL ist nicht gesetzt` | Schritt 2 nicht gemacht — DB im Database-Tool anlegen |
| `an open port was not detected` | Server muss an `0.0.0.0` binden (macht der Code) und Port 3000 nutzen |
| Deployment crasht | Deployment-Secrets fehlen — separat von Workspace-Secrets setzen |
| `/health` zeigt „db nicht erreichbar" | DB noch nicht befüllt → `npm run db:setup` |
| Doppelte Daten nach erneutem Setup | Normal: Import ist idempotent (aktualisiert per Titel, kein Duplikat) |

## Projektstruktur

```
.
├── .replit               Replit-Konfiguration (Run, Ports, Deployment)
├── package.json          Scripts: dev, build, start, db:setup, db:reset, test
├── src/                  Backend-Code (Server, Routen, DB-Pool, Typen)
├── db/
│   ├── setup.js          Spielt die SQL-Dateien geordnet ein (sicher by default)
│   └── sql/              Die vier SQL-Dateien (Schema + Daten)
└── test/                 16 Tests (laufen ohne DB)
```
