/**
 * DB-Setup für Förderschiene (intern: foerderpilot-Schema).
 *
 * Spielt die SQL-Dateien in der korrekten Reihenfolge in die per
 * DATABASE_URL referenzierte PostgreSQL-Datenbank ein.
 *
 * Auf Replit: DATABASE_URL wird automatisch gesetzt, sobald du im
 * Project Editor eine PostgreSQL-Datenbank hinzufügst.
 *
 * SICHERHEIT — bitte lesen:
 *   Die Schema-Dateien beginnen mit "DROP SCHEMA ... CASCADE", um in der
 *   Entwicklung sauber neu aufzusetzen. Das LÖSCHT alle vorhandenen Daten
 *   in den Schemas foerderpilot und energieausweis.
 *
 *   Deshalb läuft dieses Skript standardmäßig im SICHEREN Modus:
 *   Es spielt nur ein, wenn die Schemas noch NICHT existieren.
 *
 *   Vollständiges Zurücksetzen (mit Datenverlust) nur mit explizitem Flag:
 *       node db/setup.js --reset
 *   oder Umgebungsvariable:
 *       DB_RESET=true node db/setup.js
 *
 * Aufruf:
 *   npm run db:setup          → sicher (nur wenn leer)
 *   npm run db:reset          → komplettes Neuaufsetzen (Daten weg)
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import pg from "pg";

const { Client } = pg;
const __dirname = dirname(fileURLToPath(import.meta.url));
const SQL_DIR = join(__dirname, "sql");

// Reihenfolge ist wichtig: Struktur → Daten → Antragspfade → Energieausweis
// (energieausweis referenziert per Fremdschlüssel das foerderpilot-Schema)
const FILES = [
  "foerderpilot_schema.sql",
  "foerderpilot_import_generiert.sql",
  "foerderpilot_seed_antragspfade.sql",
  "energieausweis_schema.sql",
  "foerderschiene_vorgang_schema.sql",
];

const RESET =
  process.argv.includes("--reset") ||
  String(process.env.DB_RESET).toLowerCase() === "true";

async function main() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.error(
      "\n✗ DATABASE_URL ist nicht gesetzt.\n" +
        "  Auf Replit: im Project Editor das Tool 'Database' öffnen und eine\n" +
        "  PostgreSQL-Datenbank hinzufügen — DATABASE_URL wird dann automatisch gesetzt.\n"
    );
    process.exit(1);
  }

  const client = new Client({ connectionString: url });
  await client.connect();

  try {
    // Prüfen, ob die Schemas bereits existieren
    const { rows } = await client.query(
      `SELECT schema_name FROM information_schema.schemata
       WHERE schema_name IN ('foerderpilot','energieausweis')`
    );
    const vorhanden = rows.map((r) => r.schema_name);

    if (vorhanden.length > 0 && !RESET) {
      console.log(
        `\n⚠  Schemas existieren bereits: ${vorhanden.join(", ")}.\n` +
          "   Im sicheren Modus wird NICHT überschrieben (kein Datenverlust).\n" +
          "   Für komplettes Neuaufsetzen (LÖSCHT Daten):  npm run db:reset\n"
      );
      // Trotzdem den idempotenten Import erneut anwenden (aktualisiert Programme,
      // ohne Schema zu droppen) — nur die nicht-destruktiven Dateien:
      console.log("→ Aktualisiere nur die idempotenten Daten (Import + Antragspfade)…");
      for (const f of ["foerderpilot_import_generiert.sql", "foerderpilot_seed_antragspfade.sql"]) {
        await runFile(client, f);
      }
      console.log("\n✓ Daten aktualisiert (Schema unverändert).\n");
      return;
    }

    if (RESET) {
      console.log("\n⚠  RESET-Modus: vorhandene Schemas werden neu aufgesetzt (Datenverlust).");
    }

    // Vollständiger Durchlauf
    for (const f of FILES) {
      await runFile(client, f);
    }

    // Kurzer Funktionsnachweis
    const check = await client.query(
      "SELECT count(*)::int AS n FROM foerderpilot.programm"
    );
    console.log(`\n✓ Setup abgeschlossen. Programme in der DB: ${check.rows[0].n}\n`);
  } finally {
    await client.end();
  }
}

async function runFile(client, filename) {
  const path = join(SQL_DIR, filename);
  const sql = readFileSync(path, "utf8");
  process.stdout.write(`→ ${filename} … `);
  await client.query(sql);
  console.log("ok");
}

main().catch((err) => {
  console.error("\n✗ Setup fehlgeschlagen:", err.message);
  console.error("  Tipp: Läuft die Datenbank? Ist DATABASE_URL korrekt?\n");
  process.exit(1);
});
