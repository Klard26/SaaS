-- ═══════════════════════════════════════════════════════════════
-- Klard Leistungskatalog v2.0 — PostgreSQL Seed Script
-- Generated: 2026-06-14 18:52
-- Target: Supabase / PostgreSQL / Replit DB
-- Erweitert um: Preisempfehlungen (min/avg/max), Einheiten, Inputs, Förder-Notizen
-- ═══════════════════════════════════════════════════════════════

-- ┌─────────────────────────────────────────────────────────────┐
-- │ SCHEMA — Erweitert um Preis-Empfehlungen & Inputs             │
-- └─────────────────────────────────────────────────────────────┘

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Branches (8 Berufsgruppen)
DROP TABLE IF EXISTS provider_services CASCADE;
DROP TABLE IF EXISTS service_templates CASCADE;
DROP TABLE IF EXISTS service_categories CASCADE;
DROP TABLE IF EXISTS branches CASCADE;

CREATE TABLE branches (
    id                       TEXT PRIMARY KEY,
    name                     TEXT NOT NULL,
    icon                     TEXT,
    description              TEXT,
    color                    TEXT,
    color_light              TEXT,
    requires_dena            BOOLEAN DEFAULT FALSE,
    requires_hoai            BOOLEAN DEFAULT FALSE,
    requires_kammer          TEXT,
    requires_oebvi           BOOLEAN DEFAULT FALSE,
    requires_zertifizierung  BOOLEAN DEFAULT FALSE,
    display_order            INT,
    created_at               TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Service Categories
CREATE TABLE service_categories (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    branch_id     TEXT NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    display_order INT,
    UNIQUE (branch_id, name)
);
CREATE INDEX idx_cat_branch ON service_categories(branch_id);

-- 3. Service Templates (mit Preis-Empfehlungen min/avg/max)
CREATE TABLE service_templates (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category_id     UUID NOT NULL REFERENCES service_categories(id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    price_type      TEXT NOT NULL CHECK (price_type IN ('fix','hr','pa','hoai','on')),
    duration        TEXT,
    price_min       DECIMAL(10,2),     -- Untergrenze (z.B. günstigste Anbieter)
    price_avg       DECIMAL(10,2),     -- Durchschnittspreis (Marktstandard)
    price_max       DECIMAL(10,2),     -- Obergrenze (Top-Anbieter, Premium)
    unit            TEXT,              -- Berechnungseinheit (objekt, stunde, etc.)
    inputs          TEXT[],            -- Erforderliche Eingaben für Preisberechnung
    fundable        TEXT,              -- Förderfähigkeit (BAFA/KfW)
    notes           TEXT,              -- Zusatzinfos für Anbieter
    display_order   INT
);
CREATE INDEX idx_svc_cat ON service_templates(category_id);

-- 4. Providers
CREATE TABLE providers (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    branch_id        TEXT REFERENCES branches(id),
    company_name     TEXT NOT NULL,
    email            TEXT NOT NULL UNIQUE,
    phone            TEXT,
    plz              TEXT,
    city             TEXT,
    experience_years INT,
    description      TEXT,
    dena_id          TEXT,
    dena_since       INT,
    dena_categories  TEXT[],
    dena_programs    TEXT[],
    kammer_state     TEXT,
    kammer_id        TEXT,
    bauvorlage       BOOLEAN DEFAULT FALSE,
    pruefingenieur   BOOLEAN DEFAULT FALSE,
    is_oebvi         BOOLEAN DEFAULT FALSE,
    oebvi_state      TEXT,
    oebvi_id         TEXT,
    is_oebuv         BOOLEAN DEFAULT FALSE,
    iso_17024        BOOLEAN DEFAULT FALSE,
    specialties      TEXT[],
    online_available BOOLEAN DEFAULT TRUE,
    response_time    TEXT,
    certificates     TEXT[],
    is_verified      BOOLEAN DEFAULT FALSE,
    is_active        BOOLEAN DEFAULT TRUE,
    created_at       TIMESTAMPTZ DEFAULT NOW(),
    updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Provider Services
CREATE TABLE provider_services (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider_id         UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    service_template_id UUID REFERENCES service_templates(id),
    custom_name         TEXT,
    price               DECIMAL(10,2) NOT NULL,
    price_type          TEXT NOT NULL,
    duration            TEXT,
    description         TEXT,
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_psvc_provider ON provider_services(provider_id);

-- ┌─────────────────────────────────────────────────────────────┐
-- │ SEED DATA                                                    │
-- └─────────────────────────────────────────────────────────────┘

-- ── BRANCHES ─────────────────────────────────────────────────
INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order) VALUES ('enb', 'Energieberatung', '⚡', 'Qualifizierte Energieberatung nach BAFA/KfW-Standards', '#D97706', '#FEF3C7', TRUE, FALSE, NULL, FALSE, FALSE, 1);
INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order) VALUES ('arc', 'Architektur', '📐', 'Architektenleistungen nach HOAI (alle 9 Leistungsphasen)', '#1B2A3B', '#F1F5F9', FALSE, TRUE, 'architekt', FALSE, FALSE, 2);
INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order) VALUES ('sta', 'Statiker / Tragwerksplaner', '🏗️', 'Tragwerksplanung nach HOAI § 51 (Bauingenieure)', '#185FA5', '#E6F1FB', FALSE, TRUE, 'ingenieur', FALSE, FALSE, 3);
INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order) VALUES ('bau', 'Bauberatung / Baubegleitung', '👷', 'Unabhängige Bauberatung, Baubegleitung, Bauleitung', '#993C1D', '#FAECE7', FALSE, FALSE, NULL, FALSE, FALSE, 4);
INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order) VALUES ('sac', 'Gebäudesachverständige', '🔍', 'Gutachten, Bewertungen, Schäden, Wertermittlungen', '#7C3AED', '#EDE9FE', FALSE, FALSE, NULL, FALSE, TRUE, 5);
INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order) VALUES ('vrm', 'Vermesser / Geodäten', '📏', 'Vermessung, Lagepläne, ÖbVI-Leistungen für Bauanträge', '#059669', '#D1FAE5', FALSE, FALSE, NULL, TRUE, FALSE, 6);
INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order) VALUES ('tga', 'TGA-Fachplaner', '🔧', 'Technische Gebäudeausrüstung nach HOAI § 55: Heizung, Lüftung, Sanitär, Elektro', '#993556', '#FBEAF0', FALSE, TRUE, 'ingenieur', FALSE, FALSE, 7);
INSERT INTO branches (id, name, icon, description, color, color_light, requires_dena, requires_hoai, requires_kammer, requires_oebvi, requires_zertifizierung, display_order) VALUES ('bps', 'Bauphysik & Spezialberatung', '🔊', 'Schallschutz, Brandschutz, Schadstoffe, Bauphysik', '#0E7490', '#CFFAFE', FALSE, FALSE, 'ingenieur', FALSE, FALSE, 8);


-- ── Energieberatung (enb) ──
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('enb', 'BAFA-Beratungsprogramme', 1),
    ('enb', 'BEG / KfW Fördermittel und Fachplanung', 2),
    ('enb', 'Ingenieurleistungen', 3),
    ('enb', 'Weitere Energie-Leistungen', 4)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, price_min, price_avg, price_max, unit, inputs, fundable, notes, display_order)
  SELECT id, 'BAFA-Energieberatung Wohngebäude (EBW)', 'fix', 'ca. 1–2 Tage', 1200, 1700, 2400, 'objekt', ARRAY['wohneinheiten','wohnflaeche_qm']::TEXT[], 'BAFA EBW 50% (max. 850 € EFH, 1.700 € MFH)', 'Für Privatkunden und WEG bis 25 WE. 50% BAFA-Förderung direkt verrechenbar.', 1
  FROM cat_inserts WHERE name = 'BAFA-Beratungsprogramme'
UNION ALL
  SELECT id, 'BAFA-Energieberatung Nichtwohngebäude (EBN)', 'pa', '1–3 Wochen', 2500, 4500, 8500, 'objekt', ARRAY['nettogrundflaeche_qm','gebaeudetyp']::TEXT[], 'BAFA EBN 80% (max. 6.000 € KMU, 8.000 € sonstige)', 'Für Gewerbe/Kommunen. KMU-Förderung 80%.', 2
  FROM cat_inserts WHERE name = 'BAFA-Beratungsprogramme'
UNION ALL
  SELECT id, 'Energieaudit nach DIN EN 16247', 'pa', '1–4 Wochen', 2900, 5500, 12000, 'objekt', ARRAY['nettogrundflaeche_qm','energiebezug_pro_jahr']::TEXT[], 'BAFA Bundesförderung Energieaudit', 'Pflicht für Nicht-KMU > 250 MA oder > 50 Mio € Umsatz, alle 4 Jahre.', 3
  FROM cat_inserts WHERE name = 'BAFA-Beratungsprogramme'
UNION ALL
  SELECT id, 'Energieberatung nach DIN V 18599', 'pa', '2–5 Wochen', 1800, 3200, 6500, 'objekt', ARRAY['gebaeudetyp','nettogrundflaeche_qm']::TEXT[], NULL, 'Detaillierte Berechnungsmethode für Nichtwohngebäude.', 4
  FROM cat_inserts WHERE name = 'BAFA-Beratungsprogramme'
UNION ALL
  SELECT id, 'Contracting-Orientierungsberatung', 'fix', 'ca. 4–6h', 690, 990, 1490, 'objekt', ARRAY[]::TEXT[], 'BAFA Contracting-Beratung 80%', 'Vorbereitende Beratung für Energie-Contracting (Einspar-/Liefer-Contracting).', 5
  FROM cat_inserts WHERE name = 'BAFA-Beratungsprogramme'
UNION ALL
  SELECT id, 'BEG Wohngebäude (BEG WG) – Planung & Begleitung', 'pa', '3–9 Monate (projektbegleitend)', 2200, 4500, 12000, 'objekt', ARRAY['wohneinheiten','effizienzhaus_stufe']::TEXT[], 'KfW Förderzuschuss 50% (max. 5.000 € EFH, 2.000 €/WE MFH)', 'Komplettpaket Planung + Baubegleitung + Verwendungsnachweis. Voraussetzung: dena-Listung für WG.', 1
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'BEG Nichtwohngebäude (BEG NWG)', 'pa', '4–12 Monate', 3900, 7900, 25000, 'objekt', ARRAY['nettogrundflaeche_qm','effizienzhaus_stufe']::TEXT[], 'KfW Förderzuschuss bis 50% (max. 20.000 €)', 'Voraussetzung: dena-Listung für NWG.', 2
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'BEG Einzelmaßnahmen (BEG EM) Wohn-/Nichtwohngebäude', 'fix', 'ca. 3–5h pro Maßnahme', 390, 650, 1290, 'antrag', ARRAY['massnahmen_anzahl']::TEXT[], 'BAFA Zuschuss 15–70% je nach Maßnahme', 'Heizung, Hülle, Anlagentechnik. Tarif pro Maßnahme/Antrag.', 3
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Energieeffizient Bauen & Sanieren – Wohngebäude', 'pa', 'projektbegleitend', 1900, 3500, 8500, 'objekt', ARRAY['wohneinheiten','neubau_oder_sanierung']::TEXT[], 'KfW Zuschuss bis 50%', 'Direkter KfW-Antrag, klassisch für KfW-Programme 261/461/297/298.', 4
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Baudenkmal Wohngebäude (Effizienzhaus Denkmal)', 'pa', 'projektbegleitend', 2900, 4900, 14000, 'objekt', ARRAY['wohneinheiten','denkmalstatus']::TEXT[], 'KfW Förderung max. 30.000 €/WE', 'Sonderkonditionen für denkmalgeschützte Gebäude. WTA-Listung empfohlen.', 5
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Energieeffizient Bauen & Sanieren – Nichtwohngebäude', 'pa', 'projektbegleitend', 3490, 6500, 22000, 'objekt', ARRAY['nettogrundflaeche_qm']::TEXT[], 'KfW Förderung bis 50%', 'Voraussetzung: dena-Listung für NWG.', 6
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Baudenkmal Nichtwohngebäude', 'pa', 'projektbegleitend', 3990, 8900, 28000, 'objekt', ARRAY['nettogrundflaeche_qm','denkmalstatus']::TEXT[], 'KfW Förderung bis 50%', 'Sonderkonditionen. WTA-Listung empfohlen.', 7
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Klimafreundlicher Neubau (KFN) – Wohngebäude', 'pa', 'projektbegleitend', 1890, 3290, 7900, 'objekt', ARRAY['wohneinheiten','qng_siegel_ja_nein']::TEXT[], 'KfW Zinsvergünstigung KFN', 'Programm 297/298. QNG-Siegel optional, höhere Förderung.', 8
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'KfW Klimafreundlicher Neubau (KFN) – Nichtwohngebäude', 'pa', 'projektbegleitend', 2890, 5900, 18000, 'objekt', ARRAY['nettogrundflaeche_qm','qng_siegel_ja_nein']::TEXT[], 'KfW Zinsvergünstigung KFN', 'Voraussetzung: dena-Listung KFN.', 9
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'DGNB-Auditor – Planung & Begleitung QNG', 'pa', '12–24 Monate', 4500, 9500, 35000, 'objekt', ARRAY['nettogrundflaeche_qm','zertifizierungsstufe']::TEXT[], 'Voraussetzung für QNG-Bonus in KFN', 'DGNB-Auditor-Listung Voraussetzung.', 10
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'Individueller Sanierungsfahrplan (iSFP)', 'fix', 'ca. 1–2 Tage', 1300, 1700, 2500, 'objekt', ARRAY['wohneinheiten']::TEXT[], 'BAFA 80% (max. 1.300 € EFH, 1.700 € MFH)', 'iSFP-Bonus 5% bei nachfolgenden BEG-EM-Maßnahmen. Pflichtformat seit 2021.', 11
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'BAFA-Antrag Heizungsanlage (Wärmepumpe, Solar, Biomasse)', 'fix', 'ca. 3–4h', 290, 490, 890, 'antrag', ARRAY['anlagentyp']::TEXT[], 'BAFA-Antrag selbst förderfähig in BEG EM', 'Bei BEG-EM-Heizung enthalten.', 12
  FROM cat_inserts WHERE name = 'BEG / KfW Fördermittel und Fachplanung'
UNION ALL
  SELECT id, 'Energiebedarfsausweis Wohngebäude (nach GEG)', 'fix', 'ca. 2–4h', 250, 399, 690, 'objekt', ARRAY['wohneinheiten','wohnflaeche_qm']::TEXT[], NULL, 'Pflicht bei Verkauf/Vermietung. Gültig 10 Jahre.', 1
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Energieverbrauchsausweis Wohngebäude', 'fix', 'ca. 30 Min.', 79, 129, 199, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Nur bei Gebäuden mit Baujahr nach 1977 oder modernisiert. 3 Jahre Verbrauchsdaten nötig.', 2
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Energiebedarfsausweis Nichtwohngebäude', 'fix', '1–3 Tage', 490, 890, 1990, 'objekt', ARRAY['nettogrundflaeche_qm']::TEXT[], NULL, 'DIN V 18599-Berechnung.', 3
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Energieverbrauchsausweis Nichtwohngebäude', 'fix', 'ca. 4h', 290, 490, 890, 'objekt', ARRAY['nettogrundflaeche_qm']::TEXT[], NULL, 'Min. 3 Jahre Verbrauchsdaten.', 4
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Wärmeschutznachweis nach GEG', 'fix', '1–2 Tage', 390, 690, 1490, 'objekt', ARRAY['wohnflaeche_qm','neubau_oder_sanierung']::TEXT[], NULL, 'Pflichtnachweis bei Neubau und größeren Sanierungen.', 5
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Nachweis sommerlicher Wärmeschutz', 'fix', 'ca. 4–6h', 290, 490, 890, 'objekt', ARRAY['wohnflaeche_qm','fensterflaeche_qm']::TEXT[], NULL, 'DIN 4108-2 Verfahren. Pflicht bei Neubau.', 6
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Raumweise Heizlastberechnung (DIN EN 12831)', 'fix', '1–2 Tage', 390, 590, 1190, 'objekt', ARRAY['wohnflaeche_qm','raumanzahl']::TEXT[], NULL, 'Pflicht für KfW/BAFA Heizungsförderung.', 7
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Hydraulischer Abgleich (Verfahren B, Berechnung & Nachweis)', 'fix', '1 Tag', 490, 790, 1490, 'objekt', ARRAY['wohnflaeche_qm','heizkoerper_anzahl']::TEXT[], 'BAFA-förderfähig im Rahmen BEG EM Heizung', 'Pflicht seit Okt. 2022 für Gasheizungen > 1000 m² (Wohnfläche).', 8
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Lüftungskonzept nach DIN 1946-6', 'fix', 'ca. 6–8h', 350, 590, 1190, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Pflicht bei mehr als 1/3 Fensteraustausch oder Sanierung der Außenhülle.', 9
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Kostenkalkulation nach DIN 276', 'pa', 'individuell', 890, 1900, 4900, 'objekt', ARRAY['bausumme']::TEXT[], NULL, 'Detaillierte Kostenermittlung nach DIN-Kostengruppen.', 10
  FROM cat_inserts WHERE name = 'Ingenieurleistungen'
UNION ALL
  SELECT id, 'Thermografieanalyse Gebäude', 'fix', 'Halbtag (Aufnahme) + Bericht', 390, 590, 990, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Nur im Winter durchführbar (Außentemp. < 5°C, ΔT > 15°C).', 1
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen'
UNION ALL
  SELECT id, 'Heizungscheck / Heizungsoptimierung', 'fix', 'ca. 2h', 150, 230, 390, 'objekt', ARRAY[]::TEXT[], 'BAFA-Heizungscheck 30% (max. 200 €)', 'Genormter Check nach DIN EN 15378.', 2
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen'
UNION ALL
  SELECT id, 'Photovoltaik-Wirtschaftlichkeitsberechnung', 'fix', 'ca. 2–3h', 250, 390, 690, 'objekt', ARRAY['dachflaeche_qm','stromverbrauch_jahr']::TEXT[], NULL, 'Inkl. ROI, Eigenverbrauch, Einspeisung, Speicherauslegung.', 3
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen'
UNION ALL
  SELECT id, 'Energieberatung Gewerbe / Industrie', 'hr', 'pro Stunde', 120, 150, 220, 'stunde', ARRAY[]::TEXT[], 'Teilweise BAFA-fähig', 'Vor-Ort, online oder kombiniert.', 4
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen'
UNION ALL
  SELECT id, 'CO2-Bilanz Unternehmen', 'pa', '2–8 Wochen', 890, 2900, 12000, 'objekt', ARRAY['mitarbeiter_anzahl','umsatz_eur']::TEXT[], NULL, 'Nach GHG Protocol oder ISO 14064. Scope 1, 2 und teilweise 3.', 5
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen'
UNION ALL
  SELECT id, 'Erstberatung Energieeffizienz', 'fix', 'ca. 1h', 79, 120, 190, 'objekt', ARRAY[]::TEXT[], NULL, 'Kurzberatung ohne Förderzusage, oft als Einstieg.', 6
  FROM cat_inserts WHERE name = 'Weitere Energie-Leistungen';

-- ── Architektur (arc) ──
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('arc', 'HOAI-Leistungsphasen Gebäudeplanung (§ 34) – Honorarzone III', 1),
    ('arc', 'Pauschalangebote', 2),
    ('arc', 'Einzelberatung', 3)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, price_min, price_avg, price_max, unit, inputs, fundable, notes, display_order)
  SELECT id, 'LPH 1 – Grundlagenermittlung (2%)', 'hoai', '1–2 Wochen', 800, 1500, 4500, 'bausumme_prozent', ARRAY['bausumme_eur','honorarzone']::TEXT[], NULL, '2% der Gesamtleistung. Hier: Bausumme 200K–600K EUR.', 1
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 2 – Vorplanung / Vorentwurf (7%)', 'hoai', '3–5 Wochen', 2900, 5500, 16000, 'bausumme_prozent', ARRAY['bausumme_eur','honorarzone']::TEXT[], NULL, '7% der Gesamtleistung.', 2
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 3 – Entwurfsplanung (15%)', 'hoai', '6–10 Wochen', 6500, 12000, 35000, 'bausumme_prozent', ARRAY['bausumme_eur','honorarzone']::TEXT[], NULL, '15% der Gesamtleistung. Kernphase mit detaillierter Planung.', 3
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 4 – Genehmigungsplanung / Bauantrag (3%)', 'hoai', '3–6 Wochen', 1300, 2500, 7500, 'bausumme_prozent', ARRAY['bausumme_eur','honorarzone']::TEXT[], NULL, '3%. Einreichung beim Bauamt.', 4
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 5 – Ausführungsplanung (25%)', 'hoai', '8–14 Wochen', 10500, 19500, 58000, 'bausumme_prozent', ARRAY['bausumme_eur','honorarzone']::TEXT[], NULL, '25%. Werkplanung – größter Honoraranteil.', 5
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 6 – Vorbereitung der Vergabe (10%)', 'hoai', '3–6 Wochen', 4500, 8500, 24000, 'bausumme_prozent', ARRAY['bausumme_eur','honorarzone']::TEXT[], NULL, '10%. LV-Erstellung und Massenermittlung.', 6
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 7 – Mitwirkung bei der Vergabe (4%)', 'hoai', '2–4 Wochen', 1700, 3200, 9500, 'bausumme_prozent', ARRAY['bausumme_eur','honorarzone']::TEXT[], NULL, '4%. Angebotsprüfung und Vergabeempfehlung.', 7
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 8 – Objektüberwachung (Bauleitung) (32%)', 'hoai', 'Bauzeit (6–18 Mon.)', 13500, 25000, 74000, 'bausumme_prozent', ARRAY['bausumme_eur','honorarzone']::TEXT[], NULL, '32%. Längste Phase, parallel zur Bauausführung.', 8
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 9 – Objektbetreuung in der Gewährleistung (2%)', 'hoai', '5 Jahre nach Abnahme', 800, 1500, 4500, 'bausumme_prozent', ARRAY['bausumme_eur','honorarzone']::TEXT[], NULL, '2%. Mängelmanagement während Gewährleistung.', 9
  FROM cat_inserts WHERE name = 'HOAI-Leistungsphasen Gebäudeplanung (§ 34) – Honorarzone III'
UNION ALL
  SELECT id, 'Komplette Planung Einfamilienhaus (LPH 1–9)', 'pa', '12–18 Monate', 35000, 55000, 95000, 'objekt', ARRAY['wohnflaeche_qm','bausumme_eur']::TEXT[], NULL, '~12–15% der Bausumme bei 350K–700K Baukosten.', 1
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Bauantrag-Erstellung Wohnhaus (LPH 1–4)', 'pa', '6–12 Wochen', 4500, 7900, 16500, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Stand-alone-Angebot ohne weitere Bauleitung.', 2
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Sanierungsplanung Wohngebäude', 'pa', '6–14 Wochen', 3900, 7900, 22000, 'objekt', ARRAY['wohnflaeche_qm','sanierungstiefe']::TEXT[], 'Teilweise BEG-fähig (Baubegleitung)', 'Energetisch oder substanziell.', 3
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Anbau / Aufstockung Planung', 'pa', '4–10 Wochen', 2900, 5900, 14000, 'objekt', ARRAY['anbau_flaeche_qm']::TEXT[], NULL, 'Genehmigungsplanung inkl. Statik-Koordination.', 4
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Innenarchitektur-Konzept (komplette Wohnung)', 'pa', '4–8 Wochen', 1890, 3900, 12000, 'objekt', ARRAY['wohnflaeche_qm','raumanzahl']::TEXT[], NULL, 'Konzept, Möblierungsplan, Materialauswahl, Lichtkonzept.', 5
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, '3D-Visualisierung (pro Raum/Ansicht)', 'fix', '1–3 Tage pro View', 290, 490, 990, 'view', ARRAY['view_anzahl']::TEXT[], NULL, 'Foto-realistisches Rendering. Pro Innen- oder Außenansicht.', 6
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Erstberatung Bauvorhaben', 'fix', 'ca. 1,5h', 150, 230, 390, 'termin', ARRAY[]::TEXT[], NULL, 'Verrechenbar bei Beauftragung.', 1
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'Bauvoranfrage erstellen', 'fix', 'ca. 4–8h', 390, 690, 1490, 'antrag', ARRAY['grundstuecksgroesse_qm']::TEXT[], NULL, 'Klärung der grundsätzlichen Bebaubarkeit.', 2
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'Machbarkeitsstudie Grundstück', 'fix', 'ca. 1–2 Tage', 690, 1290, 3500, 'objekt', ARRAY['grundstuecksgroesse_qm']::TEXT[], NULL, 'Inkl. Bebauungsplan-Analyse, Wirtschaftlichkeit, Massenmodell.', 3
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'Bestandsaufnahme & Aufmaß', 'hr', 'pro Stunde', 85, 110, 150, 'stunde', ARRAY[]::TEXT[], NULL, 'Tagessatz typisch 700–950 € (8h).', 4
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'Architektenberatung allgemein (Stundensatz)', 'hr', 'pro Stunde', 95, 130, 195, 'stunde', ARRAY[]::TEXT[], NULL, 'Höhere Sätze bei Spezialisten/leitenden Architekten.', 5
  FROM cat_inserts WHERE name = 'Einzelberatung';

-- ── Statiker / Tragwerksplaner (sta) ──
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('sta', 'HOAI Tragwerksplanung (§ 51) – Honorarzone III', 1),
    ('sta', 'Pauschalangebote', 2),
    ('sta', 'Einzelnachweise & Prüfungen', 3),
    ('sta', 'Einzelberatung', 4)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, price_min, price_avg, price_max, unit, inputs, fundable, notes, display_order)
  SELECT id, 'LPH 1 – Grundlagenermittlung (3%)', 'hoai', '1 Woche', 250, 450, 990, 'bausumme_prozent', ARRAY['bausumme_eur']::TEXT[], NULL, '3% der TW-Honorarsumme. Klärung Aufgabenstellung.', 1
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 2 – Vorplanung (10%)', 'hoai', '2–3 Wochen', 850, 1500, 3300, 'bausumme_prozent', ARRAY['bausumme_eur']::TEXT[], NULL, '10%. Vorbemessung, Tragwerkskonzept.', 2
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 3 – Entwurfsplanung (15%)', 'hoai', '3–5 Wochen', 1250, 2250, 4950, 'bausumme_prozent', ARRAY['bausumme_eur']::TEXT[], NULL, '15%. Endgültiges Tragwerkskonzept.', 3
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 4 – Genehmigungsplanung (Standsicherheit) (30%)', 'hoai', '4–8 Wochen', 2500, 4500, 9900, 'bausumme_prozent', ARRAY['bausumme_eur']::TEXT[], NULL, '30%. Vollständiger Standsicherheitsnachweis.', 4
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 5 – Ausführungsplanung (Schal-/Bewehrungspläne) (40%)', 'hoai', '6–12 Wochen', 3400, 6000, 13200, 'bausumme_prozent', ARRAY['bausumme_eur']::TEXT[], NULL, '40%. Werkpläne. Größter Anteil.', 5
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51) – Honorarzone III'
UNION ALL
  SELECT id, 'LPH 6 – Vorbereitung der Vergabe (2%)', 'hoai', '1–2 Wochen', 150, 300, 660, 'bausumme_prozent', ARRAY['bausumme_eur']::TEXT[], NULL, '2%. Materialspezifikation.', 6
  FROM cat_inserts WHERE name = 'HOAI Tragwerksplanung (§ 51) – Honorarzone III'
UNION ALL
  SELECT id, 'Statik Einfamilienhaus (komplett)', 'pa', '3–6 Wochen', 2200, 3500, 6500, 'objekt', ARRAY['wohnflaeche_qm','geschosse']::TEXT[], NULL, 'Übliches EFH 140–200 m². LPH 1–5 komplett.', 1
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Statik Anbau / Aufstockung', 'pa', '2–4 Wochen', 1290, 2200, 4500, 'objekt', ARRAY['anbau_flaeche_qm']::TEXT[], NULL, 'Inkl. Bestandsanschluss-Nachweis.', 2
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Statik Mehrfamilienhaus', 'pa', '6–12 Wochen', 4500, 8500, 25000, 'objekt', ARRAY['wohnflaeche_qm','wohneinheiten','geschosse']::TEXT[], NULL, 'Abhängig von Geschossanzahl + Stützweiten.', 3
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Bewehrungsplanung (Stahlbeton)', 'pa', '2–6 Wochen', 690, 1900, 6500, 'objekt', ARRAY['bauteil_anzahl']::TEXT[], NULL, 'Pro Bauteil oder Gesamtobjekt.', 4
  FROM cat_inserts WHERE name = 'Pauschalangebote'
UNION ALL
  SELECT id, 'Standsicherheitsnachweis (Einzelposition)', 'fix', '1–2 Tage', 390, 690, 1490, 'position', ARRAY[]::TEXT[], NULL, 'Bsp.: einzelner Balkon, Dachfenster, kleiner Anbau.', 1
  FROM cat_inserts WHERE name = 'Einzelnachweise & Prüfungen'
UNION ALL
  SELECT id, 'Statische Berechnung Wanddurchbruch', 'fix', 'ca. 4–6h', 290, 450, 890, 'position', ARRAY['durchbruch_breite_m']::TEXT[], NULL, 'Sturzberechnung tragende Wand.', 2
  FROM cat_inserts WHERE name = 'Einzelnachweise & Prüfungen'
UNION ALL
  SELECT id, 'Statische Berechnung Decken-/Wandöffnung', 'fix', 'ca. 6–8h', 390, 690, 1290, 'position', ARRAY['oeffnung_groesse_qm']::TEXT[], NULL, 'Inkl. Bewehrungsplan.', 3
  FROM cat_inserts WHERE name = 'Einzelnachweise & Prüfungen'
UNION ALL
  SELECT id, 'Schadensgutachten Tragwerk', 'pa', '1–4 Wochen', 690, 1900, 6500, 'objekt', ARRAY[]::TEXT[], NULL, 'Begutachtung von Rissen, Setzungen, Versagen.', 4
  FROM cat_inserts WHERE name = 'Einzelnachweise & Prüfungen'
UNION ALL
  SELECT id, 'Statische Prüfung Bestandsgebäude', 'pa', '1–3 Wochen', 590, 1290, 4500, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Z.B. vor Aufstockung oder Nutzungsänderung.', 5
  FROM cat_inserts WHERE name = 'Einzelnachweise & Prüfungen'
UNION ALL
  SELECT id, 'Statiker-Erstberatung', 'fix', 'ca. 1h', 110, 170, 290, 'termin', ARRAY[]::TEXT[], NULL, 'Verrechenbar bei Beauftragung.', 1
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'Statiker-Beratung (Stundensatz)', 'hr', 'pro Stunde', 95, 130, 195, 'stunde', ARRAY[]::TEXT[], NULL, 'Höhere Sätze bei Prüfingenieuren.', 2
  FROM cat_inserts WHERE name = 'Einzelberatung';

-- ── Bauberatung / Baubegleitung (bau) ──
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('bau', 'Baubegleitung & Bauüberwachung', 1),
    ('bau', 'Qualitätsprüfung & Abnahme', 2),
    ('bau', 'Beratung & Vertragsprüfung', 3)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, price_min, price_avg, price_max, unit, inputs, fundable, notes, display_order)
  SELECT id, 'Baubegleitung Einfamilienhaus (gesamter Bau)', 'pa', '9–18 Monate', 3900, 6500, 12500, 'objekt', ARRAY['bausumme_eur','bauzeit_monate']::TEXT[], 'BEG-Baubegleitung 50% (max. 5.000 €/Maßnahme)', 'Übliche 1,5–3% der Bausumme. Privatperson als Bauherr.', 1
  FROM cat_inserts WHERE name = 'Baubegleitung & Bauüberwachung'
UNION ALL
  SELECT id, 'Baubegleitung Sanierung (komplett)', 'pa', '3–12 Monate', 2900, 5500, 14000, 'objekt', ARRAY['sanierungssumme_eur']::TEXT[], 'BEG-Baubegleitung 50% (max. 5.000 €)', 'Förderfähig nur bei dena-gelisteten Energieberatern.', 2
  FROM cat_inserts WHERE name = 'Baubegleitung & Bauüberwachung'
UNION ALL
  SELECT id, 'Bauüberwachung pro Baubesprechung (Vor-Ort-Termin)', 'fix', '2–3h inkl. Anfahrt', 230, 350, 590, 'termin', ARRAY[]::TEXT[], NULL, 'Inkl. Bautagebuch und Mängelliste.', 3
  FROM cat_inserts WHERE name = 'Baubegleitung & Bauüberwachung'
UNION ALL
  SELECT id, 'Bauleitung (Stundensatz)', 'hr', 'pro Stunde', 75, 100, 150, 'stunde', ARRAY[]::TEXT[], NULL, 'Tagessatz typisch 600–950 €.', 4
  FROM cat_inserts WHERE name = 'Baubegleitung & Bauüberwachung'
UNION ALL
  SELECT id, 'Baufortschrittsprüfung mit Bericht', 'fix', 'ca. 3–4h', 290, 450, 790, 'termin', ARRAY[]::TEXT[], NULL, 'Pro Termin. Inkl. Fotodokumentation.', 1
  FROM cat_inserts WHERE name = 'Qualitätsprüfung & Abnahme'
UNION ALL
  SELECT id, 'Bauabnahme Wohnhaus (mit Protokoll)', 'fix', 'ca. 3–4h', 390, 590, 990, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Inkl. Abnahmeprotokoll und Mängelliste.', 2
  FROM cat_inserts WHERE name = 'Qualitätsprüfung & Abnahme'
UNION ALL
  SELECT id, 'Abnahme Eigentumswohnung (Übergabe vom Bauträger)', 'fix', 'ca. 2h', 290, 390, 590, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Begehung mit Käufer.', 3
  FROM cat_inserts WHERE name = 'Qualitätsprüfung & Abnahme'
UNION ALL
  SELECT id, 'Mängelaufnahme & Mängelbeseitigungsprüfung', 'fix', 'ca. 2–3h', 230, 390, 690, 'termin', ARRAY[]::TEXT[], NULL, 'Pro Begehung.', 4
  FROM cat_inserts WHERE name = 'Qualitätsprüfung & Abnahme'
UNION ALL
  SELECT id, 'Bauvertrag prüfen (Bauträger/Generalunternehmer)', 'fix', 'ca. 2–3h', 250, 390, 690, 'vertrag', ARRAY[]::TEXT[], NULL, 'Vorbereitend vor Notar-Termin empfohlen.', 1
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung'
UNION ALL
  SELECT id, 'LV-Prüfung (Leistungsverzeichnis)', 'fix', 'ca. 3–5h', 390, 590, 1290, 'lv', ARRAY['positionen_anzahl']::TEXT[], NULL, 'Prüfung auf Plausibilität, Marktüblichkeit, Vollständigkeit.', 2
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung'
UNION ALL
  SELECT id, 'Erstberatung Bauvorhaben', 'fix', 'ca. 1,5h', 120, 190, 290, 'termin', ARRAY[]::TEXT[], NULL, 'Verrechenbar bei Beauftragung.', 3
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung'
UNION ALL
  SELECT id, 'Kostenkalkulation nach DIN 276', 'fix', '1–3 Tage', 590, 1290, 3500, 'objekt', ARRAY['bausumme_eur']::TEXT[], NULL, 'Kostengruppen 100–700.', 4
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung'
UNION ALL
  SELECT id, 'Wirtschaftlichkeitsberechnung Bauprojekt', 'fix', '1–3 Tage', 690, 1490, 4900, 'objekt', ARRAY['bausumme_eur']::TEXT[], NULL, 'Inkl. Rentabilität, Cashflow, Renditeprognose.', 5
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung'
UNION ALL
  SELECT id, 'Bauberatung allgemein (Stundensatz)', 'hr', 'pro Stunde', 85, 110, 180, 'stunde', ARRAY[]::TEXT[], NULL, 'Vor Ort, telefonisch oder online.', 6
  FROM cat_inserts WHERE name = 'Beratung & Vertragsprüfung';

-- ── Gebäudesachverständige (sac) ──
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('sac', 'Verkehrswert & Bewertung', 1),
    ('sac', 'Schadens- & Mängelgutachten', 2),
    ('sac', 'Erwerbs- & Abnahmebegleitung', 3),
    ('sac', 'Spezialgutachten', 4)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, price_min, price_avg, price_max, unit, inputs, fundable, notes, display_order)
  SELECT id, 'Verkehrswertgutachten Wohnimmobilie (Kurzgutachten)', 'fix', '1–2 Wochen', 490, 890, 1490, 'objekt', ARRAY['objekttyp','wohnflaeche_qm']::TEXT[], NULL, '10–15 Seiten. Für Privatzwecke, nicht gerichtsfest.', 1
  FROM cat_inserts WHERE name = 'Verkehrswert & Bewertung'
UNION ALL
  SELECT id, 'Verkehrswertgutachten Wohnimmobilie (Vollgutachten)', 'fix', '3–6 Wochen', 1490, 2900, 6500, 'objekt', ARRAY['objekttyp','wohnflaeche_qm','objektwert']::TEXT[], NULL, '30–80 Seiten. Gerichtsfest, ImmoWertV-konform.', 2
  FROM cat_inserts WHERE name = 'Verkehrswert & Bewertung'
UNION ALL
  SELECT id, 'Verkehrswertgutachten Gewerbeimmobilie', 'pa', '4–10 Wochen', 2490, 5900, 18000, 'objekt', ARRAY['nettogrundflaeche_qm','ertragswert']::TEXT[], NULL, 'Ertragswertverfahren. ImmoWertV-konform.', 3
  FROM cat_inserts WHERE name = 'Verkehrswert & Bewertung'
UNION ALL
  SELECT id, 'Marktwertindikation (Kurzgutachten ohne Vor-Ort)', 'fix', 'ca. 2–4h', 250, 390, 690, 'objekt', ARRAY['objekttyp']::TEXT[], NULL, 'Schreibtischbewertung anhand vorhandener Unterlagen.', 4
  FROM cat_inserts WHERE name = 'Verkehrswert & Bewertung'
UNION ALL
  SELECT id, 'Beleihungswertgutachten', 'pa', '2–4 Wochen', 890, 1900, 4900, 'objekt', ARRAY['objektwert']::TEXT[], NULL, 'BelWertV-konform. Für Banken/Kreditgeber.', 5
  FROM cat_inserts WHERE name = 'Verkehrswert & Bewertung'
UNION ALL
  SELECT id, 'Schimmelpilzgutachten', 'fix', '1–2 Wochen', 490, 790, 1490, 'objekt', ARRAY['raumanzahl']::TEXT[], NULL, 'Inkl. Materialproben + Laborkosten (extra).', 1
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Feuchtigkeitsgutachten', 'fix', '1–2 Wochen', 490, 790, 1490, 'objekt', ARRAY['raumanzahl']::TEXT[], NULL, 'Inkl. Feuchtemessungen, Ursachenanalyse.', 2
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Bauschadengutachten (Risse, Setzungen, Mängel)', 'pa', '2–6 Wochen', 790, 1490, 4500, 'objekt', ARRAY['schadensart','schadensumfang']::TEXT[], NULL, 'Aufwand stark abhängig von Schadensumfang.', 3
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Gerichtsgutachten Bauschäden', 'hr', 'pro Stunde', 90, 125, 175, 'stunde', ARRAY[]::TEXT[], NULL, 'JVEG-Sätze (öff. bestellte SV). Aktuell §10 JVEG.', 4
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Wasserschadensgutachten', 'fix', '1–3 Wochen', 490, 890, 1990, 'objekt', ARRAY['schadensumfang']::TEXT[], NULL, 'Für Versicherungsfälle. Versicherer übernimmt oft.', 5
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Beweissicherungsgutachten Nachbarschaftsstreit', 'pa', '2–6 Wochen', 790, 1490, 4500, 'objekt', ARRAY[]::TEXT[], NULL, 'Z.B. Risse durch Baumaßnahmen, Lärm, Erschütterungen.', 6
  FROM cat_inserts WHERE name = 'Schadens- & Mängelgutachten'
UNION ALL
  SELECT id, 'Hauskaufbegleitung (Begehung & Mängelbericht)', 'fix', 'ca. 3–4h', 390, 590, 990, 'termin', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Vor Kaufvertragsunterzeichnung empfohlen.', 1
  FROM cat_inserts WHERE name = 'Erwerbs- & Abnahmebegleitung'
UNION ALL
  SELECT id, 'Erwerbsgutachten Bestandsimmobilie', 'fix', '1–2 Wochen', 690, 1190, 2490, 'objekt', ARRAY['wohnflaeche_qm','objekttyp']::TEXT[], NULL, 'Inkl. Mängelaufnahme + Modernisierungspotenzial.', 2
  FROM cat_inserts WHERE name = 'Erwerbs- & Abnahmebegleitung'
UNION ALL
  SELECT id, 'Abnahme Eigentumswohnung Neubau', 'fix', 'ca. 2–3h', 290, 450, 690, 'termin', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Begehung mit Käufer beim Bauträger.', 3
  FROM cat_inserts WHERE name = 'Erwerbs- & Abnahmebegleitung'
UNION ALL
  SELECT id, 'Bauabnahme Einfamilienhaus', 'fix', 'ca. 3–4h', 390, 590, 990, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Inkl. Protokoll und Mängelliste.', 4
  FROM cat_inserts WHERE name = 'Erwerbs- & Abnahmebegleitung'
UNION ALL
  SELECT id, 'Wohnflächenberechnung (Wohnflächenverordnung)', 'fix', 'ca. 1–2h', 150, 250, 490, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Nach WoFlV. Wichtig für Mietverträge.', 5
  FROM cat_inserts WHERE name = 'Erwerbs- & Abnahmebegleitung'
UNION ALL
  SELECT id, 'Schadstoffgutachten (Asbest, PCB, KMF)', 'pa', '2–4 Wochen', 590, 1290, 3900, 'objekt', ARRAY['raumanzahl']::TEXT[], NULL, 'Plus Laborkosten. TRGS 519/521-konform.', 1
  FROM cat_inserts WHERE name = 'Spezialgutachten'
UNION ALL
  SELECT id, 'Lärm- & Schallschutzgutachten', 'pa', '2–4 Wochen', 790, 1490, 3500, 'objekt', ARRAY[]::TEXT[], NULL, 'Inkl. Vor-Ort-Messungen.', 2
  FROM cat_inserts WHERE name = 'Spezialgutachten'
UNION ALL
  SELECT id, 'Sachverständigen-Beratung (Stundensatz)', 'hr', 'pro Stunde', 110, 145, 220, 'stunde', ARRAY[]::TEXT[], NULL, 'ö.b.u.v. Sachverständige meist 130–180 €.', 3
  FROM cat_inserts WHERE name = 'Spezialgutachten';

-- ── Vermesser / Geodäten (vrm) ──
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('vrm', 'Amtliche Vermessung (ÖbVI – nach VermGebVO Bundesland)', 1),
    ('vrm', 'Ingenieurvermessung & Bauvermessung', 2),
    ('vrm', 'Lagepläne & Topografie', 3)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, price_min, price_avg, price_max, unit, inputs, fundable, notes, display_order)
  SELECT id, 'Grenzfeststellung / Grenzherstellung', 'pa', '4–8 Wochen', 890, 1690, 4500, 'objekt', ARRAY['grenzpunkte_anzahl','grundstuecksgroesse_qm']::TEXT[], NULL, 'Nach VermGebVO. Preise variieren je Bundesland.', 1
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI – nach VermGebVO Bundesland)'
UNION ALL
  SELECT id, 'Teilungsvermessung (Grundstücksteilung)', 'pa', '6–12 Wochen', 1290, 2490, 6500, 'objekt', ARRAY['teilungen_anzahl','grundstuecksgroesse_qm']::TEXT[], NULL, 'Inkl. Veränderungsnachweis ans Katasteramt.', 2
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI – nach VermGebVO Bundesland)'
UNION ALL
  SELECT id, 'Gebäudeeinmessung (für Liegenschaftskataster)', 'fix', '1–3 Wochen', 390, 690, 1490, 'objekt', ARRAY['bebaute_flaeche_qm']::TEXT[], NULL, 'Pflicht nach Fertigstellung. Frist meist 6 Mon.', 3
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI – nach VermGebVO Bundesland)'
UNION ALL
  SELECT id, 'Amtlicher Lageplan zum Bauantrag', 'fix', '2–4 Wochen', 490, 890, 1990, 'objekt', ARRAY['grundstuecksgroesse_qm']::TEXT[], NULL, 'Maßstab 1:500. Inkl. Höhen und Bestand.', 4
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI – nach VermGebVO Bundesland)'
UNION ALL
  SELECT id, 'Höhenfestlegung / Höhenbolzen', 'fix', '1–2 Tage', 250, 390, 690, 'objekt', ARRAY[]::TEXT[], NULL, 'Pro Höhenpunkt.', 5
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI – nach VermGebVO Bundesland)'
UNION ALL
  SELECT id, 'Grenzbescheinigung', 'fix', '1–2 Wochen', 220, 350, 590, 'objekt', ARRAY[]::TEXT[], NULL, 'Schriftliche Bestätigung amtlich anerkannter Grenzen.', 6
  FROM cat_inserts WHERE name = 'Amtliche Vermessung (ÖbVI – nach VermGebVO Bundesland)'
UNION ALL
  SELECT id, 'Absteckung Bauwerk (Achsabsteckung)', 'fix', '1 Tag', 390, 690, 1490, 'objekt', ARRAY['bebaute_flaeche_qm']::TEXT[], NULL, 'Inkl. Schnurgerüst und Achspunkte.', 1
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, 'Schnurgerüst erstellen', 'fix', 'ca. 4–6h', 250, 390, 690, 'objekt', ARRAY[]::TEXT[], NULL, 'Üblich vor Aushubarbeiten.', 2
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, 'Bestandsaufmaß Gebäude (für Planung)', 'pa', '1–3 Wochen', 590, 1290, 3500, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Innen + Außen, Pläne als CAD/PDF.', 3
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, '3D-Laserscanning Gebäude', 'pa', '2–4 Wochen', 1290, 2900, 9500, 'objekt', ARRAY['nettogrundflaeche_qm']::TEXT[], NULL, 'Hochpräzise Punktwolke. Für BIM und Sanierung.', 4
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, 'Drohnenbefliegung / Photogrammetrie', 'pa', '1–3 Wochen', 690, 1490, 4500, 'objekt', ARRAY['gelaendeflaeche_qm']::TEXT[], NULL, 'DJI/senseFly/Wingtra je nach Größe. Inkl. Orthophoto + DGM.', 5
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, 'Setzungs- & Verformungsmessung', 'pa', 'Mehrere Termine über Monate', 490, 1190, 3900, 'messreihe', ARRAY['messpunkte_anzahl']::TEXT[], NULL, 'Z.B. nach Nachbargrundstück-Baumaßnahmen.', 6
  FROM cat_inserts WHERE name = 'Ingenieurvermessung & Bauvermessung'
UNION ALL
  SELECT id, 'Topografische Geländeaufnahme', 'pa', '1–3 Wochen', 590, 1190, 3500, 'objekt', ARRAY['gelaendeflaeche_qm']::TEXT[], NULL, 'Inkl. Bestandsbäume, Mauern, Versorgungsleitungen.', 1
  FROM cat_inserts WHERE name = 'Lagepläne & Topografie'
UNION ALL
  SELECT id, 'Höhenplan / Geländeschnitt', 'fix', '1–2 Tage', 290, 490, 990, 'schnitt', ARRAY[]::TEXT[], NULL, 'Pro Schnitt.', 2
  FROM cat_inserts WHERE name = 'Lagepläne & Topografie'
UNION ALL
  SELECT id, 'Wegerechts- & Dienstbarkeitsplan', 'fix', '1–3 Wochen', 390, 690, 1490, 'objekt', ARRAY[]::TEXT[], NULL, 'Für Grundbucheintrag.', 3
  FROM cat_inserts WHERE name = 'Lagepläne & Topografie'
UNION ALL
  SELECT id, 'Vermesserberatung (Stundensatz)', 'hr', 'pro Stunde', 95, 130, 195, 'stunde', ARRAY[]::TEXT[], NULL, 'ÖbVI typisch 130–170 €.', 4
  FROM cat_inserts WHERE name = 'Lagepläne & Topografie';

-- ── TGA-Fachplaner (tga) ──
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('tga', 'HOAI Technische Ausrüstung (§ 55) – Honorarzone II', 1),
    ('tga', 'Heizungs- & Lüftungsplanung', 2),
    ('tga', 'Sanitär- & Elektroplanung', 3),
    ('tga', 'Einzelberatung', 4)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, price_min, price_avg, price_max, unit, inputs, fundable, notes, display_order)
  SELECT id, 'LPH 1 – Grundlagenermittlung (TGA, 2%)', 'hoai', '1 Woche', 150, 290, 690, 'bausumme_prozent', ARRAY['bausumme_tga_eur']::TEXT[], NULL, 'Bezogen auf TGA-Anteil der Gesamtkosten.', 1
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55) – Honorarzone II'
UNION ALL
  SELECT id, 'LPH 2 – Vorplanung (TGA, 9%)', 'hoai', '2–3 Wochen', 690, 1290, 3100, 'bausumme_prozent', ARRAY['bausumme_tga_eur']::TEXT[], NULL, '9%.', 2
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55) – Honorarzone II'
UNION ALL
  SELECT id, 'LPH 3 – Entwurfsplanung (TGA, 17%)', 'hoai', '3–6 Wochen', 1290, 2400, 5900, 'bausumme_prozent', ARRAY['bausumme_tga_eur']::TEXT[], NULL, '17%.', 3
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55) – Honorarzone II'
UNION ALL
  SELECT id, 'LPH 4 – Genehmigungsplanung (TGA, 2%)', 'hoai', '1–2 Wochen', 150, 290, 690, 'bausumme_prozent', ARRAY['bausumme_tga_eur']::TEXT[], NULL, '2%.', 4
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55) – Honorarzone II'
UNION ALL
  SELECT id, 'LPH 5 – Ausführungsplanung (TGA, 22%)', 'hoai', '4–10 Wochen', 1690, 3100, 7700, 'bausumme_prozent', ARRAY['bausumme_tga_eur']::TEXT[], NULL, '22%. Werkpläne TGA-Gewerke.', 5
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55) – Honorarzone II'
UNION ALL
  SELECT id, 'LPH 6 – Vorbereitung der Vergabe (TGA, 7%)', 'hoai', '1–3 Wochen', 540, 990, 2450, 'bausumme_prozent', ARRAY['bausumme_tga_eur']::TEXT[], NULL, '7%.', 6
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55) – Honorarzone II'
UNION ALL
  SELECT id, 'LPH 7 – Mitwirkung bei der Vergabe (TGA, 5%)', 'hoai', '1–2 Wochen', 390, 720, 1750, 'bausumme_prozent', ARRAY['bausumme_tga_eur']::TEXT[], NULL, '5%.', 7
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55) – Honorarzone II'
UNION ALL
  SELECT id, 'LPH 8 – Objektüberwachung (TGA, 35%)', 'hoai', 'Bauzeit', 2700, 4900, 12200, 'bausumme_prozent', ARRAY['bausumme_tga_eur']::TEXT[], NULL, '35%. Längste Phase.', 8
  FROM cat_inserts WHERE name = 'HOAI Technische Ausrüstung (§ 55) – Honorarzone II'
UNION ALL
  SELECT id, 'Heizlastberechnung & Heizungsauslegung', 'fix', '1–2 Tage', 590, 990, 1990, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], 'BAFA-fähig in BEG-EM', 'DIN EN 12831, raumweise oder gebäudebezogen.', 1
  FROM cat_inserts WHERE name = 'Heizungs- & Lüftungsplanung'
UNION ALL
  SELECT id, 'Wärmepumpen-Planung & Dimensionierung', 'fix', '1–3 Tage', 890, 1490, 2990, 'objekt', ARRAY['wohnflaeche_qm','wp_typ']::TEXT[], 'BEG-EM-förderfähig', 'Sole-/Wasser-/Luft-WP. Inkl. JAZ-Berechnung.', 2
  FROM cat_inserts WHERE name = 'Heizungs- & Lüftungsplanung'
UNION ALL
  SELECT id, 'Lüftungsplanung kontrollierte Wohnraumlüftung', 'fix', '1–2 Tage', 490, 890, 1990, 'objekt', ARRAY['wohnflaeche_qm','anlagentyp']::TEXT[], 'BEG-EM-förderfähig', 'Zentral oder dezentral, DIN 1946-6.', 3
  FROM cat_inserts WHERE name = 'Heizungs- & Lüftungsplanung'
UNION ALL
  SELECT id, 'Klima-/Kälteanlagenplanung Gewerbe', 'pa', '2–8 Wochen', 1290, 3500, 18000, 'objekt', ARRAY['nettogrundflaeche_qm']::TEXT[], NULL, 'VRF, Splitsysteme, Kaltwassersätze.', 4
  FROM cat_inserts WHERE name = 'Heizungs- & Lüftungsplanung'
UNION ALL
  SELECT id, 'Hydraulischer Abgleich (Berechnung & Planung)', 'fix', '1 Tag', 390, 690, 1290, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], 'BEG-EM-förderfähig', 'Verfahren B mit Bauteilberechnung.', 5
  FROM cat_inserts WHERE name = 'Heizungs- & Lüftungsplanung'
UNION ALL
  SELECT id, 'Sanitärplanung Einfamilienhaus', 'pa', '1–3 Wochen', 690, 1290, 2900, 'objekt', ARRAY['wohnflaeche_qm','bad_anzahl']::TEXT[], NULL, 'Trink- und Abwasser, DIN 1986-100 / DIN 1988.', 1
  FROM cat_inserts WHERE name = 'Sanitär- & Elektroplanung'
UNION ALL
  SELECT id, 'Elektroplanung Wohngebäude (Stromkreise, Verteilung)', 'pa', '1–4 Wochen', 790, 1490, 3500, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Inkl. Verteilerplan, KNX/Smart-Home optional.', 2
  FROM cat_inserts WHERE name = 'Sanitär- & Elektroplanung'
UNION ALL
  SELECT id, 'Photovoltaikplanung & Auslegung', 'fix', '1–2 Tage', 390, 690, 1490, 'objekt', ARRAY['dachflaeche_qm']::TEXT[], NULL, 'Inkl. Verschattungsanalyse, Modulauslegung, WR-Wahl.', 3
  FROM cat_inserts WHERE name = 'Sanitär- & Elektroplanung'
UNION ALL
  SELECT id, 'E-Mobilität-/Wallbox-Konzept', 'fix', 'ca. 4–6h', 250, 390, 790, 'objekt', ARRAY['wallbox_anzahl']::TEXT[], NULL, 'Inkl. Lastmanagement, Netzanmeldung.', 4
  FROM cat_inserts WHERE name = 'Sanitär- & Elektroplanung'
UNION ALL
  SELECT id, 'TGA-Erstberatung', 'fix', 'ca. 1,5h', 130, 190, 350, 'termin', ARRAY[]::TEXT[], NULL, 'Verrechenbar bei Beauftragung.', 1
  FROM cat_inserts WHERE name = 'Einzelberatung'
UNION ALL
  SELECT id, 'TGA-Beratung (Stundensatz)', 'hr', 'pro Stunde', 95, 135, 195, 'stunde', ARRAY[]::TEXT[], NULL, 'Höhere Sätze für leitende Fachplaner.', 2
  FROM cat_inserts WHERE name = 'Einzelberatung';

-- ── Bauphysik & Spezialberatung (bps) ──
WITH cat_inserts AS (
  INSERT INTO service_categories (branch_id, name, display_order) VALUES
    ('bps', 'Schallschutznachweise', 1),
    ('bps', 'Brandschutz', 2),
    ('bps', 'Schadstoff- & Umweltgutachten', 3),
    ('bps', 'Bauphysik', 4)
  RETURNING id, name
)
INSERT INTO service_templates (category_id, name, price_type, duration, price_min, price_avg, price_max, unit, inputs, fundable, notes, display_order)
  SELECT id, 'Schallschutznachweis Wohngebäude (DIN 4109)', 'fix', '1–2 Tage', 390, 690, 1490, 'objekt', ARRAY['wohnflaeche_qm','wohneinheiten']::TEXT[], NULL, 'Pflicht bei Neubau und Erweiterung.', 1
  FROM cat_inserts WHERE name = 'Schallschutznachweise'
UNION ALL
  SELECT id, 'Schallschutznachweis Nichtwohngebäude', 'pa', '1–3 Wochen', 790, 1490, 4500, 'objekt', ARRAY['nettogrundflaeche_qm']::TEXT[], NULL, 'Komplexer als bei Wohngebäuden.', 2
  FROM cat_inserts WHERE name = 'Schallschutznachweise'
UNION ALL
  SELECT id, 'Raumakustik-Konzept (Gewerbe)', 'pa', '1–3 Wochen', 590, 1290, 3900, 'objekt', ARRAY['raumvolumen_m3']::TEXT[], NULL, 'Z.B. Büro, Kita, Praxis.', 3
  FROM cat_inserts WHERE name = 'Schallschutznachweise'
UNION ALL
  SELECT id, 'Bauakustische Messung vor Ort', 'fix', 'Halbtag', 490, 790, 1490, 'termin', ARRAY[]::TEXT[], NULL, 'Luft- und Trittschall, DIN EN ISO 16283.', 4
  FROM cat_inserts WHERE name = 'Schallschutznachweise'
UNION ALL
  SELECT id, 'Brandschutzkonzept Wohngebäude', 'pa', '2–4 Wochen', 890, 1690, 4500, 'objekt', ARRAY['wohnflaeche_qm','geschosse']::TEXT[], NULL, 'Pflicht ab Gebäudeklasse 4 (Hochhaus).', 1
  FROM cat_inserts WHERE name = 'Brandschutz'
UNION ALL
  SELECT id, 'Brandschutzkonzept Sonderbau / Gewerbe', 'pa', '3–8 Wochen', 2290, 4500, 14000, 'objekt', ARRAY['nettogrundflaeche_qm','nutzungstyp']::TEXT[], NULL, 'Versammlungsstätten, Schulen, Kitas, Krankenhäuser.', 2
  FROM cat_inserts WHERE name = 'Brandschutz'
UNION ALL
  SELECT id, 'Brandschutznachweis für Bauantrag', 'fix', '1–2 Wochen', 590, 990, 2290, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Einreichungsfähiger Nachweis.', 3
  FROM cat_inserts WHERE name = 'Brandschutz'
UNION ALL
  SELECT id, 'Flucht- & Rettungswegplan', 'fix', '1–2 Wochen', 290, 590, 1490, 'objekt', ARRAY['nettogrundflaeche_qm']::TEXT[], NULL, 'DIN ISO 23601. Pro Geschoss.', 4
  FROM cat_inserts WHERE name = 'Brandschutz'
UNION ALL
  SELECT id, 'Asbest-Erkundung (vor Sanierung/Abbruch)', 'fix', '1–2 Wochen', 490, 890, 1990, 'objekt', ARRAY['wohnflaeche_qm','probenanzahl']::TEXT[], NULL, 'Plus Laborkosten 80–120 €/Probe.', 1
  FROM cat_inserts WHERE name = 'Schadstoff- & Umweltgutachten'
UNION ALL
  SELECT id, 'PCB-/KMF-Erkundung', 'fix', '1–3 Wochen', 490, 890, 1990, 'objekt', ARRAY['probenanzahl']::TEXT[], NULL, 'Häufig in Industriegebäuden der 60er/70er.', 2
  FROM cat_inserts WHERE name = 'Schadstoff- & Umweltgutachten'
UNION ALL
  SELECT id, 'Schadstoffkataster Gebäudekomplex', 'pa', '3–8 Wochen', 1290, 2900, 9500, 'objekt', ARRAY['nettogrundflaeche_qm']::TEXT[], NULL, 'Vollständige Erfassung aller Schadstoffe.', 3
  FROM cat_inserts WHERE name = 'Schadstoff- & Umweltgutachten'
UNION ALL
  SELECT id, 'Rückbau- & Entsorgungskonzept', 'pa', '2–6 Wochen', 890, 1990, 5900, 'objekt', ARRAY['bvt_volumen_m3']::TEXT[], NULL, 'Inkl. Massenermittlung + Verwertungsweg.', 4
  FROM cat_inserts WHERE name = 'Schadstoff- & Umweltgutachten'
UNION ALL
  SELECT id, 'Bauphysikalisches Gutachten', 'pa', '2–6 Wochen', 790, 1690, 4900, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Wärme + Feuchte + Schall + Brand kombiniert.', 1
  FROM cat_inserts WHERE name = 'Bauphysik'
UNION ALL
  SELECT id, 'Feuchteschutznachweis nach DIN 4108', 'fix', 'ca. 4–6h', 290, 490, 890, 'objekt', ARRAY['wohnflaeche_qm']::TEXT[], NULL, 'Pflichtnachweis bei Neubau und Sanierung.', 2
  FROM cat_inserts WHERE name = 'Bauphysik'
UNION ALL
  SELECT id, 'Beratung Bauphysik allgemein', 'hr', 'pro Stunde', 100, 140, 195, 'stunde', ARRAY[]::TEXT[], NULL, 'Vor-Ort, telefonisch oder per Video.', 3
  FROM cat_inserts WHERE name = 'Bauphysik';

-- ┌─────────────────────────────────────────────────────────────┐
-- │ VERIFICATION                                                 │
-- └─────────────────────────────────────────────────────────────┘

SELECT 'branches' AS table, COUNT(*) FROM branches
UNION ALL SELECT 'categories', COUNT(*) FROM service_categories
UNION ALL SELECT 'services', COUNT(*) FROM service_templates;

-- Energieberatung mit Preisempfehlungen ansehen
SELECT b.name AS branche, sc.name AS kategorie,
       st.name AS leistung, st.price_type,
       st.price_min, st.price_avg, st.price_max, st.unit
FROM branches b
JOIN service_categories sc ON sc.branch_id = b.id
JOIN service_templates st ON st.category_id = sc.id
WHERE b.id = 'enb'
ORDER BY sc.display_order, st.display_order;

-- Marktstatistik: Preisrahmen pro Branche
SELECT b.name AS branche,
       COUNT(st.id) AS leistungen,
       AVG(st.price_avg) AS preis_durchschnitt,
       MIN(st.price_min) AS preis_min,
       MAX(st.price_max) AS preis_max
FROM branches b
JOIN service_categories sc ON sc.branch_id = b.id
JOIN service_templates st ON st.category_id = sc.id
WHERE st.price_avg IS NOT NULL
GROUP BY b.id, b.name, b.display_order
ORDER BY b.display_order;
